# Changelog

All notable changes to `cboxdk/laravel-id` are documented here.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).
Confirmed security vulnerabilities and their fixes are cross-referenced under
**Security** below and in the repository's security advisories.

**Released entries are immutable.** A changelog is a historical record: what an entry
said at the time it shipped is part of what shipped. Entries below the newest released
heading are not edited for wording, tone or policy — only appended to, and only with a
dated note that says what changed and why. From 0.56.1 onward the house style avoids
naming competitor products in prose; that applies to entries written from here on and is
deliberately NOT applied backwards, because a silent rewrite of shipped history costs
more trust than the wording it removes.

## [Unreleased]

## [1.27.2] - 2026-11-04

### Security

- Bind OIDC and SP-initiated SAML callbacks to secure host-only browser cookies. OIDC flow state expires server-side and is consumed atomically once.
- Read SAML logout freshness and replay identifiers from the verified message root, ignoring unsigned comments.
- Restrict the SAML ACS to SAML connections and reject logout requests without a signed protocol message.

### Upgrade notes

- Restart pending federated logins after upgrading. Both legs must use the same HTTPS host. OIDC flow storage requires a shared cache with atomic add support.
- Custom SAML callback controllers must enforce `SamlBrowserBinding`; see `UPGRADING.md`.

## [1.27.1] - 2026-11-04

### Fixed

- Compare custom JSON objects independently of key order, including after MySQL persistence, so unchanged metadata does not generate extra versions or webhooks.
- Keep the SAML Redirect signing guard compatible with both xmlseclibs 3 and 4 under current static analysis.

## [1.27.0] - 2026-11-04

### Added

- Shared user preferences (language, locale, timezone, date/time formats, week start and system/light/dark theme) and custom JSON namespaces with explicit app reader/writer grants.
- OAuth user-properties read/patch endpoints, optimistic versions, explicit key removal and namespace-scoped webhook notifications through the transactional outbox. Queued deliveries recheck grants before sending; an after-commit wake-up reduces relay latency.
- Erasure support, public host contracts, integration test helpers and a complete integration recipe. User data stays within its environment; custom values are never copied into tokens or change events.

## [1.26.6] - 2026-11-04

### Fixed

- Run the release SBOM dependency-set check with PHP, which is available in every CI matrix container. The previous check failed because `jq` was missing, before comparing dependencies. Includes all security fixes from 1.26.5.

## [1.26.5] - 2026-11-04

### Security

- Reject authorization-code redemption, refresh rotation and direct user-token issuance for inactive or missing subjects. Deactivation invalidates pending authorization codes as well as existing grants; database subject locking serializes issuance with deactivation.
- Add `MfaVerification` to distinguish an enrolled factor from a verified login. Authenticated local password and magic-link events cannot mint tokens while their second factor is still required. Federated authentication keeps its upstream assurance policy.

## [1.26.4] - 2026-11-03

### Fixed

- **`organization.created` now carries the organization's `name`.** The event (and the webhook built from it) said only `id` and `slug`, so a receiver mirroring organizations had to read the name back over the management API or show the id until the first `organization.updated` arrived; Cbox Engage showed ids on its Companies page for exactly that reason. The payload is now `id`, `name`, `slug`, the shape `organization.updated` already had.

## [1.26.3] - 2026-11-02

### Fixed

- **A client ID metadata document client may sign in from any loopback port.** `AuthorizationClient::allowsRedirectUri()` matched a document client's `redirect_uris` exactly, loopback included, so a native client whose document lists `http://localhost/callback` and binds a free port at sign-in time (Claude Code does exactly this) was refused at `/authorize` with a redirect mismatch on every attempt. A loopback redirect (`127.0.0.1`, `[::1]`, `localhost`) now matches when it differs only in port, the rule a registered client already had (RFC 8252 §7.3; OAuth 2.1 §8.4.2 requires the server to allow any port there). Non-loopback redirects still match exactly.

## [1.26.2] - 2026-10-28

### Fixed

- **A catalogue provider's sign-in now says which provider it was.** `FederationLoginService::completeLogin()` started every federated session with `amr` `['sso']`, so a sign-in with an environment's or organization's Google, GitHub or other catalogue connection read exactly like enterprise single sign-on, and a sign-in page could not mark the button that was pressed. A connection with a catalogue `provider` now starts the session with `['social', '<provider>']`, the same `amr` an operator's own social sign-in records; a hand-configured connection (no `provider`) still records `['sso']`. A `pre_authentication` hook or token consumer that treated `sso` as "federated" should also accept `social`.

## [1.26.1] - 2026-10-27

### Fixed

- **Client ID metadata documents work again on Guzzle 8.** `HttpMetadataDocumentFetcher` passed `CURLOPT_MAXFILESIZE` in the `curl` request option; Guzzle 8's cURL handler refuses curl options outside its allow-list with an `InvalidArgumentException` before sending, which nothing caught, so every `/authorize` with a document `client_id` (Claude's MCP connector among them) answered 500. The size ceiling is now enforced through Guzzle's own `progress` option (the transfer stops once more than `max_bytes` has arrived), beside the existing `Content-Length` check and the final measure; any Guzzle transfer failure reads as `fetch_failed`. A test now fetches through the real cURL handler, which the faked HTTP tests never reached.

## [1.26.0] - 2026-10-13

### Added

- `identities.last_used_at` (nullable timestamp, migration): when a linked federated identity last signed somebody in. `DatabaseSubjects::resolveFederated()` stamps it when a returning identity resolves and when a first sign-in creates one; an explicit `link()` does not, so a link nobody has signed in with yet reads as never used. It is written by a direct column update, so `updated_at` still says when the link itself changed. No backfill: identities linked before this release read null until their next sign-in. `IdentityLink` casts it to `CarbonImmutable`. Nothing else changes; `LinkedIdentity` and the `Subjects` contract are untouched.

## [1.25.0] - 2026-10-10

### Added

- **Environment-wide social sign-in, inherited by organizations.** `Federation\Contracts\SignInProviders` (bound to `DatabaseSignInProviders`) decides which catalogue providers a sign-in page offers: `offeredTo(?string $organizationId)`, `environmentProviders()`, `stopInheriting()` / `resumeInheriting()` / `notInheritedBy()` / `optOuts()`, and `create()`. An environment-owned provider (`organization_id` null) is offered on every organization's page. For one provider key, an organization's own connection (active or turned off, not a draft) replaces the environment's, then an organization's opt-out hides it, then the environment's active one is offered. New table `sign_in_provider_opt_outs` (migration). Nothing existing changes: organizations had no environment providers to inherit before. See [Sign-in provider catalogue](docs/core-concepts/sign-in-provider-catalogue.md#who-owns-a-provider-the-environment-or-one-organization).
- `SignInProviders::create()` takes an optional reserved ULID, so a console can show the real redirect URI (which contains the connection id) before the provider is saved. `ConnectionService::create()` gains a trailing optional `?string $id`; the `Connections` contract is unchanged. A reserved id that is not a ULID or is already used in any environment is refused (`InvalidAssertion`).
- `OAuth2ConnectionConfig::$scopes` (trailing, optional): extra scopes an OAuth 2.0 connection requests on top of the catalogue's. `OAuth2Client::authorizeUrl()` sends the union, catalogue scopes first.
- **Environment-wide sign-in methods and session lengths on the authentication policy.** `AuthPolicy` gains trailing optional `passkeys` (true), `magicLink` (true), `sessionIdleMinutes` (null), `sessionAbsoluteMinutes` (null) and `botChallenge` (true), stored as new `auth_policies` columns whose defaults are today's behaviour (migration). They are environment-wide: `tightenedWith()` keeps the baseline's values and ignores an organization override's (`AuthPolicy::environmentWide()`, `isEnvironmentWide()`).
- `Identity\Contracts\SignInMethods` (bound to `PolicySignInMethods`) combines them with the deployment's ceiling: `passkeysEnabled()`, `magicLinkEnabled()`, `sessionAbsoluteMinutes()`, `sessionIdleMinutes()` and the `deployment*()` readers. New config `cbox-id.sign_in.passkeys` and `cbox-id.sign_in.magic_link` (`CBOX_ID_PASSKEYS_ENABLED`, `CBOX_ID_MAGIC_LINK_ENABLED`, both on by default); `cbox-id.sessions.*` is now the most an environment may choose.
- `Identity\Exceptions\SignInMethodDisabled` (with `$method`), thrown by `MagicLinkService::request()` / `redeem()` and `PasskeyService::register()` / `authenticate()` when the method is off here. A link minted before magic links were switched off no longer redeems; a passkey refusal comes before the credential lookup. See [Password policy](docs/security/password-policy.md#the-environment-wide-fields).

### Changed

- `GET /frontend/v1/config`'s `social` list is resolved by `SignInProviders::offeredTo()`, the hosted page's resolver: without a hint the environment's own providers, and with the new optional `?organization=` (id or slug) exactly what that organization's hosted page offers. It used to list every active catalogue connection in the environment, every organization's included, ordered by name; it is now ordered by provider key. An unknown organization is answered as no hint.
- `DatabaseSessionManager` starts a session with the environment's absolute lifetime and applies its idle timeout, each bounded by the deployment's (its constructor values). Where an environment chose an absolute lifetime, `active()` also measures it from `created_at`, so shortening it ends sessions already running. With no environment choice, behaviour is unchanged.

## [1.24.0] - 2026-10-10

### Added

- **Feature flags** (`Cbox\Id\FeatureFlags\`). Environment-owned switches (`feature_flags`, `feature_flag_targets`, migration) with a key, a description, a kill switch (`enabled`) and a default, targeted by user rules and organization rules that each carry their own on/off, and a 0–100 rollout. Precedence, first match wins: switched off → user rule → organization rule → rollout bucket → default (`EvaluationReason`). The rollout bucket is `int(sha256(key + "/" + identity)[0:8], 16) % 100` over the user id (the organization id without one): stable across requests and replicas, monotonic as the percentage rises, salted per flag, and reproducible by an SDK. The `FeatureFlags` contract (`DatabaseFeatureFlags`) manages flags (`all`, `find`, `findByKey`, `create(NewFeatureFlag)`, `update(FeatureFlagChanges)`, `delete`, each taking an optional `AuditActor`) and evaluates them (`isEnabled`, `evaluate` → `FlagEvaluation`, `forSubject` → sorted keys that are on, `evaluateAll`). Rules may name only users and organizations of the current environment (`InvalidFeatureFlag` with a machine `reason`); `UnknownFeatureFlag` for an id not in it.
- Evaluation reads one compiled, cached set per environment (`cbox-id:feature-flags:{environment}`) and answers in memory. Any save or delete of a flag or rule forgets it at the model, and again after the surrounding transaction commits. `cbox-id.feature_flags.cache_ttl` (300 s, `CBOX_ID_FEATURE_FLAGS_CACHE_TTL`; 0 reads the database) and `cbox-id.feature_flags.max_rules` (1000 per flag, `CBOX_ID_FEATURE_FLAGS_MAX_RULES`).
- **The `feature_flags` claim** on the access token, the ID token and UserInfo, behind a new protocol scope `feature_flags` (`ProtocolScope::FeatureFlags`, advertised in `scopes_supported` and `claims_supported`): the sorted keys of every flag on for the subject in the bound organization, an empty list when none is, absent without the scope. UserInfo reads it live; a `client_credentials` token is evaluated for its organization. Once the scope is granted a token-minting hook cannot change it; without the scope the name stays free for a hook, as before. `FeatureFlags\Support\FeatureFlagClaim`. `JwtTokenIssuer`, `TokenController` and `UserInfoController` take it as a trailing optional constructor argument.
- Webhook events `feature_flag.created`, `feature_flag.updated` (with `changed`) and `feature_flag.deleted` under a new `WebhookEventGroup::FeatureFlags`, and the audit actions of the same names (the targeting change recorded as a diff).
- Erasing a user deletes the flag rules that name them (erasure step `feature_flags.targets`).
- `InteractsWithFeatureFlags` testing trait (`createFeatureFlag`, `assertFeatureEnabled`, `assertFeatureDisabled`). Docs: [Feature flags](docs/core-concepts/feature-flags.md).
- **Fine-grained authorization** — an environment's own relationship model, Zanzibar-style. `Kernel\Authorization\Contracts\FineGrainedAuthorization` (bound to `DatabaseFineGrainedAuthorization`) holds a per-environment **schema** written in a small language (`type folder` / `relation viewer: [user, group#member] or editor or viewer from parent`, with `and`, `but not` and parentheses), **tuples** (`document:readme#viewer@group:eng#member`) written and deleted in atomic, schema-checked batches, and **check**, **batch check**, **list-resources** and **list-subjects** evaluated over both. `Schema\SchemaParser` reports every error by line; `SchemaValidator` refuses unknown types and relations, tuple-to-userset through anything but a plain type list, and any exclusion that refers back to the relation it decides, while allowing cycles that only add access. A schema change that would strand existing tuples is refused (`SchemaConflict`). The evaluator (`Fga\Evaluator`, over a `Fga\TupleReader`) searches depth-first with cycle cut-off and a memo that never caches a "no" that leaned on a cut, refuses past `max_depth` rather than guessing (`ResolutionTooComplex`), and is tested against a stratified-fixpoint reference implementation on random graphs. Every write advances a per-environment **revision**; reads take and return a `ConsistencyToken` (at least as fresh as a given write, re-reading the write connection when a replica lags; another environment's token is refused) and are cached under the revision and a per-revision random tag, so a write invalidates instantly and an answer computed in a rolled-back transaction is never served. New tables `fga_stores` and `fga_tuples` (forward and reverse indexes), config `cbox-id.fga.*` (`max_depth`, `max_expansion`, `max_batch`, `cache.enabled|store|ttl`), and the `InteractsWithFineGrainedAuthorization` testing trait. See [Fine-grained authorization](docs/core-concepts/fine-grained-authorization.md), which includes a benchmark note.
- **SMS one-time codes.** `Otp\Channels\SmsOtpChannel` texts a code through the new `Otp\Sms\Contracts\SmsSender` (`cbox-id.sms.driver`): `twilio` (Programmable Messaging; Messaging Service or From; auth token or API key), `messagebird` (legacy REST API), `bird` (Channels API), `46elks` (with `dry_run`), `log` (development; refuses when `APP_ENV=production`) and `array` (tests), or a host class implementing `SmsSender`. HTTP through Laravel's client with bounded timeouts and no retries — no provider SDK is a dependency. `SmsSenderFactory`, `SmsDeliveryFailed` (names the provider and status, never the number or body). Map it under `cbox-id.otp.channels` to use it; nothing changes until you do.
- **E.164 normalisation** without a numbering-plan dependency: `Otp\Sms\PhoneNumberNormaliser` and the `PhoneNumber` value object (`e164()`, `masked()` as `+45 ******78`, `country`). Accepts common formatting, `00` prefixes, `(0)` trunk notation, and national format with a default country; assigns a country from `CallingCodes` (North American area codes that are not the US, Kazakhstan inside `+7`); refuses non-geographic ranges (`+881`, `+882`, `+883`, `+979`, …), letters, extensions and lengths outside the plan (`InvalidPhoneNumber`).
- **Toll-fraud guard.** Every text passes `Otp\Sms\Contracts\SmsSendGuard` (`RateLimitedSmsSendGuard`) before the provider is called: deployment country allow-list (`cbox-id.sms.allowed_countries`) plus a caller's narrower list, per-number cooldown, per-number daily cap, per-IP hourly cap, per-environment daily cap and a deployment-wide daily circuit breaker (`cbox-id.sms.limits.*`). Nothing is counted when it refuses. `SmsSendRefused` carries a `SmsRefusalReason` and `retryAfterSeconds`.
- **`Otp\Sms\SmsDispatcher`** — the single path for coded texts: guard, compose, send, and audit `sms.sent` / `sms.refused` / `sms.failed` with the number masked, the country, the purpose and the IP. Never the number, never the code.
- **Localised SMS text.** `SmsMessageComposer` ships `en`, `da`, `de`, `fr`, `nb`, `sv`, code first, each a single GSM-7 segment at the worst case; `cbox-id.sms.messages` overrides per locale. `OtpDelivery` gains trailing optional `ip` and `locale`, which `DatabaseOtpService` fills from the issue call and the current locale.
- **SMS as a second factor.** `Identity\Contracts\SmsFactors` (`SmsFactorService`): `beginEnrolment()` / `confirmEnrolment()`, `sendChallenge()` / `verifyChallenge()`, `isEnrolled()`, `isUsable()`, `needsStrongerFactor()`, `details()` and `remove()` (audited `user.mfa_sms_removed` with the actor). The number is sealed in `mfa_factors.secret_encrypted` (type `sms`, the person's AEAD context, so rewrap and erasure cover it); its OTP challenges are addressed to `mfa-sms:{factor id}` through the `sms_factor` channel (`SmsFactorOtpChannel`), so neither `otp_challenges` nor the audit log holds it. Code length, lifetime, attempts and verify throttles are the OTP module's. Recovery codes are unaffected. `SmsFactorRefused` / `SmsFactorRefusal`, `SmsCodeSent`, `SmsFactorDetails`.
- **Per-environment SMS policy**, off by default: `Identity\Contracts\SmsFactorPolicies` (`DatabaseSmsFactorPolicies`, `sms_factor_policies` table, migration) storing `SmsFactorPolicy` — `enabled`, `allowedCountries` (an empty list admits none; re-checked at every send) and `privilegedNeedStrongerFactor` (default on: an administrator may add SMS only beside TOTP or a passkey). `Identity\Contracts\PrivilegedSubjects` decides who is an administrator (default `MembershipPrivilegedSubjects`: an owner or admin of any organization).
- `AuthMethod::Sms` (`sms`, RFC 8176) and `AuthMethod::forSmsCode()` (`pwd`, `sms`, `mfa`) for a sign-in completed with a texted code — `sms` rather than `otp`, so a relying party can tell it from an authenticator app.
- `InteractsWithSms::fakeSms()` test helper; `ArraySmsSender` with `assertSent()`, `latestCode()`, `failNext()`.

### Changed

- `DatabaseMfaMandate` counts a usable SMS factor as a second factor, and asks an administrator whose only factor is SMS to enrol a stronger one when the policy says SMS cannot stand alone (even where MFA is optional). The SMS dependency is a trailing optional constructor argument. No behaviour changes in an environment that has not turned SMS on.
- **HR-system (HRIS) directory sync.** Five new pull providers on `DirectoryProvider` — `Workday`, `BambooHr`, `Rippling`, `HiBob`, `Personio` — with `isHris()` and `hris()`, each with a connector registered in `DirectoryConnectors`: `WorkdayConnector` (a RaaS custom report as JSON, with an integration system user or an OAuth API client's refresh token; the report URL pinned to `cbox-id.directory.hris.workday_hosts`), `BambooHrConnector` (`/api/v1/employees` cursor-paged, active and inactive; `/meta/lists` departments; `/employees/changed` incremental), `RipplingConnector` (REST API `workers`/`departments`, `next_link` pinned to the API host, `updated_at` incremental), `HiBobConnector` (`people/search` with `showInactive`, named-list departments) and `PersonioConnector` (v2 `persons` + `employments`, `org-units`).
- `Directory\Hris\Contracts\HrisProvider` (extends `DirectoryConnector`: `fetchEmployees()`, `fetchDepartments()`, `supportsIncremental()`, `probe()`), the `HrisConnector` base class, `HrisEmployee`, `HrisDepartment`, `HrisSyncOptions`, `EmploymentStatus`, `HrisEmployeeMapper` (dates over status words; the person stored as a SCIM user with the enterprise `manager`/`department`/`employeeNumber` and the `urn:cbox-id:params:scim:schemas:extension:hris:1.0:User` extension), `HrisDirectorySync` (leavers never provisioned, per-record failures reported, termination dates swept every run, departments as `department:{id}` groups, a mass-deprovisioning guard), `HrisCatalog` (setup steps, documentation, and the credentials each connector reads, with `credentialsFrom()` validation), `HrisCredential`, `HrisSetup`, `IncompleteHrisCredentials`, and the shared `HrisHttp` client that retries 429/502–504 honouring `Retry-After` and rate-limit reset headers.
- `DirectoryPullSync` runs an `HrisProvider` through `HrisDirectorySync`, records every run on the directory (`last_sync_started_at`, `last_sync_status` — `DirectorySyncStatus` running/succeeded/partial/failed — `last_sync_stats`, and for HR systems `sync_cursor` / `last_full_sync_at`), holds a per-directory cache lock (`DirectorySyncInProgress`), and takes a trailing `bool $full = false`. `DirectorySyncResult` gains trailing `skipped`, `failed`, `failures` (`SyncFailure`) and `incremental`, with `partial()` and `toArray()`.
- Per-directory sync pace: `directories.sync_interval_minutes` (migration, with the other run columns), `Directory::syncIntervalMinutes()`, `isDueForSync()`, `nextSyncAt()`, `cbox-id.directory.default_interval_minutes` (60). `cbox-id:directory:sync` gains `--due` and `--full`; the scheduler now runs `--due` every fifteen minutes, so a directory with no interval of its own is still pulled hourly.
- `PullDirectories` contract (implemented by `DirectoryService`): `replaceCredentials()`, `setSyncInterval()`, `setHrisOptions()` (custom attributes to pass through, Workday column map, stored on `mappings.hris`).
- `Directory\Jobs\SyncPullDirectory`, a queued, unique-per-directory pull that carries only the directory id.
- `FakeHrisProvider` for tests.
- Config `cbox-id.directory.hris.*`: `pre_hire_days`, `full_sync_hours`, `deprovision_guard`, `max_attempts`, `max_backoff_seconds`, `max_reported_failures`, `workday_hosts`; `cbox-id.directory.lock_seconds`.
- Docs: [Sync people from an HR system](docs/cookbook/sync-people-from-an-hr-system.md); feature support and the schedule table updated.
- `Directory` hides `credentials` and `bearer_token_hash` from serialization (`toArray()`/JSON). Both were already sealed or hashed.
- A pull that fails for a reason other than `DirectoryConnectionFailed` is now recorded on the directory as failed (with the exception's class, not its message) before it is rethrown, and a missing-credentials failure is recorded too.
- **Pipes — connected third-party accounts** (`Cbox\Id\Pipes\`). A signed-in person connects their own account at GitHub, Google, Microsoft 365, Slack, Salesforce, HubSpot, Linear or Notion over OAuth 2.0 authorization code + PKCE (S256, always sent), and the environment's authorised apps lease a fresh access token for them. Built on the token vault: each connection's access and refresh tokens are **user-owned `SecretVault` secrets** (sealed, audited, rewrapped, erased with the person), read only through vault leases by the internal broker client `cbox-id:pipes` (`Support\PipeSecrets::BROKER_CLIENT_ID`).
  - `PipeProviderCatalog` / `ValueObjects\PipeProvider`: endpoints, default scopes, scope parameter and separator, token request format (`Enums\TokenRequestFormat`) and client authentication, nested token responses (Slack's `authed_user`), assumed token lifetimes (Salesforce), per-installation `PipeParameter`s with strict patterns (Microsoft `tenant`, Salesforce `domain`), revocation (`PipeRevocation`, `Enums\RevocationStyle`: RFC 7009, bearer, GitHub grant, HubSpot path, JSON token for Notion), per-provider `requestHeaders` (Notion's `Notion-Version`), account-label lookup and the non-secret token-response `metadataPaths` an app needs (Salesforce `instance_url`). GitHub's endpoints and shared vendor names are read from the sign-in `ProviderCatalog`.
  - Contracts `Pipes` (configure / update / remove / grant / revokeGrant / grantedClients / isGranted), `PipeConnections` (`start` → `complete`, `disconnect`, `find`, `forUser`, `forPipe`) and `PipeTokens` (`lease`, `refresh`, `refreshIfExpiring`), bound to `DatabasePipes`, `DatabasePipeConnections`, `DatabasePipeTokens`. `PipeOAuthClient` does the HTTP, SSRF-pinned, and reduces provider errors to their code.
  - Leases are deny-by-default and uniform for an app without a `PipeGrant` (`PipeLeaseDenied`, reason audited as `pipe.lease.denied`); a granted app is told `PipeConnectionMissing` or `PipeReauthorizationRequired`; `PipeRefreshFailed` is transient. `ValueObjects\PipeAccessToken` carries the provider's `expiresAt`, the vault's `leaseExpiresAt`, scopes and metadata.
  - Single-flight refresh through an atomic claim on `pipe_connections.refresh_claimed_until`; a lease waits for a refresh in progress, the sweep skips it. A refused refresh token (`invalid_grant`, `bad_refresh_token`, `invalid_refresh_token`, `BAD_REFRESH_TOKEN`, …) or an expired token with none marks the connection `needs_reauth`; outages and `invalid_client` are counted, not blamed on the person.
  - `cbox-id:pipes:refresh`, scheduled every five minutes (`pipes.schedule`), refreshes connections expiring within `pipes.refresh_ahead_seconds` across environments.
  - Webhook events `pipe.connection.connected`, `pipe.connection.needs_reauth`, `pipe.connection.disconnected` (new `WebhookEventGroup::Pipes`), and audit actions `pipe.*`. No token or client secret reaches the audit trail, the outbox or the log.
  - Migration `create_pipes_tables` (`pipes`, `pipe_grants`, `pipe_connections`); the pipe's client secret is a sealed column registered for `cbox-id:crypto:rewrap`. Erasure step `pipes.connections`.
  - Config `cbox-id.pipes.*`: `schedule`, `refresh_ahead_seconds`, `refresh_batch`, `lease_refresh_skew_seconds`, `refresh_claim_seconds`, `refresh_wait_milliseconds`, `http_timeout`, `verify_url` (env `CBOX_ID_PIPES_*`).
  - Every write (`Pipes::configure` / `update` / `remove` / `grant` / `revokeGrant`, `PipeConnections::disconnect`) takes an optional trailing `?AuditActor $actor`, recorded on the audit trail — a console passes the person, an API the key; left out, the system. `InvalidPipeConfiguration::$field` names the input a refusal is about.
  - `Testing\InteractsWithPipes` (`configurePipe`, `grantPipe`, `connectPipeAccount`, `leasePipeToken`) runs the real flow with only the provider faked.
  - Docs: `core-concepts/pipes.md`, `security/pipes.md`, `cookbook/connect-a-third-party-account.md`.

### Fixed

- **The Auth0 SAML guide linked a page Auth0 retired.** `IdentityProviderGuides`' Auth0 entry pointed `documentationUrl` at `…/saml-sso-integrations/configure-auth0-saml-identity-provider`, which answers 404; a host's Admin Portal and generated IdP pages printed it as "Auth0's own guide". It now points at Auth0's *Enable SAML2 Web App Addon* page, which documents the steps the guide gives.

## [1.23.1] - 2026-10-08

### Fixed

- `cbox-id:doctor` counts signing keys per environment. Signing keys are environment-owned and the doctor runs with no environment set, so the environment scope hid every key and it warned "No active signing key yet" on every multi-environment install. It now reads past the scope, reports OK when every environment has an active key, and names the environments that have none.

## [1.23.0] - 2026-10-08

### Added

- **SCIM 2.0 filter grammar** (RFC 7644 §3.4.2.2). `Scim\Filter\ScimFilterParser` (a tokenizer and recursive-descent parser) produces a typed AST — `ComparisonNode`, `PresentNode`, `LogicalNode`, `NotNode`, `ValuePathNode` — with every operator (`eq ne co sw ew gt ge lt le pr`), `and`/`or`/`not` with `not` > `and` > `or`, grouping, case-insensitive operators and attribute names, JSON string escapes, numbers, `true`/`false`/`null`, URN-qualified paths, sub-attributes and value filters (`emails[type eq "work"].value`, `members[value eq "…"]`). Length, nesting depth and comparison count are bounded; a parse error is `InvalidScimFilter` and answers `400 invalidFilter`. `ScimDirectoryQuery` translates the AST to Eloquent over the attributes the store holds (`ScimQueryAttributes`); anything else is `invalidFilter`, never an unfiltered result. Dates (`meta.created`, `meta.lastModified`) compare as datetimes.
- **SCIM sorting** (§3.4.2.3): `sortBy` / `sortOrder` on `/Users` and `/Groups` through the new optional `DirectoryUserSearch` / `DirectoryGroupSearch` contracts (`DirectorySearch` value object, `ScimSortOrder`). Values sort last ascending and first descending when absent, `id` breaks ties, and an attribute that cannot be sorted on is `400 invalidValue` (`UnsupportedDirectorySort`). `sort.supported` is advertised.
- **SCIM ETags** (§3.14): a weak `meta.version` and `ETag` header on every resource, moved by a per-resource revision counter (`directory_users.version`, `directory_groups.version`, migration) so two writes in one second get two tags and a group's tag moves on membership changes. `If-Match` on `PUT`/`PATCH`/`DELETE` answers `412` on mismatch; `If-None-Match` on a single `GET` answers `304`. `etag.supported` is advertised. `Scim\Support\ScimETag`.
- **SCIM `/Bulk`** (§3.7): `POST /scim/v2/Bulk` runs POST/PUT/PATCH/DELETE on `/Users` and `/Groups` through the same `ScimUserResources` / `ScimGroupResources` contracts the single-resource controllers now delegate to (`DirectoryScimUserResources`, `DirectoryScimGroupResources`), via `ScimBulkProcessor` (`DefaultScimBulkProcessor`). `bulkId` references resolve in paths and data (forward references run first; cycles and unresolvable references fail that operation with `409`), `version` is honoured as `If-Match`, `failOnErrors` stops the run, and `cbox-id.scim.bulk.max_operations` (1000) / `max_payload_size` (1 MiB) are enforced with `413` and advertised in `ServiceProviderConfig`.
- **SCIM PATCH value paths** (§3.5.2): paths are parsed by the filter grammar and value filters evaluated (`emails[type eq "work"].value`; `emails[type eq "home"]` no longer reads as the work address); URN-qualified core and Enterprise paths; a pathless `add`/`replace` with an object value; the `manager` shape Microsoft Entra ID sends; group `remove` by any value filter over `value`/`display`/`type`; `add`/`replace` of a group's `displayName` and `externalId`.
- SCIM conformance suites replaying Microsoft Entra ID's and Okta's published SCIM test cases (`ScimEntraConformanceTest`, `ScimOktaConformanceTest`).
- **Standard Webhooks signatures, per endpoint.** `SignatureScheme` (`Cbox`, the default, and `StandardWebhooks`) is stored on each endpoint (`webhook_endpoints.signature_scheme`, migration, default `cbox`). A Standard Webhooks endpoint is delivered with `webhook-id` (the delivery id, the same on every retry), `webhook-timestamp` and `webhook-signature: v1,<base64 HMAC-SHA256 of "{id}.{timestamp}.{body}">`, keyed by a `whsec_` secret minted at registration, so any Standard Webhooks library verifies it. Only the chosen scheme's headers are sent. The new `WebhookSigningSchemes` contract (bound to `DatabaseWebhookRegistry`) registers with a scheme (`registerWithScheme()`, `registerForEnvironmentWithScheme()`) and moves an endpoint between schemes (`changeSignatureScheme()`, exact-owner match) without re-minting its secret: a hex secret is losslessly `whsec_` + base64 of itself. `RegisteredEndpoint::signatureScheme()`; `DatabaseWebhookRegistry::register()` / `registerForEnvironment()` and `InteractsWithWebhooks::registerWebhook()` take a trailing optional scheme.
- **Receiver-side webhook verifiers.** `StandardWebhookSignature::verify()` and `CboxWebhookSignature::verify()`: constant-time, a tolerance window in both directions (300 s default), several signatures per header, failures as `InvalidWebhookSignature` with a stable `reason`. `StandardWebhookSignature` also signs, mints `whsec_` secrets and converts a hex secret (`secretFor()`). Held to the specification's published test vector (`tests/Fixtures/Webhooks/standard-webhooks.json`) and, for the Cbox scheme, the cross-SDK fixture.
- **RFC 9470 step-up authentication.** `AuthenticationRequirement` (`acr_values` + `max_age`) is evaluated the same way by a resource server (`assessToken()`) and by the host's `/authorize` (`fromAuthorizationRequest()`, `assessSession()`), so the authorization server never issues a token the resource that asked for it would refuse. The outcome is an `AuthenticationAssessment`: typed `AuthenticationShortfall`s (`TooOld`, `ContextNotMet`), the authorization error (`login_required` / `unmet_authentication_requirements`) and the resource server's 401 challenge. Missing facts fail closed; a shared 60-second `max_age` leeway keeps `max_age=0` satisfiable. A malformed `max_age` is `InvalidAuthenticationRequirement` (`invalid_request`).
- `BearerChallenge` gains trailing `acrValues` / `maxAge`, `withAcrValues()`, `withMaxAge()` and `insufficientUserAuthentication()`, rendering RFC 9470 §3 `acr_values` and a quoted `max_age`. Existing headers are unchanged.
- **`acr` and `auth_time` on access tokens** (RFC 9470 §6.1) for the authorization code grant and every refresh of it (always the original login's values), and `auth_time` for CIBA. `acr` is derived from the login's `amr`, never from the request. Stamped through the new optional `AuthenticationAwareTokenIssuer` contract (implemented by `JwtTokenIssuer`); a host's own `TokenIssuer` keeps working, its tokens carrying no authentication context. `AuthenticationEvent` is the value object.
- Introspection returns `acr` and `auth_time` (RFC 9470 §6.2); `Introspection::acr()` / `authTime()`.
- **LinkedIn, Bitbucket, Xero and Intuit in `ProviderCatalog`**, appended after the existing entries. LinkedIn (issuer `https://www.linkedin.com/oauth`), Xero (`https://identity.xero.com`) and Intuit (`https://oauth.platform.intuit.com/op/v1`, with Intuit's documented discovery document) are OIDC. Bitbucket is OAuth 2.0: subject `uuid`, and only a confirmed primary address from the paginated `/2.0/user/emails`.
- `Federation\Enums\TokenEndpointAuthMethod` (`client_secret_post` / `client_secret_basic`). OIDC discovery reads `token_endpoint_auth_methods_supported` (`DiscoveredOidcProvider::$tokenEndpointAuthMethods`), `OidcConnectionConfig::$tokenEndpointAuthMethod` stores the choice, and `ProviderTemplate::$tokenEndpointAuthMethod` declares it for OAuth 2.0 entries.
- `ProviderTemplate::$discoveryUrl` / `discoveryUrlFor()`; `OidcDiscovery::fromIssuer()` gains a trailing `?string $discoveryUrl` (the document must still name the issuer).
- UserInfo for catalogue providers whose id_token carries no address: `ProviderTemplate::$profileFromUserInfo`, `Contracts\OidcUserInfo` (`OidcUserInfoClient`), `Contracts\OidcTokenExchange` (implemented by `OidcClient`), `OidcTokenSet`, `OidcConnectionConfig::$userinfoEndpoint`.
- `ProviderProfileMap` gains `emailListPath`, `emailEntryAddress`, `emailEntryPrimary` and `emailEntryVerified`, for email endpoints that answer an envelope or flag confirmation per entry.
- **Enterprise IdP setup guides.** `IdentityProviderGuides` (`all()`, `find()`, `keys()`, `forProtocol()`, `directories()`, `genericDirectory()`) with `IdentityProviderGuide`, `GuideField`, `GuideReturns`, `ScimDirectoryGuide`, `ServiceProviderValues`, `GuideProtocol`, `SpValue` and `GuideReturnKind`: twenty guides (Okta, Microsoft Entra ID, Google Workspace, OneLogin, JumpCloud, PingFederate, PingOne, AD FS, Auth0, Keycloak, Duo, CyberArk Identity, Shibboleth, Oracle Cloud Infrastructure IAM, SAP Cloud Identity Services, Salesforce, LastPass, Cloudflare Access, generic SAML 2.0, generic OpenID Connect) mapping each service-provider value onto the field the IdP's admin console names, with SCIM directory guides for the nine that can push to a custom app with a bearer token. `ProviderCatalog::enterpriseGuides()` delegates; guides never appear in `ProviderCatalog::all()`, so they never become sign-in buttons.
- Docs: [Connect Microsoft Entra ID and Okta over SCIM](docs/cookbook/connect-entra-and-okta-scim.md), [Verify webhook signatures](docs/cookbook/verify-webhook-signatures.md), [Require step-up authentication](docs/cookbook/require-step-up-authentication.md), [Sign-in provider catalogue](docs/core-concepts/sign-in-provider-catalogue.md), [Enterprise SSO setup guides](docs/cookbook/enterprise-sso-setup-guides.md); the SCIM concept page, the standards matrix, feature support, token claims, the threat model and the MCP cookbook updated.

### Changed

- **SCIM: `POST /Users` with an `externalId` the directory already holds is `409 uniqueness`** (RFC 7644 §3.3), and so is a duplicate group `displayName` (`DirectoryGroupNameTaken`). They were a `201` upsert and a `500`. Both IdP conformance suites require the 409.
- SCIM filters that mix `and` and `or` are answered by the RFC's precedence instead of refused, and filters on attributes the store holds that the old parser could not read (for example `members`) are answered instead of `invalidFilter`.
- A SCIM PATCH that changes a provisioned user's `externalId` is `400 mutability`. A `remove` with a value filter such as `emails[type eq "home"]` is evaluated, and no longer clears the stored address. The Enterprise `manager` is always stored and returned as the complex attribute. `/Groups` `displayName` filters compare case-insensitively on every engine.
- `ScimSchema::meta()` gains a trailing `?string $version`; `DiscoveryController::serviceProviderConfig()` takes the `ScimBulkProcessor` whose limits it advertises.
- `ScimUserFilter` is deprecated (nothing in the package calls it); the stores use `ScimFilterParser` and `ScimDirectoryQuery`. The SCIM `UserController` / `GroupController` now delegate to `ScimUserResources` / `ScimGroupResources` and take them as constructor dependencies (container-built).
- `POST /oauth/par` refuses a `max_age` that is not a non-negative integer, or a non-string `acr_values`, with `400 invalid_request` (RFC 9126 §2.1), instead of storing it.
- An OIDC connection whose provider's discovery document lists token endpoint auth methods without `client_secret_post` now authenticates with HTTP Basic (RFC 6749 §2.3.1). Every connection saved before this keeps the body form.
- The OIDC callback reads the access token through `OidcTokenExchange` when the bound relying party implements it; `OidcCallbackController` gains a trailing optional `?OidcUserInfo`. The `email_verified` organization-domain rule moved from `OidcAssertionValidator` into `Support\OrganizationVouchedEmail`, unchanged.
- Webhook endpoints that existed before this release stay on the Cbox scheme with byte-identical headers; `WebhookRegistry` is unchanged.

### Security

- `acr` and `auth_time` are reserved access-token claims: a token-minting hook can no longer set them, so a hook cannot vouch for a second factor or a fresh sign-in that never happened.
- Webhook replay protection no longer depends on each receiver re-implementing the check: both verifiers ship and enforce the signed timestamp's tolerance window.
- SCIM filters are bounded in length, nesting depth and comparison count, and every SQL fragment the translator emits is built from literals; `/Bulk` is bounded by `maxOperations` / `maxPayloadSize`, since one bulk request counts once against the SCIM rate limit.
- OIDC UserInfo is called only after the id_token and nonce are verified; its `sub` must equal the token's (OIDC Core §5.3.2), it fills only claims the token left empty, and its verified flag passes the same organization-domain rule.
- Bitbucket: an unconfirmed primary address is not taken at all, so nobody can occupy an address they never received mail at.

### Fixed

- A SCIM resource's version no longer moves on MySQL when a write changes nothing: MySQL hands its JSON column back with the keys re-ordered, and Eloquent compared the decoded document order-sensitively, so an idempotent re-push looked like a change there and nowhere else. Revisions now compare JSON attributes by value.
- SAML sign-in reads the email from an `emailAddress`-format NameID when no email attribute is sent — the default for Okta and Google Workspace. An attribute still wins; a NameID in any other format is never read as an address.
- SCIM `caseExact` attributes (`externalId`, `id`) compare byte-for-byte on MySQL and MariaDB too: their default collations fold case, so `externalId eq "EXT-LEE"` matched `ext-lee` there and nowhere else. Compared as binary on those engines; PostgreSQL and SQLite already compared exactly.

### Dependencies

- Accepts `cboxdk/laravel-siem` `^0.1 || ^0.2`, so a host can take the 0.2 destinations (Datadog, Amazon S3, Google Cloud Storage) when it is ready for them.

## [1.22.0] - 2026-10-08

### Added

- **Host-declared protected resources.** `ProtectedResources` (bound to `ConfiguredProtectedResources`, reading `cbox-id.oauth.protected_resources`) lets a host declare resource servers it serves itself — an MCP endpoint at `{issuer}/mcp`, say — with the scopes each accepts and whether self-registered clients may use it, without registering an API row. A declared resource is an RFC 8707 audience: `resource` naming it audiences the token to it with the protocol scopes plus the requested scopes it accepts; with no `resource`, scopes belonging to exactly one declared resource pick it. `ProtectedResource` is the value object; `InvalidProtectedResource` is thrown for a declaration that cannot be served.
- **RFC 9728 path-suffixed metadata.** `GET /.well-known/oauth-protected-resource/{path}` serves each declared resource's document (§3.1), 404 for a path nothing is declared at. The root document's `scopes_supported` is read from `ProtectedResources::issuerScopes()`.
- **`BearerChallenge`**: an RFC 6750 §3 `WWW-Authenticate` builder with RFC 9728 §5.1 `resource_metadata`, every value escaped. UserInfo and the decision endpoint now use it, pointing at the root metadata document.
- **Client ID Metadata Documents** (draft-ietf-oauth-client-id-metadata-document), off by default (`cbox-id.oauth.client_id_metadata_documents.enabled`). An https URL `client_id` is resolved by `ClientIdMetadataDocuments` (`CachedClientIdMetadataDocuments`): fetched through `MetadataDocumentFetcher` (`HttpMetadataDocumentFetcher` — SSRF-guarded via `cboxdk/laravel-ssrf`, pinned, no redirects, size- and time-limited), validated (`ClientMetadataDocument`), cached for its `Cache-Control: max-age` within `min_ttl`/`max_ttl`, and described as a never-persisted `MetadataDocumentClient`. The token, PAR and revocation endpoints accept it by `client_id`; `private_key_jwt` documents authenticate by assertion against the key set at `jwks_uri`. `client_id_metadata_document_supported` is advertised when on. Failures are `InvalidClientMetadataDocument` with a stable `reason`.
- **`AuthorizationClients`** (`DefaultAuthorizationClients`): one call for the host's `/authorize` that resolves a registered client or a metadata document client into an `AuthorizationClient` — with `allowsRedirectUri()` (exact match for document clients), `consentRequired()` (always for self-registered clients) and the document's host, `client_uri` and `logo_uri` for the consent screen.
- **`mcp` dynamic registration mode**: open registration held to public clients, the `authorization_code`/`refresh_token` grants, https or loopback redirect URIs, no back-channel logout URI, and the scopes `SelfRegisteredScopes` allows (declared resources open to self-registered clients, plus the protocol scopes in `allowed_scopes`). Reserved scopes are never granted.
- `cbox-id.oauth.dynamic_registration.max_per_ip_per_hour` (default 20): a per-address hourly ceiling on `POST /oauth/register` in `open` and `mcp` modes.
- `cbox-id.oauth.resource_indicators.unknown_resources` (`accept` | `refuse`, default `accept`).
- `oauth_clients.last_used_at`, stamped by the token issuer at most once an hour, and a `cbox-id:prune` target (`retention_days.oauth_clients`, off by default) that removes self-registered clients unused for that many days and holding no live refresh token.
- `ResourceParameter` reads the one RFC 8707 `resource` off a request the same way everywhere, counting repeated keys on the wire.
- Testing: `InteractsWithOAuth::declareProtectedResource()` and `fakeClientMetadataDocuments()` (a `FakeMetadataDocumentFetcher`).
- Docs: [Protect an MCP server with Cbox ID](docs/cookbook/protect-an-mcp-server.md); the standards matrix and threat model updated.

### Changed

- `resource` is honoured on the device grant at the token endpoint (it was dropped), validated at `POST /oauth/par`, and bound for the life of a refresh token: a refresh naming a different `resource` is `invalid_target`, refused before the refresh token is consumed. `RefreshTokens::rotate()` gains a trailing `?string $resource = null`.
- A repeated `resource` (form body, query string or array) is refused with `invalid_target` — one token is never valid at several resource servers. It used to be silently collapsed to its last value.
- A malformed `resource` is now held to `ResourceIndicator` (absolute, host, no fragment, ≤ 255 characters) and its `invalid_target` carries an `error_description`. `AuthorizationCodes::issue()` refuses a malformed `resource`.
- Constructor changes on container-built classes: `RegisteredApiAudienceResolver` (`ProtectedResources`, `IssuerResolver`), `DynamicClientRegistrar` (`SelfRegisteredScopes`), `PushedAuthorizationController` (`AudienceResolver`), `ProtectedResourceMetadataController` (`ProtectedResources`); optional trailing dependencies on `RefreshTokenService`, `ClientAuthenticator` and `ClientAssertionValidator`.
- `Client::isMetadataDocumentClient()` (false on every persisted client).

- **Login lockout is on by default**: 10 failed sign-ins inside 15 minutes lock a subject for 15 minutes when no policy names a threshold. A policy's `lockoutThreshold` still wins; `cbox-id.lockout.threshold = 0` restores the old default.
- The package SAML ACS and OIDC callback return `sid` (the opaque OIDC session id) instead of `session_id`.
- The browser SSO routes (OIDC redirect/callback, SAML login/SLO) send `Cache-Control: no-store`.
- The package SAML IdP SSO endpoint answers an issuance-time refusal (including a replayed request) with a SAML error Response instead of a 500.

### Security

- A self-registered client (RFC 7591, or a metadata document) may only be audienced to a registered API, a declared resource open to self-registered clients, or the issuer; any other `resource` is `invalid_target`. Until now such a client could have a token signed by this issuer audienced to any URI it named.
- **Master-key rotation.** The `SecretBox` is now a versioned keyring: new ciphertext is `v1.<key-id>.<payload>`, where the key id is a derived HMAC of the key (never the key). `cbox-id.crypto.previous_keys` (`CBOX_ID_CRYPTO_PREVIOUS_KEYS`) keeps old keys for opening only; `CBOX_ID_CRYPTO_KEY` stays the current key. `cbox-id:crypto:rewrap` re-seals every registered sealed column onto the current key in resumable, compare-and-set chunks (`--dry-run`, `--column`, `--chunk`), and `cbox-id:doctor` warns while anything is still under a previous key. New contracts: `MasterKeyRing`, `SealedColumns` (every module registers its own sealed columns; hosts can register theirs) and `SecretRewrapper`. See [master key management](docs/security/key-management.md).
- **GDPR Art. 17 erasure.** `SubjectEraser::erase()` removes a subject's credentials, sessions, OAuth grants, memberships, role grants, API tokens, vault secrets and stored payload copies in one transaction, pseudonymises the subject row in place (id kept), records a `user.erased` audit tombstone, emits `user.erased`, and returns an `ErasureReceipt`. The pipeline is the `ErasureSteps` registry of `ErasureStep`s, one per module; hosts register their own. `SubjectPseudonymiser` is the swap point for a host-owned user store. The audit trail is deliberately not rewritten. See [erasure](docs/security/erasure.md).
- **`user.erased`** webhook event, and an outbound-SCIM `erase` operation that sends `DELETE /Users/{id}` to every connection holding a remote record of the person, whatever its deprovision policy.
- **Organization-owned SAML service providers.** `NewServiceProvider` gains `organizationId`; `saml_service_providers.organization_id` stores it (migration). Assertions to an organization-owned SP carry an `organization_id` attribute.
- **`cbox-id.lockout.*`** — `threshold`, `window_minutes`, `duration_minutes` (`CBOX_ID_LOCKOUT_*`).

- **SAML IdP apps are no longer environment-wide by accident.** An organization-owned SP is only ever asserted to active members of its organization; anyone else is refused with `SubjectNotPermitted` (`Responder`/`RequestDenied`), audited and emitted as `saml_idp.assertion_refused`. Before this, any subject of an environment could single-sign-on into any organization's SAML app. Existing SPs stay environment-wide until you set their organization.
- A refresh token is minted only for a client that may redeem it (`GrantPolicy` allows `refresh_token`). Device-only and CIBA-only clients that did not register `refresh_token` were being handed refresh tokens the refresh grant would refuse.
- The raw `auth_sessions` row key no longer leaves the server from the SSO callbacks.

## [1.21.0] - 2026-10-07

### Added

- **Management keys that can be minted by keys.** Both key tables gain provenance columns (`created_by_type`, `created_by_id`, `parent_key_id`, `rotated_from_id`, `description`, `step_up_policy`), written from the new `KeyProvenance` value object passed to `issue()`. Organization keys gain optional `scopes`, narrowing a key below its role (`OrganizationApiKey::permits()`); a key minted without them is bounded by its role alone, as before.
- **`ManagementScopes`**, the vocabulary an environment key's scopes are checked against, bound to `EnumManagementScopes` (the `EnvironmentApiScope` enum). Rebind it to add the scopes a host's own endpoints require. `EnvironmentApiKey::can()` accepts a string as well as the enum.
- **`cbox-id.management_keys.organization_prefix`**: the prefix organization keys are minted and resolved under, `cbid_org_` by default.
- **`ActionApprovals`** (`CibaActionApprovals`): ask a person to approve one action, bound to a digest of exactly that action, and spend the approval once with `consume()`. Built on the CIBA request store, so the same approval surfaces answer it; it raises `oauth.backchannel_authentication_requested` with `purpose: action`. See [Require a person's approval for one action](docs/cookbook/require-approval-for-one-action.md).
- **`cbox-id.oauth.reserved_scopes`** (`vault.manage`, `vault.lease`, `apps.manifest`, `decisions:read`): scopes no dynamically registered client may hold, refused at registration and on every save even when `allowed_scopes` names one.

### Changed

- `EnvironmentApiKeys::issue()` refuses a scope `ManagementScopes` does not know (`UnknownApiKeyScope`) instead of storing it.
- `POST /oauth/backchannel_authentication` answers `400 invalid_binding_message` for a `binding_message` over 255 characters, instead of failing on the column.

### Security

- An action approval is never redeemable for tokens: `CibaAuthenticationService::redeem()` treats a request carrying an action digest as unknown.

## [1.20.0] - 2026-09-25

### Changed

- The hash-chained audit log now runs on the new framework package `cboxdk/laravel-audit-chain` (new dependency). The append path (anchor-row serialisation, the duplicate-key / serialisation-failure retry ladder), verification and the checkpoint cross-check moved there unchanged; `DatabaseAuditLog`, `Checkpointer` and `CheckpointCommand` are now thin adapters that keep the platform's addressing (environment, scope), tables (`audit_logs`, `audit_checkpoints`), canonical hash form (`CboxIdEntryCodec`, byte-identical) and JWT checkpoint signatures (`TokenCheckpointSigner`). No migration, no re-chain, no public signature change. Golden vectors written by the previous implementation (`tests/Fixtures/audit/golden-vectors.json`) are verified and reproduced byte for byte by the new one. See [UPGRADING.md](UPGRADING.md).
- `AuditEntry` / `AuditCheckpoint` extend the package's `ChainEntry` / `ChainCheckpoint`; `CannotAppendToAuditChain` / `CannotCheckpointEmptyScope` extend the package's exceptions (still `RuntimeException`s, same messages).

### Fixed

- `AuditLog::checkpoint()` with no environment in context (the platform plane) threw a `QueryException` on `signing_keys.environment_id`. The platform chain is now signed as the `__platform__` environment, the same key the checkpoint pass uses.
- `AuditLog::verifyChain()` with no environment reported a platform chain checkpointed by the checkpoint pass as `checkpoint signature failed to verify` (a false tamper report). It now verifies with the `__platform__` environment's keys, the same lookup as signing.

### Security

- Checkpoint verification requires `typ` = `cbox-id.audit.checkpoint`. Previously any token signed by the environment's key that carried `scope`, `up_to_sequence` and `root_hash` was accepted as a checkpoint. All checkpoints laravel-id has signed carry the claim.

### Added

- The package's `audit-chain:verify` (every environment's chains, or the newest `--window` entries of each) and `audit-chain:checkpoint` operate on the platform trail; `audit-chain:keygen` is available. None is scheduled by default.
- Platform checkpoints are handed to the package's `CheckpointAnchor`, so they can be exported to an external disk (`AUDIT_CHAIN_ANCHOR=filesystem`). The default still exports nothing.
- `DatabaseAuditLog::__construct()` accepts an optional `CheckpointAnchor`; `ChainCheckpoint::fromOutcome()`.

## [1.19.3] - 2026-09-24

### Fixed

- A support session stores exactly the scopes its tokens will carry. It used to store the requested scopes (or the app's whole registration) narrowed only to the app's registration, while every token passed through the audience resolver — so once the app held a registered API's scope, a scope nobody registered (e.g. `apps.manifest`) was listed on the session and its codes but carried by no token. A set that spans two registered APIs is now refused with `InvalidAudience` before the session is created or announced. (`SupportSessionService` gains an `AudienceResolver` constructor dependency; it is container-built.)

## [1.19.2] - 2026-09-24

### Fixed

- The `roles` and `permissions` claims (access token, ID token `groups`, userinfo, decisions) are now sorted byte-wise. They were returned in whatever order the database produced, which differed between PostgreSQL and SQLite, so the same grants could sign two different tokens.

## [1.19.1] - 2026-09-24

### Fixed

- The `api_keys:read` / `api_keys:write` environment-API scope labels and the "no key prefix" refusal no longer say "customer": the keys belong to an app's users (the members of its organizations), and "customer" already means something else across the console. Labels now read "Read member API keys" / "Revoke member API keys".

## [1.19.0] - 2026-09-24

Six feature sets in one release: tenancy context (`org_role`, RBAC decisions, the membership
lifecycle, one webhook catalogue), APIs that own their scopes, app secrets and settings,
customer API keys, OIDC Back-Channel Logout, and staff roles with support sessions. Ten
additive migrations; read [UPGRADING.md](UPGRADING.md#1190) before deploying.

### Added

- **`org_role` claim — the member's tier in the bound organization.** On the access token,
  the ID token and UserInfo whenever an organization is bound and the subject holds an
  **active** membership in it (`owner`, `admin`, `developer`, `member`, `viewer`). Absent on
  `client_credentials` tokens, on tokens without an organization and for invited or
  suspended memberships. Every user grant carries it — authorization code, refresh (which
  re-reads it), device, CIBA and token exchange — and UserInfo reads it live. Reserved
  against token-minting hooks and listed in `claims_supported`. See
  `docs/reference/token-claims.md`.
- **RBAC mode on `POST /oauth/decisions`.** A body with `permission` (a key or a list) asks
  "may X do `feature:action` in org T" for the calling app, answered by the new
  `PermissionDecisions` contract from the same resolver that stamps the token's
  `permissions` claim (organization grants, ancestor roll-down, environment-wide grants;
  never another app's roles). A user token asks about itself in its own organization; a
  client token may name any `subject` but needs `decisions:read`, and a client an
  organization owns may ask only about that organization. A suspended or archived
  organization denies everything. The ReBAC mode is unchanged. See
  `docs/reference/decisions.md`.
- **Membership lifecycle verbs.** `Memberships::leave()` (refused for the only owner with
  `LastOwner::leaving()`), `Memberships::transferOwnership()` (atomic, both rows locked; the
  previous owner becomes admin; refusals carry an `OwnershipTransferRefusal` reason),
  `Memberships::owners()`, `Memberships::activeRole()`, `MembershipRole::isAssignable()`,
  `Organizations::archiveAsOwner()` and `Organizations::update(OrganizationChanges)`. See
  `docs/core-concepts/membership-lifecycle.md`.
- **Webhook catalogue.** `WebhookEventType::catalogue()` returns a typed
  `WebhookEventDescriptor` per event — group, label, a description of the event and its
  payload, the event that supersedes a legacy name, and whether the framework emits it —
  and `WebhookEventType::offered()` is what a subscription picker should show.
  `WebhookCatalogueMarkdown` renders it; `docs/reference/webhook-events.md` is generated
  from it and a test fails when the two drift.
- **New webhook events**, emitted by the framework: `membership.created|updated|deleted`,
  `invitation.created|accepted|revoked` (a re-invite announces the invitation it supersedes),
  `organization.updated` (rename, slug, settings) and `organization.deleted` (archive).
  Catalogued for the services that emit them: `api_key.created|revoked`,
  `support_session.started`. Catalogued because they were already emitted but missing:
  `user.login`, `user.reactivated`, `identity.linked`, `role.unassigned`,
  `role.assigned_everywhere`, `role.unassigned_everywhere`, `organization.archived`.
- **Environment API scopes** `members:read|write`, `invitations:read|write`,
  `roles:read|write`, `apps:read|write`, `apis:read|write`, `api_keys:read|write` and
  `support:write`, each with `label()` and `description()`, plus `writes()`,
  `isReserved()`, `offerable()` and `offerableValues()`.
- **APIs (resource servers) and the scopes they own.** New `oauth_apis` / `oauth_api_scopes`
  tables, the `Apis` contract (`DatabaseApis`), and `Api` / `ApiScope` models. An API has an
  identifier (becomes `aud`, unique per environment), an owner (`organization_id`, null =
  environment), and an optional linked app (`client_id`) whose roles and permissions tokens
  for it carry. Scope keys are unique per environment and carry `tenant_requestable`
  (default true). `InteractsWithOAuth::makeApi()` registers one in tests;
  `makeClient()` takes an `organizationId`. See
  [APIs and scopes](docs/core-concepts/apis-and-scopes.md) and the new
  [access token reference](docs/core-concepts/access-tokens.md).
- **One `AudienceResolver` for every access token.** `JwtTokenIssuer` asks it once per
  token, so authorization code, refresh, client credentials, device, CIBA and token
  exchange share one answer: registered scopes the client's owner may not hold are
  dropped; with no `resource`, `aud` defaults to the one API the scopes belong to (scopes
  of two APIs is `invalid_target`); a named API narrows the token to its scopes plus the
  protocol scopes, adds the issuer to `aud` when `openid` is present, and stamps the linked
  app's `roles`/`permissions`; free-text scopes never ride on a registered API's audience;
  nothing grantable is `invalid_scope`.
- Discovery's `scopes_supported` adds the tenant-requestable scopes of environment-owned
  APIs; dynamic registration accepts them.
- **Overlapping client-secret rotation.** An OAuth client can hold several live secrets
  (`oauth_client_secrets`: SHA-256, a four-character hint, created/expires/last-used).
  `ClientRegistry::rotateSecret($client, $graceSeconds)` mints a new `csec_` secret and
  retires the others after the grace period (0 = at once; bounded by the new
  `cbox-id.oauth.client_secrets.max_rotation_grace`, 30 days), never extending one due
  sooner. `revokeSecret()` cuts one off and refuses the last live secret of a
  shared-secret client; `secrets()` lists them as `ClientSecretSummary` (id, hint,
  dates — never the secret). Any live secret authenticates; all are compared in constant
  time on every attempt. `last_used_at` is written at most once a minute.
- **`ClientRegistry::update()` and `delete()`.** An app's settings are replaced from a
  `ClientBlueprint` — grants and `access_token_ttl` included — so token exchange can be
  enabled and disabled through the registry the consoles use. The client type and
  authentication method cannot change through update.
- **`ClientBlueprint`**: an app's configuration without its identity or credentials, as a
  deterministic, versioned JSON document. `ClientRegistry::blueprint()` exports it;
  `ClientRegistry::import()` creates a new client (new id, new secret) from it in the
  current environment. See *Promote an app between environments* in the cookbook.
- **The registry audits the app lifecycle**: `app.created`, `app.updated` (with a
  from/to of each changed field), `app.secret_rotated`, `app.secret_revoked` and
  `app.deleted`, on the owning organization's trail, with the new
  `Kernel\Audit\ValueObjects\AuditActor` a caller passes. RFC 7591/7592
  self-registration gets the same entries.
- **`cbox-id.oauth.max_access_token_ttl`** (default 86400): the ceiling on a client's own
  access-token lifetime — refused above it when set, clamped to it when minted. The floor is
  60 seconds. The deployment default is not clamped.
- `NewClient` accepts `tokenEndpointAuthMethod` and `manifestUrl`, persisted at
  registration. `Enums\GrantType` names the six grants the token endpoint implements.
- **Customer API keys.** An end-customer of an app built on Cbox ID could not get a key for
  that app's API. User API tokens (`cbid_pat_`) existed, but they were bound to no app,
  carried a coarse verb instead of the app's permissions, and only an environment key with
  `users:read` could check one. The app itself had no way to verify a key with its own
  credentials, and OAuth introspection answers `active: false` for anything the caller did
  not issue.

  A customer API key is that same credential, bound to one app (`client_id`), one
  organization and one holder, and carrying a subset of the app's permissions. It uses the
  same table, the same SHA-256-at-rest lookup by hash, and the same tenancy and revocation.
  Two caps keep it honest. At issuance, every permission must be one the holder currently
  holds for that app (`AccessChecker::forToken()`, the set an access token would carry).
  At every verification, the key's permissions are intersected with what the holder holds
  at that moment, so a demoted holder's key loses the permission on the next request. The
  key also goes inactive when the holder leaves the organization, and stays inactive if
  they are added back later. A suspended organization or a deactivated account does the
  same.

  - `CustomerApiKeys` contract (`setPrefix`, `issue`, `verify`, `find`, `revoke`,
    `forUser`, `forOrganization`). Refusals throw `CustomerApiKeyRefused` with a typed
    `ApiKeyRefusal` reason.
  - Per-app key prefix `oauth_clients.api_key_prefix`, validated by `ApiKeyPrefix`
    (`^[a-z][a-z0-9]{1,15}_(live|test)$`, root `cbid` reserved, unique per environment).
    Keys are `{prefix}_{48 base62}` and are shown once. Declaring a prefix is how an app
    opts in.
  - `POST /oauth/api-keys/verify`: the app authenticates with its own client credentials
    (the token endpoint's methods) and gets back
    `{active, key_id, sub, org, org_role, permissions[], client_id, expires_at}` for its own
    keys. Every other outcome is exactly `{"active": false}`. The endpoint is no-store and
    throttled at `cbox-id.customer_api_keys.verify_per_minute` (default 600 per IP).
  - `last_used_at` is written at most once a minute per key, and the throttle is part of
    the UPDATE's own WHERE clause.
  - Audit entries and webhook events `api_key.created` / `api_key.revoked`. Both are in
    `WebhookEventType`.

  Personal tokens are unchanged. Each model now carries a global scope for its half of
  the shared table, so neither service can resolve, list or revoke the other's rows.
  Migrations `2026_09_24_000300_bind_user_api_tokens_to_an_app` and
  `2026_09_24_000400_add_api_key_prefix_to_clients` are additive. Existing tokens stay
  personal tokens.
- **OpenID Connect Back-Channel Logout 1.0.** When a person signs out, when an administrator
  ends their sessions, when their account is deactivated, when their grants are revoked or
  when they are removed from an organization, every application that signed them in is now
  told — a signed logout token POSTed server to server — and ends its own session. Until
  now nothing told them: an application kept the person signed in until its own session
  expired, and consumers re-checked grants on every request to compensate.
  - Client metadata `backchannel_logout_uri` and `backchannel_logout_session_required`
    (§2.2) on `NewClient`, on the new `ClientRegistry::configureBackchannelLogout()`, and
    through Dynamic Client Registration (register, read and RFC 7592 update). HTTPS only;
    plain HTTP on `localhost`; no fragment, no credentials. Refused out loud, never dropped.
  - `sid` on the ID Token (and on a refreshed one), when the host passes the new
    `sessionId` argument to `AuthorizationCodes::issue()`. It is a SHA-256 derivation of the
    session id, not the id itself, so relying parties never see the host's row key.
  - Logout tokens per §2.4 — `iss`, `aud`, `iat`, `exp` two minutes out, a fresh `jti` per
    attempt, the `events` member, `sub` and/or `sid`, no `nonce`, `typ: logout+jwt` — signed
    with the environment's ID Token key.
  - Delivery by a queued job (`DeliverBackchannelLogout`) through the SSRF guard (pinned
    DNS, no redirects, HTTPS only; `cbox-id.oauth.backchannel_logout.verify_url`), with short
    timeouts, retries by release with backoff (10 s, 1 min, 5 min, 15 min; five attempts),
    queued after commit, and every final outcome in the audit trail as
    `oauth.backchannel_logout.delivered` / `.failed` with the reason.
  - Triggers: every `SessionManager::revoke()` / `revokeAllForUser()` (through the new
    `Identity\Contracts\LogoutPropagator`), the new `RefreshTokens::withdrawAccess()`,
    `revokeForUserAndClient()`, `Subjects::deactivate()`, and `organization.member_removed`.
    `RefreshTokens::revokeForUser()` deliberately does NOT notify anyone — see Changed.
    Hosts that end sessions another way call `BackchannelLogout::sessionEnded()` /
    `subjectSignedOut()`.
  - Discovery advertises `backchannel_logout_supported` and
    `backchannel_logout_session_supported`, and `sid` in `claims_supported`.
  - `Identity\Contracts\SignedInSession`: bind it and RP-initiated logout without a verified
    `id_token_hint` ends this browser's session row too, instead of only clearing the cookie.
  - `oauth_session_participants` is pruned by `cbox-id:prune` once its session has ended
    (`cbox-id.prune.retention_days.oauth_session_participants`, default 30).
  - Recipe: [Receive back-channel logout](docs/cookbook/receive-back-channel-logout.md).
- **Staff roles.** Roles gain `tenant_assignable` (default `true`, so no existing role
  changes). `false` marks a staff role that the organization plane never lists and never
  accepts: `Roles::tenantAssignableRoles()`, `assertTenantAssignable()` and
  `assignAsTenant()` are the tenant plane's list and guard, built on one `Role` scope so
  the two cannot drift. `assign()` stays the environment plane's call — how an environment
  administrator gives staff rights inside one customer. App manifests declare it per role
  as `"tenant_assignable": false`; the value must be a JSON boolean. It enters the
  manifest checksum only when `false`, so every existing manifest hashes to the same bytes
  in every SDK (new fixture case `staff_role`). `Roles::define()` and `updateRole()` take
  the flag. `RoleNotTenantAssignable` extends `UnknownRole`.
- **Environment-wide grants of one app's role.** `Roles::assignEverywhere()` accepts any
  non-orphaned role no organization owns. An app-declared role granted everywhere is
  stamped into that app's tokens only; an app-agnostic role into every app's. The two-app
  leak test fails if the token issuer's client filter is removed.
  `role.assigned_everywhere` / `role.unassigned_everywhere` carry `client_id`.
- **Access reviews of environment-wide grants.** `AccessReviews::open(null, …)` reviews
  every environment-wide grant (`AccessKind::EnvironmentRole`), and revoking one calls
  `Roles::unassignEverywhere()`. `certify`, `revoke` and `close` take `null` for such a
  campaign. An organization's campaign never includes them, and null matches only the
  environment's campaign. New `Roles::assignmentsEverywhere()`.
- **Support sessions (RFC 8693 `act`).** `SupportSessions::begin()` lets the vendor's
  staff (the app's own `support:impersonate`, held environment-wide) or an environment
  administrator (the caller asserts it) sign in to one first-party, environment-owned app
  as an active member of an active organization, for a required reason and at most an hour
  (`cbox-id.oauth.support_sessions.max_ttl` can only lower it). The app completes an
  ordinary code exchange. Its access and ID Tokens carry `act: {sub}`, it gets no refresh
  token, and nothing outlives the session. `issueCode()` mints further codes for the
  session's own actor, and `end()` consumes outstanding codes and revokes every token the
  session minted. Starting and ending are audited on the organization's trail and the
  environment's. `support_session.started` is emitted to the organization and added to
  the webhook catalogue. New contract `StaffAccess` (built-in: `DatabaseStaffAccess`;
  `external` driver: `NullStaffAccess`, which denies).

### Changed

- **The legacy `organization.member_*` / `organization.invitation_*` events are still
  emitted** beside the new `membership.*` / `invitation.*` ones — provisioning and usage
  metering key off them — so a `*` subscriber receives both. They are marked legacy in the
  catalogue and no longer offered to new subscriptions.
- **`directories:read|write` are reserved**: still honoured on keys that hold them, no longer
  offered for new keys.
- **Nine catalogued webhook events that were only ever audited are now delivered.**
  `domain.added|removed|verified`, `connection.activated`, `vault.grant.created|revoked`,
  `vault.secret.revoked` and `governance.access.revoked` were offered to subscribers and
  recorded on the audit trail, but nothing put them on the event bus, so a subscriber
  received nothing. Each is now emitted where its change happens (payloads in
  `docs/reference/webhook-events.md`; never a credential). `connection.activated` is also
  audited now, once per actual activation. `organization.settings_updated` is emitted as a
  legacy name beside `organization.updated` and no longer offered. `domain.verified` also
  starts counting toward the `DomainVerified` usage metric, which was mapped to it but never
  fed. `WebhookEventType::isEmitted()` is true for every case; a test fails if a case is
  catalogued without an emitting source.
- `Invitations::revoke()` takes an optional `$revokedBy`, locks the row, records
  `organization.invitation_revoked` on the audit trail and is idempotent.
- A refresh token now records the access token's **granted** scopes and resolved audience
  instead of the grant's requested ones, so a refresh can never widen either.
- Token exchange echoes the scopes the new token actually carries (RFC 8693 §2.2.1); it
  echoed the inherited set even when the exchanging client's registration narrowed it.
- `IssuedToken` gains a trailing `?string $audience`. `JwtTokenIssuer` takes an
  `AudienceResolver` and `DynamicClientRegistrar` an `Apis` (both container-resolved).
- **Registration refuses incoherent settings** with `InvalidClientMetadata`: a grant the
  token endpoint does not implement, token exchange on a public client (also on RFC 7591
  registration and RFC 7592 update), an `access_token_ttl` outside the bounds, and an
  authentication method that contradicts the client type or key set.
- `oauth_clients.secret_hash` is deprecated: a mirror of the newest live secret, never read
  to authenticate. See UPGRADING.md.
- An RFC 7592 update to `none` or `private_key_jwt` revokes every secret of the client; a
  move back to a secret method mints a fresh one.
- `Client` no longer serializes `secret_hash` or `registration_access_token_hash`.
- **Removing a person from an organization now revokes the refresh tokens they held in it.**
  A new framework listener on `organization.member_removed` calls
  `RefreshTokens::withdrawAccess($user, $organization)`. Before, the membership and role
  assignments went and the organization-scoped refresh tokens kept refreshing.
- **New `RefreshTokens::withdrawAccess()`: revoke AND sign the person out of the
  applications that held the grants.** It is what deactivation, an administrator's password
  reset and membership removal now call. `revokeForUser()` is unchanged — it revokes
  refresh tokens and notifies nobody — because hosts call it on every role assignment and
  unassignment purely so the next token carries the new claims; propagating logout there
  would sign people out of every application whenever an administrator adjusted a role.
- A user API token (`cbid_pat_`) now stamps `last_used_at` at most once a minute, like
  customer API keys: `resolve()` runs on every authenticated request and wrote the row
  every time.
- `ClientBlueprint` carries `backchannel_logout_uri`, `backchannel_logout_session_required`
  and `api_key_prefix` (optional on the way in, so an earlier document still reads), with
  `withBackchannelLogout()` / `withApiKeyPrefix()`. `ClientRegistry::update()` applies them
  and `import()` creates with them; a prefix already declared by another app in the target
  environment is refused, not dropped. `NewClient` gains `apiKeyPrefix`.
  `configureBackchannelLogout()` records `app.updated` when the setting changes.
- **A permission's `tenant_assignable` now counts toward the manifest checksum**, so a deploy
  that only opts a permission in to (or out of) tenant self-serve re-syncs; before, the
  unchanged checksum skipped the sync and the flag never reached the catalogue. Added to the
  canonical form only when `true` (a permission's non-default), so every manifest that does
  not opt a permission in hashes exactly as before. A manifest that DOES declare
  `"tenant_assignable": true` on a permission hashes differently once and re-syncs once; SDKs
  computing the checksum must add the same marker (new `self_serve_permission` fixture case).

### Security

- **Membership reads and writes no longer depend on the tenant scope alone.** `add()`,
  `of()`, `changeRole()`, `remove()`, `leave()`, the last-owner count and the new transfer,
  owner-archive and `activeRole()` queries now bind `organization_id` in their `WHERE`
  clause, and `add()` states the organization on the insert. Under
  `TenantContext::withoutScope()` — provisioning jobs, backfills — the scope-only versions
  deleted a person from every organization on `remove()`, counted other organizations'
  owners (so the last-owner guard could not fire), re-tiered or returned a membership in a
  different organization, and failed to insert at all in `add()`; a transfer could have
  promoted a member of another organization. Each binding was removed in turn and a
  suspended-scope test went red.
- **A tenant could mint a token for someone else's API.** Custom scopes were unowned free
  text on each client and `resource` was only checked for being an absolute URI before it
  became `aud`, so an organization administrator could put `tax:assess` on their own
  client, request `resource=<the tax API>`, and receive a signed token carrying exactly the
  `aud` and `scope` that API checks. Once the API is registered, its scopes can only be held
  by clients its owner allows — enforced when a client is saved (by any writer) and again
  at issuance for rows written before — and unregistered scopes can never ride on its
  audience.
- **Dynamic registration can no longer be used to claim a registered scope.** A
  self-registered client counts as a tenant, not as the environment, even though its owner
  column is null, and `allowed_scopes` cannot widen what a registered API allows.
- **An environment-wide staff role no longer leaks into every app's tokens.** The only role
  that could be granted everywhere was an app-agnostic one, so one app's "Support" role was
  stamped into every other app's tokens in the same environment.
- **Tenants cannot hand out staff roles**, directly or through a directory group mapping
  (the customer's IdP decides who is in a group). A mapping whose role later becomes
  staff-only has its pushed grant withdrawn at the next reconcile.
- **Environment-wide grants were never reviewed.** Access-certification campaigns belonged
  to one organization, so the largest grants in the system appeared in no campaign.
- **`act` is a reserved claim** that a token-minting hook can neither forge nor rewrite.
  Token exchange refuses a subject token carrying `act`, because the exchanged token
  would drop it and restart the lifetime. Introspection returns `act`.

## [1.18.1] - 2026-08-27

### Fixed

- **`legacy_login_declarations.client_id` was four characters too narrow, and the feature
  did not work on either server engine.** The column was declared `string('client_id', 26)`
  — the ULID width, taken from the three genuine ULID columns above it in the same table.
  A client id is not a ULID: `ClientRegistryService` mints `'cid_'.Str::ulid()`, which is
  thirty characters.

  PostgreSQL refused the insert outright — `SQLSTATE[22001] value too long for type
  character varying(26)` — so declaring a legacy login through the manifest was impossible.
  MySQL in strict mode refused it the same way; without strict mode it truncated the id to
  a prefix matching no client, so the console could never name the app that proposed the
  URL. SQLite ignores declared widths entirely.

  The create migration is corrected and
  `2026_08_26_000100_widen_the_legacy_login_client_id` repairs an install that already ran
  it. Both state a width rather than a delta, so running both is harmless. There is no
  backfill and none is possible: on the engines where the column was wrong, no row was ever
  written.

  **Why the engines matrix did not catch it.** The one test that writes this row declared
  with `'client-a'` — eight characters, and nothing the registry could mint. A fixture
  shaped unlike the data it stands for takes the engines' opinion out of the run. It now
  mints ids the way the product does, and asserts the id arrived at full length, which is
  the half a strict-mode-off MySQL would otherwise lose silently. `SchemaPortabilityTest`
  gained a second sweep — "never declares an id column too narrow for the id it holds" —
  that reads the prefix off `ClientRegistryService` rather than hard-coding thirty.

- **`sbom.json` did not describe 1.18.0.** The committed dependency set listed
  `getallheaders` and was missing `polyfill-php82` — an upstream package swapped a
  transitive dependency and the SBOM was never regenerated. CI said so: the tag-only
  "SBOM dependency set is up to date" gate is exactly this check, and it failed on the
  `v1.18.0` tag. Regenerated from a fresh resolve. The published 1.18.0 artifact keeps
  the SBOM it shipped with, because a release's provenance record is part of what
  shipped; this corrects the record from the next tag forward.

## [1.15.0] - 2026-08-18

### Fixed

- **SCIM attribute names are now read case-insensitively on POST and PUT.** RFC 7643 §2.1
  is explicit that attribute names are case-insensitive, and PATCH honoured it — the path
  is lowercased before matching — while create and replace read `userName`, `displayName`,
  `members` and the `name.*` parts with exact casing straight off the request. A
  conformant provisioner spelling them differently had its values silently read as empty:
  a user created with no username (refused at the edge as "userName is required"), or a
  group replace dropping its entire member list. The same client, against the same server,
  worked on PATCH and failed on POST.

  Only the NAMES are case-insensitive. Whether two userNames differing by case are the
  same account is a separate question the directory already answers with its
  `user_name_lower` index, and this does not touch it.

### Security

- **A client's registered scopes are now a ceiling for every token, not just the access
  token.** `JwtTokenIssuer` has always filtered a request down to what the client holds —
  but the device and CIBA grants stored the REQUESTED scopes verbatim, and the token
  endpoint read those raw scopes to decide whether to mint a refresh token and what to put
  on it. So a client registered for `openid` alone could ask a device grant for
  `openid offline_access`, receive a correctly downscoped access token, and a refresh
  token anyway — carrying a scope its registration explicitly withheld, and rotating
  indefinitely. The same held for the id_token via `openid`.

  Both grants now apply the ceiling at creation (`GrantedScopes`), so no grant ever exists
  holding scopes the client cannot have and every reader downstream inherits one answer
  instead of deriving its own.

  **BREAKING (error paths only):** an over-broad request is now REFUSED with
  `invalid_scope` (RFC 6749 §4.1.2.1, inherited by RFC 8628 §3.2 and CIBA) rather than
  quietly narrowed. These grants are machine-initiated — the request arrives before any
  user code or approval prompt exists — so a 400 costs a developer one clear error at
  integration time instead of a token that silently does less than they asked for. The
  authorization-code path deliberately keeps filtering quietly: a person is waiting there,
  and refusing mid-flow strands them.

## [1.13.0] - 2026-08-18

### Changed

- **The role lifecycle can be fenced on an organization.** `updateRole()`,
  `attachPermission()`, `revokePermission()` and `deleteRole()` resolved by primary key
  under the environment scope and nothing else, which made the tenant boundary something
  every caller had to remember rather than something the query enforced: a surface that
  correctly checked "may this administrator manage organization A" and then passed an id
  belonging to organization B mutated B's role. `grantPermission()` has taken the
  organization and fenced on it since it was written — its own comment reads *"never grant
  onto another tenant's role"* — and these four simply never got the same treatment.

  All four now take an optional trailing `?string $organizationId`. Null still means the
  environment plane, which is exactly what its absence has always meant, so existing
  callers are unaffected; a caller that passes one gets the fence. Nothing shipped was
  exploitable — cbox-id's console resolves through an ownership-scoped set before it calls
  — but this package has more than one consumer and a contract that invites the mistake
  will eventually get it.

### Fixed

- **A configured base domain with a leading dot reserved nothing.** `.cboxid.com` is how a
  cookie domain is spelled and how most DNS documentation spells "and everything under
  it", so it turns up in `cbox-id.environments.base_domains` — and the reservation check
  builds `'.'.$base`, which for that value is `..cboxid.com` and matches no hostname at
  all. The apex stopped being reserved and every subdomain with it, silently, with the
  config looking exactly right on screen: a tenant could claim the platform's own
  hostname as a custom domain. `TrustedHosts` and `ManageCustomDomain` in the host
  application already stripped the dot; this was the copy that did not, and it is the one
  that decides what a tenant may CLAIM rather than what gets served.

### Security

- **Deprovisioning now deprovisions.** `deactivate()` revoked refresh tokens and stopped
  there, and no other login path asked whether the person still had an account —
  `UserStatus` appeared nowhere in the OAuth module, nowhere in the passkey verifier and
  nowhere in the SAML IdP. The exception that says otherwise has existed the whole time:
  `AccountInactive`'s docblock reads *"revoking existing sessions is not enough if the
  login paths don't also refuse"*. Federation login applied it. Nothing else did.

  Four doors are now closed. Deactivation revokes the **access-token rows** as well as the
  refresh grants, so everything already in flight dies with the account. Introspection
  refuses a token whose subject is known and no longer Active, which covers UserInfo, the
  decisions endpoint, `/frontend/v1/session`, the introspection endpoint and token
  exchange in one place rather than five that can drift. `Passkeys::authenticate()`
  refuses a credential whose owner is inactive — the credential nobody collects on the
  last day, because it lives in a laptop's secure enclave. And the SAML IdP refuses to
  assert an identity for an account that can no longer sign in.

  The compounding case was token exchange: RFC 8693 took a live access token and minted a
  fresh one, so "valid until it expires" renewed itself for as long as the holder kept
  asking. A leaver's connected application never lost access at all.

  Introspection asks whether the subject is *known and suspended*, deliberately not
  `isActive()`, which answers false both for "disabled" and for "no such account". Only
  the first is a reason to refuse a token; subjects are never hard-deleted here.

### Tests

- **Four guards that could not fail.** Found by mutation, not by reading. Deleting the
  refresh token's `client_id` binding left all 1805 tests green — so the one check
  standing between two clients' grants was unconstrained, and any client that came into
  possession of another's refresh token could rotate it into a grant of its own. Deleting
  either of token exchange's `resource` checks (RFC 8707) did the same.

  Two of the tests written for this were themselves too loose on the first pass, and
  mutation caught that too: asserting `toThrow(InvalidTokenExchange::class)` passes
  whether the liveness guard is present or not, because the exchange falls through to
  `intendedFor()` and throws the same class for a different reason. They assert the
  message now. Noted here because the lesson is the finding.

## [1.12.0] - 2026-08-18

### Security

- **An audit stream is owned by an organization, and delivers only that organization's
  entries.** A stream was environment-owned and nothing more: every entry recorded
  anywhere in the environment was mirrored to every enabled stream in it. That was right
  while only an operator could configure one — and the console has since put log streaming
  on the ORGANIZATION plane, on the fair argument that shipping an audit trail to a SIEM is
  a compliance obligation the organization carries. Together they meant an administrator of
  organization A registered their own endpoint and started receiving organizations B and
  C's sign-ins, role changes and member events: not a leak anyone had to work for, the
  feature working exactly as built on a plane that was never in its design.

  `log_streams` gains a nullable `organization_id`. Null keeps meaning what it meant — the
  environment's own stream, receiving everything, configurable from the environment plane
  alone — so existing rows are left as they are rather than backfilled with an owner none
  of them has. `AuditStream::scopeDeliverableFor()` decides what an entry reaches;
  `scopeOwnedByOrganization()` decides what a console may list and manage, and the
  difference between the two IS the control: an organization is delivered the
  environment's streams' attention and must never be able to pause them.

  A platform-level entry (no organization) reaches the environment's streams only, because
  there is no tenant it belongs to.

### Changed

- `StreamingAuditLog` no longer takes a `LogStreams`. It queries `AuditStream` directly,
  because the organization boundary is this package's column and not the underlying
  engine's — the `owner_key` seam stays unused, as its docblock always said.
- `InteractsWithAuditStreaming::registerAuditStream()` takes an optional `$organizationId`,
  so a test can build the two-tenant case the fix exists for.

## [1.11.0] - 2026-08-18

### Security

- **`/frontend/v1/session` asked nothing of the token but that it be live.** It read the
  bearer straight off the `Authorization` header, introspected it, and answered with the
  holder's id, name and email address. `/oauth/userinfo` next door asks three further
  things, and every one of them was a way in: a token minted for a customer's own API
  (RFC 8707 `resource`) could be replayed here by that API to learn the identity of the
  person who granted it; a pure API token carrying no `openid` scope was never an identity
  token at all; and a DPoP-bound token — whose entire premise is that it is worthless to a
  thief without the key — worked here on its own, because this was the one door that
  skipped the proof. The endpoint now requires the issuer audience, the `openid` scope,
  and a valid DPoP proof for any token carrying `cnf.jkt`; `enforce()` returns immediately
  for an ordinary bearer, so nothing changes for clients that never asked to be
  sender-constrained. These three refusals answer `401` rather than `{"user": null}`:
  signed out is still a state and not an error, but a rejected token must not render
  identically to a logged-out visitor.

- **Federation start URLs are checked before a browser is sent to one.** An organization's
  OIDC `authorization_endpoint` and SAML `idp_sso_url` are the one tenant-configured value
  this platform puts in a `Location:` header, and they were used exactly as typed. The
  destination is somebody else's IdP by design, so the host cannot be constrained — but
  the shape can, and `BrowserStartUrl` now requires https, refuses `javascript:`/`data:`
  and anything without a host, refuses embedded credentials
  (`https://acme.okta.com@evil.example/` reads as Okta and resolves to evil.example), and
  refuses a fragment. Without it, an ordinary SSO connection was an open-redirect
  primitive flying this platform's own domain. The check is on the READ path, so
  connections already stored are covered; a connection that fails it now answers `502`
  (OIDC) or `422` (SAML) with a message an administrator can act on, instead of a 500, and
  the SAML path no longer leaves an authn-request row behind for a login that cannot
  happen.

### Changed

- **BREAKING: reach beyond one tenant is a different call, not a different argument.**
  `WebhookRegistry::register()` and `ExternalActions::register()` took the owning
  organization as a nullable parameter where `null` meant "every organization in this
  environment" — a webhook endpoint fed every tenant's members joining, sign-ins failing
  and roles changing; an external action consulted at `token_minting`, where it can refuse
  issuance, for all of them. `ExternalActions::register()` went further and DEFAULTED that
  argument to `null`, so a caller who simply left it off got the widest scope the platform
  has. Both `register()` methods now take a non-nullable `string $organizationId`, and the
  platform-wide case has its own method — `registerForEnvironment()` — which cannot be
  reached by a variable that happens to be null and whose callers are one grep away. The
  console's environment plane is the only production caller of either.

  Upgrading: `register($orgId, …)` is unchanged when `$orgId` is a string. Replace
  `register(null, …)` with `registerForEnvironment(…)`. The `InteractsWithWebhooks` and
  `InteractsWithExternalActions` test traits keep their nullable shorthand — a fixture
  table where one row is environment-wide is exactly what it is for.

## [1.10.0] - 2026-08-15

### Added

- **Dynamic Client Registration accepts `private_key_jwt`.** Discovery has advertised it in
  `token_endpoint_auth_methods_supported` at the token, revocation and introspection
  endpoints since those documents were written; `DynamicClientRegistrar::AUTH_METHODS`
  listed three methods and not that one. A conformant client read the metadata, asked for
  the strongest method the server claimed, and got `400 unsupported
  token_endpoint_auth_method` — for a capability that was complete behind the door.
  `ClientAuthenticator` has always verified the assertion and `ClientRegistry` has always
  stored a JWK Set in place of issuing a secret. Only the way in was shut.

  Register with `token_endpoint_auth_method: "private_key_jwt"` and the key set inline as
  `jwks`. A registration naming that method without keys is refused rather than minting a
  client holding neither credential, and `jwks` on any other method is refused rather than
  stored and never read.

  `jwks_uri` is **refused**, not ignored. Fetching a registrant-chosen URL from an endpoint
  that is unauthenticated in `open` mode is a server-side request forgery primitive handed
  out by a public API; ignoring it silently would register a client whose keys are never
  read, which it discovers when every assertion it signs is rejected for no stated reason.

### Fixed

- **The RFC 7592 client document reports the auth method the client actually has.** It
  derived `token_endpoint_auth_method` from the client's TYPE, so every confidential client
  was told `client_secret_basic` — including a `private_key_jwt` client, which holds no
  secret to put in a Basic header, in the very response completing its registration. The
  registered `jwks` is echoed too, so a key rotation can be read back.

## [1.9.0] - 2026-08-15

### Added

- **Manual permissions can be owned by an organization.** `permissions` gains a nullable
  `organization_id`, and `Permission` gains the pair of predicates that fence it:
  `visibleToOrganization()` — a tenant's own rows plus the environment's shared tier, which
  their roles are composed from — and `ownedByOrganization()`, which is what an edit or
  delete target must be resolved through. The two are deliberately not the same query; a
  console that authorized writes with the visibility one would hand every tenant the whole
  shared tier to delete.

  The catalog previously had no tenant tier at all. A console that offers permission
  authoring to an organization administrator — the usable shape, since roles are made of
  permissions — wrote every row into the environment-wide tier: one tenant could rename a
  key a peer's roles were built from, and deleting one cascades the `role_permission` rows
  for every role in the environment. Found by a third-party review of the console that
  consumes this package, not by this package's own suite, which had no test for a boundary
  the schema could not express.

  The migration is additive and does not backfill: existing rows keep the shared meaning
  they were authored under, because roles across the environment may already bind them and
  a guessed owner would silently revoke live grants. `UPGRADING.md` has what a host
  rendering its own permission console must apply.

## [1.8.0] - 2026-08-12

### Added

- **`SignedInSubject`** — who is signed in to this browser, as the HOST understands it.
  The package's logout endpoints asked `auth()->id()` directly, which is a guess: an
  application that keeps its own session (which any host with a subject/operator/environment
  split does, because a guard models one identity and it has three) answers null to it
  forever. The default implementation still reads the guard, so a host using it sees no
  change; a host that does not now has somewhere to say so.

- **`AuditReader::count()`** — how many entries a filter matches, without reading any. The
  compliance console rendered one number by cursoring through a subject's entire audit
  history twice, 200 rows at a time, on a live-updating input.

- **Certification-item reads are fenced to the campaign's own organization.**
  `CertificationItem` is environment-owned and not tenant-owned, and organizations share an
  environment — so `where('campaign_id', …)` alone made the id the whole authorization, and
  the fence lived in one console's discipline. `AccessReviews`' three item readers now carry
  the predicate themselves.

- **`Projects` gained owner-carrying verbs** — `renameForOrganization()`,
  `suspendForOrganization()`, `reactivateForOrganization()`. `Project` is the one model in
  the hierarchy with no global scope at all, so `rename($id, …)` is a write across every
  customer's projects fenced only by each caller remembering to resolve first. The bare
  verbs are deprecated.

- **`SyncAppManifestJob` restores the environment it borrowed.** It used `set()` rather
  than `runAs()`, so on a long-lived worker the next job started inside the last client's
  environment.

- **`Memberships::userIdsForOrganization()`** — the subject ids of an organization, for a
  caller that only wants to filter by them. Two module pages built a `whereIn` by
  hydrating every membership and reducing it to `pluck('user_id')`, one of them twice per
  render. The subquery a reader would reach for instead is genuinely unavailable:
  `Membership` is tenant-owned, so an unwrapped one meets `TenantScope`'s deny-by-default
  and matches nothing.

- **`AccessReviews::paginateItemsFor()` and `countItemsFor()`** — a campaign's snapshot is
  one row per role assignment PLUS one per membership in the organization, so it grows
  with the customer's end-user count. `itemsFor()` reads all of it, which is right for a
  batch job and wrong for a reviewer's screen; and counting one by loading them all was
  the only way to answer "how many items".

- **`AuditLog::headSequence()`** — where a scope's chain ends, so a caller can verify a
  WINDOW. `verifyChain()` reads and re-hashes every row in its range, which is right for
  an auditor and wrong for a console page that re-renders on every keystroke; without this
  the only window anyone could name was "all of it".

- **Per-endpoint client-authentication metadata.** `revocation_endpoint_auth_methods_supported`
  and `introspection_endpoint_auth_methods_supported` are now published, because they
  differ: revocation accepts a public client, introspection does not.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Global sign-out now requires a verified `id_token_hint`.** `/oauth/logout` is
  unauthenticated by design — a relying party reaches it by redirecting the browser — and
  it answers GET. Once the previous release made the revocation actually fire on a host
  with its own session, "revoke every session this browser's owner holds" became something
  any page could cause by sending somebody through a link: no credential, nothing minted,
  a denial of service against every user of a deployment. The teardown now fires only when
  a hint this server verified names the person actually holding the browser; without it,
  only that browser is signed out. Introduced and fixed before release.

- **A federated `email_verified` is carried only for a domain the connection's owner has
  proven.** A connection is configured by a CUSTOMER — they choose the issuer, so they can
  point one at an IdP they run and assert `email: ceo@somebody-else.com, email_verified:
  true`. Since `email_verified` is exactly the claim a downstream relying party uses to
  decide two accounts are the same person, carrying it unconditionally would let any tenant
  mint a verified address in another company's domain. Domain verification is the boundary
  this platform already uses to decide an organization speaks for a domain, so it is the
  one applied here. Introduced and fixed before release.

### Fixed

- **RP-initiated logout revoked nothing on a host with its own session.** `/oauth/logout`
  is OIDC's global sign-out, and it resolved the subject with `auth()->id()`. On a host
  that never populates Laravel's guard that is always null — so the endpoint cleared the
  browser's own session, answered 200 and redirected, and the revocation behind it never
  ran. Logout looked correct while other devices stayed signed in and the person's own
  session list went on showing sessions they believed they had ended. A relying party
  using this as global sign-out got success and no global sign-out. Now resolved through
  {@see SignedInSubject}; the SAML IdP's plain-logout branch had the same defect and the
  same fix.

- **An outbound SCIM connection using OAuth2 client credentials retried forever instead of
  failing.** A connection with no token URL — which is every one the console could
  register, because it had no fields for the three values `HttpScimClient` reads — failed
  on the empty URL, was classified as a transport error, and backed off and retried until
  every queued joiner and leaver was exhausted. Nothing about waiting was going to supply a
  field that did not exist. A connection that cannot authenticate is now a PERMANENT
  failure (`ScimResult::misconfigured()`), so it dead-letters where an operator can see it.

- **`MfaRequirement::Off` did nothing.** "Not offered" is a setting an administrator can
  choose on the auth-policy screen, and the enum case appeared exactly once in the
  codebase — its own declaration. The only behavioural reader compared `!== Required`, so
  `Off` and `Optional` were the same thing everywhere. `MfaMandate::offersEnrolment()` is
  the reader. Enrolment only: turning it off does not disarm a factor somebody already
  has, which would quietly weaken the accounts most likely to care.

- **A public client could not revoke its own tokens.** `/oauth/revoke` required a client
  secret, and a PKCE client authenticates with `none`. Every browser SDK that revokes on
  sign-out — AppAuth-JS, oidc-client-ts, angular-auth-oidc-client — got `401
  invalid_client`, swallowed it, and left the refresh token valid for its full lifetime
  after the person pressed sign out. On a deployment whose own discovery document
  advertises `none`. Nothing is weakened: RFC 7009 §2.1 scopes a revocation to the calling
  client, which was already enforced, so the new capability is "destroy a token you are
  holding". Introspection stays confidential-only — it answers questions about a token
  rather than destroying one, and an unauthenticated answer is an oracle.

- **A federated address the provider had verified was stored unverified, forever.**
  `ProviderProfileMap::$emailVerified` named where nine catalogue entries put this and
  nothing read it. A federated account has no local verification flow to finish, so every
  Google, Entra, Okta and Apple account stayed unverified permanently — and our own
  `/oauth/userinfo` reported `email_verified: false` to every relying party about an
  address the upstream IdP had proven. Only an explicit `true` carries over; a provider
  that says nothing still yields an unverified address. This is not an account-takeover
  path: `resolveFederated()` refuses outright to attach a new identity to an existing
  account by email.

- **Sign in with Apple lost the person's name permanently.** `name` never appears in
  Apple's id_token — it arrives in a `user` form field on the FIRST authorization and
  never again — so a callback reading only `code` and `state` created every Apple account
  with a null name, recoverable only by revoking the app in Apple ID settings and starting
  over. `ProviderTemplate::$profileOnFirstAuthorizationOnly` declared this and nothing read
  it; `FirstAuthorizationProfile` is now the reader. The field is unsigned, so it is a
  fallback only: a name the assertion carried always wins.

- **The CSRF exemption on the OIDC callback excluded nothing.** Laravel 13's `web` group
  holds `PreventRequestForgery`; `VerifyCsrfToken` and `ValidateCsrfToken` are deprecated
  SUBCLASSES of it, and `Router::resolveMiddleware()` matches an exclusion in one direction
  only. So the route registered to accept Apple's cross-site POST answered 419 to it —
  invisibly, because `PreventRequestForgery::handle()` returns early under
  `runningUnitTests()` and every federation test stayed green. There is now an assertion on
  the registration rather than on a request.

- **A segregation-of-duties scan cost two queries per person holding a role.** It read the
  organization's assignments, reduced them to distinct subjects, then asked
  `violationsFor()` about each — which fetches the subject's assignments and the applicable
  policies for itself. Both reads are hoisted; the policy set is identical for every
  subject in the organization by construction.

- **A host that resolved to nothing was the one answer never cached, and the cheapest to
  aim at.** Host→environment resolution runs before any endpoint logic on every request:
  2–3 database round trips, cached for real tenants and never for an unmapped host. A
  wildcard DNS record or a scanner therefore bought full lookups per request against the
  table the whole platform resolves through, while every paying tenant's host cost zero.
  A refusal is now remembered for ten seconds — a tenth of the positive TTL — which
  bounds the flood without changing the off-switch: suspension still cuts traffic on the
  very next request, and account reactivation still restores it on the next one, because
  the account writer now forgets the hosts as well as the environments.

- **Sign in with Apple could not complete, and had never been able to.** The catalogue
  offered it, the setup form had fields for it, and an ES256 client-secret minter sat
  fully tested next to the flow — with nothing calling it. Three declarations on the
  provider template were inert: `secretKind: SignedJwt`, `responseMode: 'form_post'`, and
  the redirect URI's method. The token exchange sent whatever the administrator had been
  forced to type into a "client secret" field for a provider that issues none; the
  authorization request never asked for the response mode Apple switches to by itself the
  moment a scope beyond `openid` is requested; and the callback then arrived as a
  cross-site POST at a GET-only route. Each failure looked like something else — a wrong
  client id, a cancelled sign-in, an expired link.

  `OidcClient` now mints the assertion per request from the connection's own key material
  (`SigningKeyCredential`, carried through `OidcConnectionConfig`), sends `response_mode`
  when the catalogue declares one, and the callback accepts POST. The choice is made from
  the connection's material rather than its provider name, so a hand-configured OIDC
  connection can authenticate the same way — this is RFC 7523 §2.2 `private_key_jwt` in
  everything but the parameter name.

- **A `form_post` callback arrived with no session, so its state was always missing.** A
  `SameSite=Lax` session cookie is not sent on a cross-site POST: the callback ran against
  an empty session, found no stashed `state`, and told the person their sign-in link had
  expired. The pair now also travels in a dedicated `SameSite=None; Secure; HttpOnly`
  cookie scoped to one connection and read once (`FederationFlowStash`). It stays
  browser-bound, which is the entire point of `state` — moving it to a server-side store
  keyed by `state` would have turned a CSRF defence into a lookup table.

## [1.1.0] - 2026-08-08

### Added

- **The token endpoints can be walled separately from the rest of the IdP surface.**
  `/oauth/token` and `/oauth/revoke` now take their middleware from
  `cbox-id.api.first_party_middleware`, which defaults to `cbox-id.api.middleware` — so a
  deployment that configures nothing, or configures only the existing key, sees no change
  at all.

  It exists because a host can need to issue tokens to software it ships without being an
  identity provider for anybody else's app. A multi-tenant platform's own root serves a
  console whose users enrol authenticators, and that enrolment is an authorization-code
  flow against the host they are standing on — while the same host must keep answering no
  to discovery, dynamic registration, SCIM and the SAML bindings. One middleware list
  decided both, so making the first case work meant opening the second on the same host.
  Two lists let the host state them separately.

  Consumers do not have to do anything. `cbox-id/cbox-id` uses this to close a live 404:
  its `.well-known/cbox-authenticator` advertised an issuer with a real `client_id` on the
  platform root while every endpoint that document implies was absent there, so scanning
  the enrolment QR worked on a tenant subdomain and failed on the root.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **`league/commonmark` updated to 2.9.0**, clearing six advisories against 2.8.3 —
  denial of service via deeply nested XML output and via colliding heading slugs among
  them. A development dependency (it reaches the package through `laravel/framework`), so
  no shipped surface was affected, but `composer audit` is part of this repository's gate
  and it was red.

## [1.0.0] - 2026-08-06

The account plane is gone. A customer **is** an organization.

### Removed

- **`Account`, `AccountMember`, `AccountRole`, `AccountApiKey` and their contracts,
  schema and migrations.** There was an `Account` row above the organization carrying the
  same name and the same status, with its own members, its own role vocabulary and its own
  password column — two rows for one customer, and therefore two answers to "who may act
  for them". They kept disagreeing. Deleted rather than reconciled.
- **`docs/core-concepts/account-and-membership-roles.md`**, which documented the mapping
  between the two role enums and the only safe direction to translate in each way. One of
  the two no longer exists, so the mapping is a description of a decision nobody has to
  make.
- **`PlatformOccupant::Account`** — a customer is an organization, so it was a second name
  for the check `Organization` already makes, and two cases probing one table is how an
  occupancy set starts disagreeing with itself.

### Changed

- **`AccountProvisioner` → `TenantProvisioner`**, `AccountBlueprint` → `TenantBlueprint`,
  `ProvisionedAccount` → `ProvisionedTenant` (five things now, not four: the organization,
  the owner's subject, that owner's membership, the project and the environment).
- **`AccountApiKeys` → `OrganizationApiKeys`**, and the plaintext prefix moves from
  `cbid_acc_` to `cbid_org_`. It is a user-visible credential format, which is exactly why
  it changes now: after 1.0.0 the marker would permanently name a plane that has not
  existed since before the first tag.
- **`ActorType::AccountMember` → `ActorType::OrganizationMember`** (`organization_member`).
- **`MembershipRole::assignable()`** replaces the account role enum's. `Owner` is absent
  deliberately: ownership is transferred, never assigned.
- Provisioning **attaches an existing subject** as the owner rather than failing. `users`
  is unique on `(environment_id, email)`, so creating unconditionally made provisioning
  impossible for anybody already holding a Cbox ID — including the operator running the
  installer, whose address is also the first customer's owner. The blueprint's password is
  applied only when the subject is being created.

### Fixed

- **The organization off-switch did not work at all.** `transitionStatus()` called a
  cache-invalidation method that was never written, so suspend, reactivate and archive each
  raised an `Error`. The invalidation now enumerates ownership through
  environment → project → organization, matching the liveness gate exactly.
- **Suspend and reactivate appended a duplicate audit entry** on replay, and fired a
  duplicate webhook for a transition that never happened. The account writer had enforced
  "record only on an actual change"; only the archive case came across.
- **A suspended customer could still be sold products and environments.** The account
  provisioner locked the account and refused; only the project check survived the move, so
  suspension stopped reads and left writes open. An off-switch that only stops reads is not
  one.
- **`PlatformRoot::environment()` had stopped refusing anything.** It rejects a configured
  platform root that a customer owns — a privilege boundary, since the platform's own
  people are written into whatever it returns. The predicate read a deleted column, and an
  Eloquent model answers null for an attribute it no longer has, so the guard did not break:
  it became TRUE for every row. It had no test; it has one now.
- **`Project::casts()` was deleted with the account relation.** Uncast, `status` is the
  string `'active'` while `isActive()` compares it to a `ProjectStatus` case — false for
  every project that has ever existed — so `addEnvironment()` raised `ProjectSuspended`
  every time. `settings` was separately handing a JSON string to callers expecting an array.
- **API-key authentication raised a fatal**: `Organization::isActive()` does not exist. The
  check asks `OrganizationStatus::revokesAccess()`, so `Deleted` is refused exactly as
  `Suspended` is — the account status enum had two cases and could not get this wrong.

### Build

- `composer qa` runs **`sbom-check`**, which compares the dependency SET and exits non-zero.
  Plain `composer sbom` regenerates in place, so it could only ever report success.


## [0.96.0] - 2026-08-05

### Fixed

- **`PlatformRoot` switched an environment nobody was reading.** It constructor-injected
  `EnvironmentContext`, which is a **scoped** binding — one instance per request. Singletons
  hold `PlatformRoot` (`AccountMembers` and `PlatformOperators` both do), so the object
  graph captured the first request's context and kept it. `run()` resolved the platform root
  correctly and then called `runAs()` on a dead object: the query inside ran under whatever
  environment the live request had selected.

  Invisible for as long as every caller read tables that are not environment-owned —
  `accounts`, `account_members` — where running in the wrong environment changes nothing.
  The first caller to read an environment-owned table through it (`memberships`, once
  environment grants moved there in 0.94.0) found no membership on a tenant host, so an
  account owner was refused the environment they own and the console bounced between the
  hand-off and the sign-in.

  **Anything calling `PlatformRoot::run()` and reading an environment-owned table was
  affected**, on any host other than the platform root's own.

### Changed

- **The scoped-capture architecture test is transitive.** It inspected one level — a
  singleton's own constructor parameters — and the capture above is two
  (`AccountMembers → PlatformRoot → EnvironmentContext`), so it passed while the capture
  was real. A singleton that holds the scoped context *through* a collaborator is exactly
  as broken: what is long-lived is the object graph, not its first hop.

  The walk follows actual property **values** rather than declared types (a constructor
  typed against an interface says nothing about which object is on the other end),
  terminates on cycles by object identity, and reports the whole chain rather than the leaf
  — the leaf alone sends you to the wrong class.

## [0.95.0] - 2026-08-05

### Changed

- **The account plane reads its environment grants from the membership.**
  `AccountMembers::setEnvironmentAccess()` and `accessibleEnvironmentIds()` delegate to
  `Memberships`. The signatures are unchanged, so consumers move once — to `Memberships` —
  when `AccountMember` itself goes, rather than twice.

  `account_members.all_environments` and `account_member_environments` are **no longer
  written**. Keeping both stores in step would be a second truth to drift, and the drift is
  silent in the worst direction: three authorization gates read this, so two stores that
  disagree means one is quietly granting access an administrator believes they removed.

- **`AccountMembers::hasAllEnvironments()`** — read this instead of
  `AccountMember::$all_environments`, which now holds whatever was true before the grant
  moved. It answers **false** for a member the organization has no record of, because
  "all" is the permissive reading and an unknown member must not get it.

### Upgrade notes

- **A consumer reading `AccountMember::$all_environments` directly must switch to
  `hasAllEnvironments()`.** The column is stale from this release on, and a member who has
  since been restricted will read as unrestricted.

- Environment access is answered through the organization now — the environment's project,
  and that project's organization. That is the same set for every environment that has an
  account (`2026_07_19_000110` gave each one a project, `2026_08_06_000100` gave each such
  project its account's organization). The one population where the answers differ is an
  environment whose account was never homed: its project has no organization, so its
  members **lose** access rather than gain it. Home those accounts
  (`2026_08_05_000200`); `2026_08_07_000100` reports them to the log.

- A deployment with no platform-root environment has accounts with no organization and
  therefore no reachable environments. That is the first-install bootstrap window, which an
  installed deployment leaves before anybody restricts a member's access.

## [0.94.0] - 2026-08-05

### Added

- **A membership can be restricted to a subset of the environments its organization owns.**
  `memberships.all_environments` plus a `membership_environments` pivot, with
  `Memberships::setEnvironmentAccess()` and `accessibleEnvironmentIds()` on the contract.

  This is the account plane's per-member environment grant, moved to where it will still
  exist once that plane is folded away. It was believed orphaned — no writer, no rows, no
  coverage — and it is not: three authorization gates read it. Dropping the account-plane
  tables without this would not have removed a dead feature, it would have removed the
  basis of those gates, in the direction that matters: "no grants found" and "all
  environments" are told apart by a boolean that would have gone with the table.

  The grant belongs to the MEMBERSHIP, not the subject: the same subject may hold
  memberships in several organizations, and a restriction one organization grants must not
  follow them into another.

  `all_environments` defaults to **true**. False would mean "restricted to the empty set",
  so a deployment that migrated but had not yet re-pointed its readers would lock every
  member out of every environment on the next request.

  Ownership is filtered on **both** sides. On write, because an id in a member's grant list
  IS access, so a grant naming another organization's environment is a way in rather than a
  stray row. On read, because a grant survives an environment moving to another
  organization and the row alone would still say yes.

### Migration notes

- `2026_08_08_000100_give_a_membership_its_environment_grants` adds only. The account
  plane's `all_environments` and `account_member_environments` are untouched and keep
  working, so the readers can be re-pointed as a separate, separately-revertible change.
  Existing restrictions are carried over, keyed through
  `(accounts.organization_id, account_members.subject_id)` — a membership belonging to an
  ordinary tenant user, with no account member behind it, is not in the join.

## [0.93.0] - 2026-08-05

### Added

- **An organization can own an IdP product with no account behind it.**
  `projects.account_id` was `NOT NULL` *and* carried a cascade to `accounts`, so an
  organization could only ever own a project transitively, through an account row. The
  column is optional now, and `Projects::createForOrganization()` is what makes that
  reachable rather than merely permitted — a nullable column no statement in the codebase
  can leave empty is a capability nobody has.

  The cascade is deliberately **kept**. Dropping the foreign key belongs with dropping
  `accounts` itself, in one migration where both halves are visible: a `DROP TABLE` with
  this cascade still live would take every project with it.

  `uniqueSlug()` now takes the column it scopes to. The account path keys on
  `(account_id, slug)` and the organization path on `(organization_id, slug)`; scoping to
  the wrong one yields a slug that passes the check and then violates the index, surfacing
  as a database error on an ordinary second project called "Default".

### Migration notes

- `2026_08_07_000100_let_a_project_outlive_its_account` repairs before it alters: a project
  whose account has since been homed gets that organization. A project whose account was
  never homed is left alone and **reported to the log** rather than refused — there is
  nothing to derive an organization from, and inventing one is worse than a row an operator
  can see. Those rows will lose their owner when the account plane is retired; home their
  accounts first (see `2026_08_05_000200`).

- Verified incrementally against PostgreSQL 17 and MySQL 8.4, not only by a fresh migrate:
  seeded both legacy shapes at the pre-change migration, then migrated. Rows survived, the
  column became nullable, and `projects_account_id_foreign` was intact afterwards on both.

- SQLite implements a column change by rebuilding the table, and `environments.project_id`
  references `projects` — so the alteration is skipped when it has already been applied.
  That also makes the whole migration re-runnable after a partial failure.

## [0.92.0] - 2026-08-05

### Fixed

- **The webhook retry sweep never ran in production.** `retryPending()` is called from the
  scheduler, and a scheduler process has no ambient environment — `EnvironmentContext` is
  a `scoped` binding populated only by an HTTP middleware or by a job re-entering its own
  environment. Both models it reads are environment-owned with a deny-by-default scope, so
  the select compiled to `WHERE 1 = 0` and the sweep returned zero. Silently, and forever.
  A failed delivery was never retried; a `Pending` row whose job was lost was never
  rescued, so "durable before enqueued" was a promise nothing kept; and orphans were never
  terminalised, so the pruner could never remove them and `webhook_deliveries` grew without
  bound. Every test passed, because the suite pins an environment before it runs anything.

- **Every failed sign-in is now audited, not only the one that trips the lock.** The sole
  entry was `user.locked_out`; everything below the threshold — and everything on a
  deployment with no lockout policy, which returned earlier still — left no trace. That is
  backwards for the attack the counter exists to bound: password spraying is quiet by
  design, and three guesses each against five thousand accounts under a threshold of five
  produced an audit trail containing nothing at all.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Disabling host verification no longer re-enables redirect chasing.** The four
  `verify_url` toggles let an on-prem deployment reach an internal host it owns; their
  disabled branch returned a bare `[]`, which is not "no opinion" but Guzzle's default,
  and Guzzle follows up to five hops. An operator who set the flag to admit one internal
  issuer also allowed every outbound fetch on that plane to be redirected — so a URL the
  tenant controls could 302 to the cloud metadata service. `Guard::pinnedOptions()`
  refuses redirects unconditionally and `laravel-siem`'s adapter already mirrored it;
  these four did not.

### Fixed

- **The liveness probe no longer depends on the cache being reachable.** `/up` carried
  `throttle:300,1`, and `ThrottleRequests` writes to the default cache store — so the one
  endpoint whose job is to answer "is this process alive" could not answer without Redis
  or the database. A blip in either failed liveness on every instance at once, the whole
  fleet restarted together, and each replacement crash-looped against the same dependency
  it was waiting to recover. The handler is a static `{"status":"ok"}`: there is no cost
  to limit, and no limiter worth taking a dependency for.

## [0.91.1] - 2026-08-04

### Changed

- **`AccountRole::Billing` can no longer be assigned.** 0.91.0 mapped it to `Viewer` and
  described that as losing only `canManageBilling()`, which nothing asks for. That was
  incomplete, and the host console's role/page matrix is what caught it: a Viewer may read
  the member roster and a Billing role may not, so the mapping GRANTS access to PII rather
  than merely dropping an unreachable capability. No organization role both reads the plan
  and refuses the roster, so the mapping cannot be made faithful — and widening access to
  PII is the wrong direction to fail in. The case remains, so rows that already carry it
  keep casting and keep their account-plane refusal; it is simply no longer offered.

## [0.91.0] - 2026-08-04

### Changed

- **An account member's membership now says what they hold.** `attachSubject()` wrote a
  neutral `MembershipRole::Member` for everybody, deliberately: `AccountRole` on the member
  row was the single authority for account capabilities, and mirroring it would have been a
  second truth to drift. That was right while the console asked the member row. The console
  asks the MEMBERSHIP now, so a neutral role is not an abstention — it is the wrong answer
  to the only question, and it made an account's own owner a plain member of the
  organization they own. `AccountRole::asMembershipRole()` is the one definition of how the
  two vocabularies line up; `setRole()` carries a change onto the membership so the two
  cannot separate on the first role change; and `2026_08_06_000200` repairs the rows the
  earlier backfill left neutral.

  **`Billing` maps to `Viewer`,** which is the one case that loses something.
  `MembershipRole` has no billing case and should not gain one: `canWrite()` is "not a
  Viewer", so a new role would arrive holding write access to every organization on every
  tenant, and correcting that changes what write means for everybody. Viewer keeps the
  reachable half — reading the plan — and drops `canManageBilling()`, which no page and no
  route in the product asks for.

### Added

- **`MembershipRole` gains the capability vocabulary the account plane needed.**
  `canReadMembers()`, `canReadBilling()`, `canManageEnvironments()` and
  `supportsEnvironmentScoping()`. None of these are account-specific: an organization's own
  console has the same needs, and the roster restriction in particular is general — a
  Developer is frequently a CI or agent credential rather than a person, and a leaked one
  must not enumerate the team. `canManageEnvironments()` is deliberately NOT `canWrite()`,
  which admits the generic `Member`: standing up an environment grants a live
  environment-admin session on that tenant's host.

### Fixed

- **The last owner of an account can no longer be demoted.** `remove()` has always refused
  to delete an owner, on the grounds that it could orphan the account; re-roling the same
  owner to Admin orphaned it just as thoroughly and was allowed. It went unnoticed because
  only the member row was written and nothing objected. Refused up front, before anything
  is written, so the account and its organization cannot record different outcomes.

## [0.90.0] - 2026-08-04

### Removed

- **The account plane's own second factor.** `account_mfa_factors`,
  `account_mfa_recovery_codes` and `account_webauthn_credentials` are dropped, along with
  `AccountMemberMfa`, `AccountPasskeys` and their implementations and models. They were
  built on the premise that an account member is a separate principal from a subject —
  "a SEPARATE subsystem from operator and subject MFA", as the original migration put it.
  Unified account identity removed that premise: an account member IS an ordinary subject
  in the platform root.

  It had already stopped being enforceable. Once the deployment's one sign-in served the
  platform root, a member holding an account TOTP signed in at `/login` against their
  SUBJECT credential and reached the console with a password alone — nothing on that path
  had reason to consult a table keyed by member id. What remained was the appearance of a
  factor, and a store that can still be written but is never checked is worse than none:
  it reads as protection in a schema diagram, it accumulates secrets that must be sealed
  and rotated and disclosed in a breach, and whoever enrolled believes they are protected.

  A member's second factor is their SUBJECT's — enrolled through `Identity\Contracts\Mfa`
  on the account security page, enforced by the host's password door, with the same
  recovery codes every other person on the deployment gets. **No rows are carried across**:
  a sealed TOTP secret belongs to the principal it was enrolled against, and silently
  re-pointing one would produce a factor its owner never agreed to. Anyone who had enrolled
  on the account plane re-enrols. `down()` rebuilds the tables; it cannot rebuild the rows,
  and says so.

### Fixed

- **Every account that predates `accounts.organization_id` is now homed.** The column was
  added nullable in `2026_07_25_000400` with no backfill, and it is written in exactly two
  places, both at account-CREATION time — so every account created before that date had
  null, permanently. That is not cosmetic: the console asks whether the organization being
  administered is the one this account owns, and against null that is false for every
  organization, so an account owner saw no projects, no members, no API keys, no billing
  and no settings — the whole identity-platform area, absent for the person who owns it.
  No test could see it, because every fixture in both suites builds its account through
  `AccountProvisioner::provision()`, which homes it on the way past; the one state a real
  deployment was in was the one state nothing here could produce. It is also not only a
  legacy problem — `homeAccount()` returns silently when there is no platform root yet,
  which is precisely the window the installer and the first-run screen run in.

  The migration writes raw rows rather than calling `OrganizationService::create()`: a
  backfill runs during a deploy, and a thousand accounts should not put a thousand domain
  events on a queue and a thousand entries on the audit chain. It is ordered ahead of
  `2026_08_06_000100`, whose own backfill reads `accounts.organization_id` and would
  otherwise have written null the whole way through.

### Added

- **An organization can own IdP products directly.** `accounts.organization_id` has
  always said an account *is* an organization in the platform root — members and a
  payment method bolted onto it. `projects.organization_id` now records that link
  directly instead of re-deriving it through the account plane, and `Organization` gains
  `projects()` (has-many) and `environments()` (has-many-through the project, so there
  is no second denormalized column to drift). `Platform\Contracts\OrganizationProjects`
  adds `forOrganization()` and `ownedByOrganization()` for the console case where only
  the id is in hand; `DatabaseProjects` implements it alongside `Projects`.

  Both relations cross OUT of the environment scope, which is safe because of the
  PARENT, not the child: a project owns environments and cannot itself live inside one,
  while `Organization` is environment-owned, so the model is unobtainable from any other
  environment — deny-by-default refuses it even by primary key — and the child query is
  keyed on that organization's id.

  The column is stamped on the model's `creating` hook rather than at a call site, so a
  host calling `Project::create()` directly gets it too; a project that missed it would
  read as healthy from the account side and be invisible from the organization side, a
  silent one-directional split of the same fact. Existing rows are backfilled per homed
  account, idempotently. `(organization_id, slug)` is unique, mirroring the
  `(account_id, slug)` key beside it.

  **Purely additive.** `Account`, `AccountMember`, `AccountRole`, `AccountProvisioner`
  and every existing signature are untouched, and `projects.account_id` stays NOT NULL —
  an organization can be *read* as the owner today, but owning a project with no account
  behind it needs that column to become nullable, which is a separate, subtractive step.
  `Account::$environment_limit` is deliberately NOT copied to organizations: the enforced
  limit lives on the project (`EnvironmentLimitReached` is keyed there) and the account
  column is only a provisioning seed, so a third copy would be a number that can disagree
  with the one enforced.

- **The account-role / membership-role correspondence, written down.**
  `docs/core-concepts/account-and-membership-roles.md` maps `AccountRole` to
  `MembershipRole` in both directions. They are not the same set under two names: four
  cases are shared, `Billing` exists only on the account plane and `Member` only on the
  organization plane, and the predicate surfaces do not line up —
  `MembershipRole::canWrite()` is broader than `AccountRole::canManageEnvironments()`, so
  mapping `Billing` onto `Member` grants write access to a billing-only role.
  `Viewer` is the safe floor in both directions, neither round-trips, and billing
  capability is not representable on the organization plane at all. The enums are
  deliberately NOT unified; a test locks every claim on the page so a new case turns it
  red rather than stale.

### Fixed

- **An account member's password reset did not end their sessions.** `resetPassword()`
  reaches the subject through `Subjects::setPassword()`, which writes the credential and
  nothing else — `PasswordResetService` and `AdminPasswordService` each revoke alongside
  it, and this door inherited the write without the revocation. What stood in for it was
  `account_members.session_version`, a stamp a host re-checked on every resolve of its own
  member session.

  That worked only for as long as a member session was its own thing keyed on a member id.
  A member is an ordinary subject in the platform root, and a host that signs them in the
  ordinary way gives their browser an ordinary subject session — which no column on
  `account_members` can reach. So on any host that has finished the unification, a reset
  left every other session the member held wide open, including the one a thief was
  sitting in. `resetPassword()` now calls `SessionManager::revokeAllForUser()` inside its
  existing transaction, in the platform root's scope.

  The stamp is unchanged and still bumped: its other job is making a reset LINK single-use,
  and that is a different question from ending a session.

- **Accepting an invitation could resurrect sessions from before the account was left.**
  Removing a member deactivates their subject but does not revoke its sessions — the
  per-request active check is what holds them out. Accepting a later invitation reactivates
  that same subject (a subject is never re-created for an address that already has one), so
  those sessions came back to life next to a password that had just been replaced.
  `activate()` now revokes alongside the credential write, for the same reason
  `resetPassword()` does.

## [0.89.1] - 2026-08-04

### Fixed

- **A pinned relying party could win with an origin no browser reports.** 0.89.0 let a pin
  survive where it was a valid answer for the environment's host — but it validated only
  the `rp_id`, not the origin. The id is what an authenticator scopes a credential to; the
  ORIGIN is what the verifier compares byte-for-byte against the browser's
  `clientDataJSON`. An operator following our own advice to pin "usually the registrable
  domain" for BOTH keys — `rp_id=acme.com`, `origin=https://acme.com`, on an environment
  serving `id.acme.com` — got a pin that won and then failed every registration and every
  assertion with "origin mismatch". `RelyingParty`'s own docblock warns that the pair can
  be individually plausible and jointly impossible; the guard checked one member of it.

- **`cbox-id:doctor` could not name that state, by construction.** It compared the pinned
  party against the party in force — and once a pin wins, those are the same object, so
  both halves matched and it reported OK for every pin that won, including one that fails
  every ceremony. It now compares the pin against the HOST that will actually answer,
  which is the question an operator needs answered.

## [0.89.0] - 2026-08-04

### Fixed

- **The canonical-issuer redirect held the whole protocol surface; now it holds only the
  metadata.** 0.88.0 redirected every endpoint on an alias host to the canonical issuer.
  That is right for the documents whose identity IS the host, and wrong for everything
  else: SCIM has no issuer concept at all, and a cross-origin redirect makes HTTP clients
  drop `Authorization` — so Okta and Entra provisioning that worked on the alias began
  answering 401 the moment a tenant verified a custom domain. `/oauth/token`,
  `/introspect`, `/revoke` and `/userinfo` are the same shape: they authenticate by
  credential, not by issuer identity.

  Only the four discovery documents and the SAML IdP metadata redirect now, and they
  answer **302 with `Cache-Control: no-store`** rather than a cacheable 301. A 301 is
  heuristically cacheable forever, so clearing a custom domain used to strand every client
  that had seen one, with no way to unwind it. A non-safe method is refused rather than
  redirected.

  The browser surface is deliberately left alone. Nothing it returns names a host — the
  `iss` of the authorization response, the id_token and the SAML `Issuer` are canonical
  whichever host answered — a discovery-driven client already arrives at the canonical
  endpoint, and redirecting it is precisely what an SP's `form-action` CSP blocks.

- **An upgrade could silently lock out every passkey holder on an on-prem deployment.**
  0.88.0 derived the relying party from the environment's host whenever the environment
  had one. WebAuthn allows an RP id to be the origin's host OR a registrable suffix of it,
  and our own documentation tells operators to pin "usually the registrable domain" — so
  `rp_id=acme.com` on the single environment serving `id.acme.com` is a correct pin with
  credentials enrolled against it. Overriding it moved the id, and an authenticator is
  never even OFFERED a credential scoped to a different id: locked out, silently, with no
  error and no way back, because no credential stores the id it was enrolled under.

  A pin now survives where it is still a valid answer for the host in front of it. It does
  NOT survive on a tenant label under a configured base domain, where a shared id would
  offer one tenant's passkey on another tenant's sign-in page — and nothing is stranded
  there, because a tenant passkey could never have enrolled in the first place.

- **`cbox-id:doctor` reported a pin as being in force when it was not.** It compared only
  the origin, and the pair that strands users has identical origins and differs only in the
  id. It now compares both halves and names what a ceremony actually runs as.

## [0.88.0] - 2026-08-04

### Fixed

- **Discovery advertised an `issuer` that was not the host serving it.** An environment
  resolves from either its verified custom domain or `{slug}.{base_domain}`, and both kept
  serving the whole protocol surface — but the issuer was the custom domain
  unconditionally. So a tenant onboarded at `acme.example.com` that later verified
  `id.acme.com` had every existing relying party fetch discovery from the subdomain and
  receive a different `issuer`. That is a MUST in OIDC Discovery §4.3 and RFC 8414 §3.3;
  conformant clients throw. Every integration broke at once, from a config change nobody
  would associate with them.

  `CanonicalIssuerHost` now redirects the alias to the canonical host — 301 for safe
  methods, **308** for the rest, because a 301 on `POST /oauth/token` lets a client rewrite
  to GET and drop the grant body. Deployment-wide issuers (platform root, single-tenant,
  on-prem) are deliberately not redirected: their issuer is operator-configured and
  host-independent, so internal load-balancer names and health probes keep working.

  **Upgrade consequence:** a tenant that has already verified a custom domain now has ONE
  issuer, and its subdomain becomes a redirect. Relying parties configured against the
  subdomain must be repointed. The break is now explicit and one-time at verification
  instead of silent and permanent.

- **WebAuthn was single-origin, so passkeys could not work on any tenant host.** The
  relying-party id and origin were one deployment-wide pair, compared byte-for-byte against
  what the browser reports. Subject-plane passkeys are served on tenant hosts only, so with
  the pair set to the platform apex every tenant's enrolment and assertion failed with
  "origin mismatch" — a shipped, documented, tested feature inert for the entire customer
  base.

  `RelyingParties` now derives the pair per environment from its issuer, and the id and the
  origin travel together in one value object: read as separate config keys they can each be
  individually plausible and jointly impossible. The RP id is the environment's full host,
  not a registrable suffix — a suffix would offer one tenant's passkey on another tenant's
  sign-in page.

### Changed

- **`Subject` carries its status**, so the per-request re-check that refuses a deactivated
  account no longer costs a second read of the row `find()` already loaded. Nullable rather
  than defaulting to active: a host-bound resolver written before the field says nothing,
  and null means "ask the contract", so an unaware implementation keeps paying the query
  and keeps being right.

- **`RequestLifetime`** — a scoped marker whose identity is "this request or job". Hot
  objects that are singletons, or captured by them, cannot be memoised by binding them
  `scoped`: `forgetScopedInstances()` unsets the binding and cannot reach an instance
  something else is holding, so the first request's memo would be pinned forever. Comparing
  a held token against the one the container resolves works whoever holds the memo.
  `CachedEntitlements`, `EnvironmentIssuerResolver`, `DatabaseAuthPolicies` and
  `PlatformRoot` use it.

  `PlatformRoot::model()` memoises only when a row is FOUND — "there is no platform root"
  is the one answer that flips inside a request, and a memoised null would leave the
  operator the installer just created on the bootstrap hash.

- `WebhookRegistry::forOrganization()` — `matching()` read every active endpoint per event
  type and filtered in PHP. The app's own catalogue lists 24 event types; aligning the
  config with it would have made that 24 full reads per render.

- `registration_client_uri` comes from the issuer resolver rather than `url()` — it was the
  only endpoint in the document that did not.

## [0.87.3] - 2026-08-04

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **A deactivated subject authenticated with ANY password.** `DatabaseAccountMembers::verifyPassword()`
  refused a deactivated subject with `! $this->hasher->check($password, $this->dummyHash())`.
  The dummy verify exists to burn time and have its result discarded; the negation made it
  the answer. A dummy hash matches nothing, so `check()` returned false and `!false`
  authenticated. "Deactivated subject holding an active membership" is not exotic — it is
  an unaccepted invitation, and it is a removed member. The caller mints a session on that
  answer and clears the failure counters, so the session goes live the moment the subject
  is reactivated.

  It survived because the branch is only reached with a WRONG password by an attacker;
  every honest test supplies the right one, where broken and fixed agree. The refusal is
  now a statement block that cannot return the discarded value, matching
  `DatabasePlatformOperators::verifyPassword()`, which always expressed the same policy
  correctly. Regression test supplies a garbage password and falsifies.

- **SCIM: `PATCH` group with a bare `members[...]` value filter detached every member.**
  `members[value eq "x"].display` was refused; `members[value eq "x"]` was not — it
  contains no `].` and does not begin with `members.`, so it cleared both guards, reached
  `sync(valueIds(…))` with a non-list value, and emptied the group. 200 returned,
  membership-changed fired, every role mapped from that group was revoked for every
  member, and the connector recorded a success so it never retried or re-synced. Silent on
  both sides, which is what made it worse than an error.

  `add` and `replace` now refuse any filtered `members` path. `remove` with that exact
  path is how an IdP detaches ONE member and continues to work.

## [0.87.2] - 2026-08-04

### Fixed

- **A member's password reset no longer leaves their other sessions alive.** The security
  stamp on `account_members` invalidated MEMBER sessions, and that was the whole of
  log-out-everywhere while a member session existed. It is a host's decision to stop
  keeping one — the credential of record is the subject, so a second session for the same
  person is a second place to ask who they are — and the moment a host makes it, the
  control silently stops covering anything: `Subjects::setPassword()` does not revoke.

  `resetPassword()` now revokes the subject's sessions inside its existing transaction.
  The stamp still moves; its other job, making a reset link single-use, is a different
  question and is unchanged.

- **`activate()` revokes too.** Removing a member deactivates their subject without
  revoking its sessions, so accepting a later invitation resurrected the old ones beside a
  freshly-replaced password.

## [0.87.1] - 2026-08-04

### Fixed

- **An operator carried across from before the unification could no longer sign in.**
  0.87.0 made `platform_operators.subject_id` nullable and left the attaching to
  `verifyPassword()`: the local hash stayed the credential and the subject was created on
  that operator's next successful sign-in — the only moment the plaintext is available to
  seed one. That was correct while a sign-in existed that verified against the local hash.

  It stops being correct the moment a host makes operator authority a permission on the
  ordinary sign-in and retires the separate operator login form, because that form was the
  only caller reaching the bootstrap window. On an upgraded deployment every existing
  operator then has no subject, no account to sign in as, and no door that consults their
  hash — locked out of the platform they run, by an upgrade that reports success.

  A migration now attaches a subject to every operator that lacks one. The plaintext is
  gone but the hash is not, and it does not need re-deriving: both tables hash with the
  configured driver and both models pass an already-hashed value through untouched, so the
  credential moves and the password keeps working. An operator who is also an account
  member is pointed at the subject they already have rather than given a second one, and
  their live password is not touched. The address is NOT marked verified — the operator
  table never asked, and claiming otherwise would hand a confirmed address to step-up
  gates that rely on it meaning something.

  A migration rather than a command, deliberately: a command is a step someone has to know
  about, and the failure mode for not knowing is that nobody can administer the platform,
  discovered after the deploy by the person who can no longer fix it.

## [0.87.0] - 2026-08-04

### Changed

- **A platform operator is a person now, not a second credential store.**
  `platform_operators` held an email and a bcrypt hash and nothing else. Everything that
  protects a sign-in on this platform lives on the SUBJECT — password policy,
  breached-password refusal, lockout after repeated failures, TOTP, passkeys, step-up,
  session revocation — and an operator had none of it, because it was never given any.
  The widest reach in the product sat behind the weakest door, and it was weakest
  precisely because it was separate.

  `platform_operators.subject_id` points at an ordinary subject in the platform root, and
  `verifyPassword()` asks that subject. Account members already work this way; this is the
  same change for the same reason, and it follows the same shape.

  Nothing breaks on upgrade. The column is nullable, the local hash remains the credential
  for an operator created before a platform root existed, and the subject is attached on
  that operator's next successful sign-in — the only moment the plaintext is available to
  seed it. The hash column stays until every row has a subject; removing it earlier is a
  deployment that cannot authenticate.

  A deactivated subject now refuses the operator immediately rather than at the next
  session boundary, which for an identity with cross-environment reach is the point.

### Added

- **`PlatformOperators::findBySubject()`** — the operator record a signed-in subject
  holds, or null. With the operator unified onto the subject store, "is this session
  staff" becomes a question about the session a host already has, so a console can gate
  the platform pages as a PERMISSION instead of standing up a second sign-in beside the
  first. The separate operator door only ever existed because there was a separate
  operator credential.

  Suspended operators are excluded inside the lookup rather than by the caller. Authority
  now rides an existing session and suspending an operator has never revoked their subject
  sessions, so a status check left to each call site fails open — the suspended operator
  keeps every platform page in the session they already hold.

## [0.86.0] - 2026-08-03

### Added

- **One provider catalogue, with capabilities.** Providers were named in two registries
  that shared nothing: `ProviderCatalog` held eleven entries for sign-in — issuers,
  scopes, profile maps, setup steps, documentation — and `DirectoryProvider` held three
  for user sync. Google and Entra were in both, connected by nothing but the word.

  The administrator paid for that. The directory screen could not show the guide that
  already existed here for the same provider, so somebody who had just finished
  connecting Google for sign-in was handed an empty credential form and left to work out
  alone that a directory needs a service account with domain-wide delegation rather than
  the OAuth client they had just made. Two registries meant the product knew the answer
  and had no way to say it.

  A `ProviderTemplate` now carries what it can DO — `ProviderCapability::Login`,
  `ProviderCapability::Directory` — as a typed `ProviderCapabilities` set, and
  `ProviderCatalog::withCapability()` is how a screen asks for the providers it is there
  to set up. The capabilities are **derived from the entry's contents, never declared
  beside them**: a hand-written list is a claim that can be false, and a template
  claiming `directory` with no setup on it would put a provider in the console's list
  that the console cannot then show one field for.

- **The directory half is its own guide, because it is its own job.** `DirectorySetup`
  carries the steps, the vendor documentation URL, and the credentials the connector
  actually reads — separately from the login steps, which describe a different act
  entirely. Connecting Google for sign-in is an OAuth client and two pasted strings;
  connecting the same Google as a directory is a service account, a numeric client ID,
  and a domain-wide delegation grant made in a different console. One flat list of steps
  could only ever have been right for one of them, and an administrator following the
  wrong one gets to the end before finding out.

  The declared credentials are driven through the real connectors in the suite: the full
  set must satisfy them, and dropping any single one must not. A setup form built from a
  stale list collects fields nobody reads and misses one nobody asked for — and stores
  the connection anyway, because a credential map is just an array until something uses
  it.

### Fixed

- **The Entra directory guidance asked for half the permissions it needs.** The
  connector's own documentation named `User.Read.All` only, and the pull fetches groups
  and group members as well — so an administrator who granted exactly what they were
  told got users and, silently, no groups at all. The catalogue entry and the connector
  both now say `User.Read.All` **and** `Group.Read.All`, application permissions,
  admin-consented. The same trap exists on the Google side, where domain-wide delegation
  must carry both the user and the group read-only scopes, and the setup steps now spell
  out both.

### Notes

- `DirectoryProvider` **stays**, deliberately. It is what sits in `directories.provider`
  on every row ever written, what the connector registry is keyed by, and what the sync
  command filters on — a serialization boundary, where a rename is a migration rather
  than an edit. What it no longer does is own provider metadata; the catalogue does, and
  `ProviderCatalog::forDirectory()` is the join. Nothing about existing rows changes.

- **SCIM is not in the catalogue, and that is the design.** Everything in the catalogue
  is a service we go to, holding a credential the customer created for us. SCIM is the
  reverse — a protocol the customer's own identity provider speaks TO us, against an
  endpoint and a bearer token we mint. It has no issuer, no vendor, no client credentials
  to collect and no third-party documentation to link, because the far end is whatever
  they happen to run. An entry for it would have meant inventing a protocol and an empty
  endpoint set to make the shape fit, and would tell an administrator that "connect SCIM"
  is the same kind of act as "connect Google" when every field on that form is ours
  rather than theirs.

- Additive throughout: `ProviderTemplate` gains one trailing optional constructor
  argument, and no existing field, method or signature changed. The dependency runs one
  way — the catalogue reaches down to `Directory`'s enum, and nothing in `Directory`
  reaches up, so a host that renders no setup screen at all still syncs.

## [0.85.0] - 2026-08-03

### Fixed

- **A refresh renews the ID Token, not only the access token** (OIDC Core §12.2). The
  refresh grant returned `access_token` + `refresh_token` and nothing else. That is
  invisible while every relying party authenticates the ACCESS token — and a hard
  failure for one that authenticates the ID Token, because the credential it actually
  presents could not be renewed at all. `kubectl oidc-login` is exactly that relying
  party, as are Grafana and Vault in that mode.

  Measured against a live deployment: a client with a 300-second lifetime meant a
  browser window every five minutes, which is the behaviour `offline_access` exists to
  prevent — and the reason somebody then asks for a longer lifetime instead of a fix.

  The refreshed token keeps `iss`, `sub` and `aud` from the original, stamps a fresh
  `iat`, and binds `at_hash` to the access token returned beside it. A grant with no
  user behind it (`client_credentials`) still gets none: an ID Token asserts an
  authenticated person, and one minted for a machine grant would be an assertion about
  nobody.

  It carries **no `nonce`**. A nonce binds an ID Token to one authentication *request*
  so a client can detect replay, and a refresh is not an authentication request —
  echoing the original would hand back a token the client has already seen that nonce
  on, which is the condition its replay check exists to catch.

### Added

- **The rotation family remembers the login it descends from.** `auth_time` and `amr`
  are recorded on the refresh token, so a refreshed ID Token can describe the ORIGINAL
  authentication as §12.2 requires rather than the moment it was refreshed. Without it
  a session's asserted assurance level would fall at its first refresh, which reads to a
  relying party gating on `acr` as the user losing their second factor.

  Adds a nullable `auth_time` and `amr` to `oauth_refresh_tokens` (migration included).
  Families issued before this keep working and simply carry no authentication context —
  the claims are optional, and a missing one is honest where a fabricated one is not.

  `RefreshTokens::issue()` takes the two as trailing optional arguments; a host that has
  implemented the contract itself must widen its signature.

## [0.84.0] - 2026-08-03

### Added

- **`cbox-id:doctor` runs the host's checks too.** The doctor knows what the LIBRARY
  needs — extensions, a crypto key, signing keys, an issuer that resolves. It cannot know
  what the host application needs, and the host's misconfigurations are the ones that
  fail quietly: a deployment claiming a shape it cannot serve still boots, still answers,
  and degrades behaviour with no error anywhere.

  A host implements `Console\Contracts\HealthCheck` and adds it to the `HealthChecks`
  registry from a service provider. One command rather than a second health command,
  because two things to remember to run means the one nobody runs is the one holding the
  finding.

  Results are a typed `HealthResult` (`ok` / `warn` / `fail` plus a label and the fix)
  rather than the string-keyed array the command used internally — this crosses a package
  boundary now, and a map at a boundary is a shape every implementer has to guess at.

  A check that throws is reported as a failure and the rest still run. The contract says
  it must not throw; the registry assumes it will anyway, because the moment you most want
  a health report is when something is already broken enough to throw.

## [0.83.1] - 2026-08-03

### Fixed

- **`cboxdk/laravel-ssrf` raised to `^1.1.1`, which repairs DNS pinning for dual-stack
  hosts.** Up to and including v1.1.0 the guard emitted one `CURLOPT_RESOLVE` entry per
  validated address, but curl treats a second entry for the same `host:port` as a
  replacement rather than an addition — so only whichever address sorted last survived.
  For a dual-stack host whose AAAA sorts last (`accounts.google.com` is one) every
  pinned request was pinned to IPv6 alone, with no fallback to the IPv4 address that had
  been validated moments earlier. On a host without an IPv6 route the connection simply
  failed, with a transport error naming neither the pin nor the protocol.

  Every outbound path in this package that pins DNS was affected: OIDC discovery, the
  OIDC and OAuth 2.0 token exchanges, JWKS fetches during assertion validation, SAML
  metadata import, SCIM provisioning, webhook delivery, external action transport and
  access-control manifest fetches. Whether it actually *failed* depended entirely on the
  host's own IPv6 connectivity, so it presented as "works on my machine".

  The floor is raised rather than left at `^1.0` so the fix is guaranteed rather than
  merely permitted — `^1.0` would let an existing lock file stay on the broken v1.1.0.
  No API change on either side.

## [0.83.1] - 2026-08-03

### Fixed

- **Requires `cboxdk/laravel-ssrf` ^1.1.1.** Below that version the SSRF guard pinned
  only the LAST of a host's validated addresses — curl treats a repeated
  `CURLOPT_RESOLVE` entry for the same `host:port` as a replacement, not an addition —
  so any dual-stack federation target whose AAAA sorted last was reached over IPv6
  alone, and failed outright on a host with no IPv6 route. `accounts.google.com` is such
  a target. Every outbound path in this package goes through that guard: OIDC discovery,
  token exchange, JWKS retrieval, and the directory connectors.

  The floor is the fixed version rather than `^1.1`, because a consumer that resolved
  1.1.0 would get a package whose pinning silently discards addresses.

## [0.83.0] - 2026-08-03

### Added

- **`ConnectionType::OAuth2`.** Providers that speak OAuth 2.0 and nothing more —
  GitHub, Discord, Facebook — now have a type of their own rather than borrowing OIDC's.
  The difference is not configuration: there is no `id_token`, no discovery document and
  no signature over the claims, so what may be trusted afterwards is genuinely narrower.
  One shared type would have let a caller reach for OIDC's guarantees on a connection
  that cannot provide them. `Connections::oauth2Config()` reads it, and refuses a config
  naming an OIDC provider — driving one of those down this path would mean no `id_token`
  was ever verified.

- **A `provider` column on connections, and `catalogueProvidersFor()`.** A tenant may
  enable several catalogue providers at once (Google *and* GitHub *and* Apple), while
  `forOrganization()` answers "the organization's enterprise sign-on connection" and has
  to keep answering exactly that. Without the column the two kinds were
  indistinguishable and the first active row won whichever it happened to be — so
  enabling Google could silently become an organization's SSO, which decides where every
  one of its people is sent to authenticate. `create()` refuses a key the catalogue does
  not have, rather than storing a connection that renders a sign-in button nobody can
  complete.

  The column is nullable and existing rows become NULL, which is what they are: a
  hand-configured enterprise connection genuinely has no catalogue entry.

- **`AppleClientSecret`.** Apple's client secret is not a string anyone can paste — it
  is an ES256 JWT minted from a downloaded signing key, valid at most six months.
  Treating it as a text field is how an Apple integration stops working half a year
  after the last person touched it, on a day nobody changed anything. Minted on demand
  and cached for an hour rather than for Apple's ceiling, keyed by the material so
  rotating a key takes effect immediately instead of when a cache expires. Signed
  through firebase/php-jwt like every other signature here; the tests verify the result
  against a real EC public key rather than by parsing our own output.

## [0.82.1] - 2026-08-03

### Fixed

- **A client's token lifetime now reaches the `id_token`.** It was hardcoded at 900
  seconds, so `accessTokenTtl` shortened only the access token — and a relying party
  that authenticates the ID token never sees that one. Kubernetes is exactly that case:
  `kubectl oidc-login` presents the `id_token` as its bearer, the API server validates
  `exp` offline and never calls back, so for it the `id_token`'s lifetime IS the
  revocation window. A client registered with a 300-second TTL was getting five minutes
  on a credential it does not present and fifteen on the one it does. Found by Cortex
  driving a real `kube-apiserver` against this issuer.

  Nothing changes for a deployment that has configured nothing: the default is still
  900. The tests assert the SIGNED `exp - iat` as well as `expires_in`, because the
  response field describes the access token and a change that moved only one of them
  would look right in the response and be wrong in the credential.

## [0.82.0] - 2026-08-03

### Added

- **A provider catalogue** — Google, Microsoft Entra, Okta, Auth0, Keycloak, GitLab,
  Slack, GitHub, Discord, Apple and Facebook. Issuers, endpoints, scopes, where the
  identity sits in the response, and how to obtain the credential. What it deliberately
  does not hold is the client id and secret: those stay the tenant's, which is the point.
  Adding a provider is a new entry, not a new code path.
- **`FederationProtocol` and an OAuth 2.0 client.** GitHub, Discord and Facebook are not
  OpenID Providers — no discovery document, no `id_token` — so the generic OIDC path
  could not reach them at all. The new client exchanges a code and fetches a profile,
  mapping it through the catalogue. It is explicit about what it does and does not prove:
  that the browser controls the provider account, and nothing about the address attached
  to it.
- **Apple, with the three ways it differs declared rather than discovered**: its client
  secret is an ES256 JWT minted from a downloaded key rather than a value to paste, it
  POSTs its callback, and it sends the person's name exactly once. Each produces a failure
  that reads as something else — most sharply, a secret stored as a string that works and
  then stops six months later.
- **`Subjects::resolveFederated()`**, reporting whether the call CREATED the account. A
  first federated sign-in is a signup, with a signup's obligations: the address is
  unverified until this platform verifies it, and the person holds exactly one way in.

### Fixed

- **The `ArraySubjects` test fake merged a federated identity into an existing account by
  email** — the account-takeover the real implementation exists to refuse. A fake more
  permissive than the thing it stands in for does not merely fail to catch a regression;
  it teaches every test written against it that the unsafe behaviour is the contract.

## [0.81.0] - 2026-08-03

### Added

- **A `groups` claim on the ID TOKEN, behind a `groups` scope.** Relying parties that
  authenticate the id_token rather than the access token — Kubernetes, Grafana, Vault —
  had nothing to map to groups: our federated RBAC lived only on the access token. A
  cluster could authenticate a person correctly and then have nothing to bind a policy
  to, so every request was denied with the identity plainly right in the logs. The claim
  carries the same data the access token does (this app's declared roles plus org-wide
  ones, never another app's), and is emitted only when the scope was granted, so no
  existing client's id_token changes shape.
- **Per-client access-token TTL.** One deployment-wide value is the wrong shape once an
  issuer serves relying parties with different revocation stories. A credential a
  resource server validates OFFLINE can only be revoked by expiry — Kubernetes never
  calls back — so for that credential the TTL *is* the revocation window, and five
  minutes is a real answer to a stolen laptop where fifteen is a worse one. A browser
  session has no reason to pay for it. `NewClient::$accessTokenTtl`; null keeps the
  deployment default, so nothing changes for existing clients.

## [0.80.0] - 2026-08-02

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **A client could choose its own token audience after the user had authorized.** The RFC
  8707 `resource` parameter was read at the token endpoint, validated as an absolute URI,
  and stamped verbatim into the access token's `aud` — while nothing recorded what the
  authorization had been FOR. So any client holding a valid code could name any resource
  server at redemption and receive a token, signed by this issuer, asserting it was minted
  for that server. That is a confused deputy against every resource server that trusts the
  issuer and checks `aud`, which is exactly the check RFC 9068 tells it to make and the
  property the MCP authorization model rests on. §2.2 requires the token request's
  resource to be the one the authorization was granted for; `authorization_codes` now
  carries it, and a mismatch is refused with `invalid_target`. A redemption naming no
  resource gets the authorized one. Codes carrying none behave exactly as before — nothing
  is retroactively bound.

  Hosts must pass the authorized `resource` to `AuthorizationCodes::issue()` for the
  binding to exist; the parameter is optional and defaults to null, so an un-updated host
  is no worse off than it was.

## [0.79.0] - 2026-08-02

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **A `persistent` NameID was the subject's email address, identical at every service
  provider.** `resolveNameId()` never consulted the format — it returned whatever the
  service provider's `name_id_attribute` pointed at, which defaults to `email`. SAML Core
  §8.3.7 defines the format as an opaque, SP-specific pseudonym precisely so that two
  providers cannot match their users against one another; ours handed them a shared join
  key that was also PII. `transient` (§8.3.8, "MUST NOT be reused") was the same stable
  email forever. Persistent identifiers are now 128 random bits per (service provider,
  subject), stored in `saml_idp_name_ids` so one provider's identifiers can be reissued
  without touching any other's; transient ones are minted per assertion and recorded on
  the session row, so Single Logout still resolves them. `emailAddress` and `unspecified`
  are unchanged. The conformance tests asserted the URN strings and the metadata but
  never the value, which is how this passed a conformance suite.

## [0.78.0] - 2026-08-02

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **A captured SAML `LogoutRequest` was a permanent, unauthenticated logout against the
  person it named.** The relying-party half of Single Logout verified the signature and
  nothing else — no freshness bound and no single-use claim, while the identity-provider
  half has enforced both since it was written. The message arrives as a query string in
  the user's browser, so a copy survives in history, proxy logs and any leaked `Referer`;
  anyone holding one could end that person's sessions again after every re-login, forever.
  onelogin checks `NotOnOrAfter` only when the message carries one, and most identity
  providers do not send one on a logout. Both bounds are now enforced, with the replay key
  scoped to the connection rather than the identity provider's EntityID — two tenants may
  federate to the same IdP, and a shared key is one tenant able to burn the other's
  message ids.
- **`saml_idp_sessions` carried a 30-day expiry that nothing enforced.** The release notes
  told operators records are kept 30 days and the constant's own docblock said a later
  logout "has nothing to resolve and is refused" — but the lookup had no expiry predicate,
  so a service provider that federated a user once could end that person's sessions
  indefinitely. A bound nobody checks is a comment.

### Fixed

- **The SAML HTTP-POST binding could not work under any real content-security policy.** A
  self-submitting form aimed at a service provider's ACS is, to a browser, exactly the
  shape `form-action` exists to refuse, and its auto-submit is exactly what a `script-src`
  without `'unsafe-inline'` exists to refuse. A host that hardened its headers broke its
  own federation: the assertion was built, signed, and never delivered — the user watched
  a blank page and the service provider was never told anything happened. There is no
  PHP-level symptom, which is why it shipped. `SamlResponse::toPostBinding()` now returns
  the payload together with a policy of its own: `default-src 'none'`, a per-response
  nonce for the single submit script, and `form-action` naming only the ACS this assertion
  is addressed to — taken from the registration, never from the request. The submit moved
  from a `body onload` handler to a script tag because an event-handler attribute can only
  be permitted by `'unsafe-inline'`, which is all-or-nothing for the whole document. Hosts
  with no policy are unaffected; `toPostForm()` still returns the same HTML.
- **Two migrations dropped a uniqueness constraint before adding its replacement.** MySQL
  DDL is not transactional, so a failure between the two statements is a state, not a
  rollback — and in that state DPoP proof-JTI replay and SAML assertion replay were
  unconstrained, on the two tables that exist to prevent exactly that, with the migration
  unrecorded so the deploy that would repair it could not run either. Both now add first
  and drop second, so the window holds two constraints instead of none.

## [0.77.1] - 2026-08-02

### Fixed

- **0.77.0's `saml_idp_sessions` table could not be created on MySQL or MariaDB, and left
  the schema stuck.** The Single Logout lookup was indexed over the raw
  `(environment_id, sp_entity_id, name_id)` triple. Two 512-character URI columns are
  4096 bytes in `utf8mb4` before the environment id is added, and InnoDB refuses a key
  over 3072 — so `create table` succeeded, the `add index` behind it failed, and the
  migration was never recorded. Every subsequent deploy then failed on *table already
  exists* without reaching the migrations queued behind it. The lookup is now a
  `lookup_hash` column — sha256 of the EntityID and NameID, NUL-separated so the boundary
  between them cannot be shifted — maintained by the model, and the migration drops the
  stranded table before recreating it. That drop can only fire where the migration is
  unrecorded, which is exactly the failed state; where 0.77.0 completed (sqlite,
  PostgreSQL) it is never called again. Upgrading from 0.77.0 needs no manual step.
- **A migration stranded by a half-applied run is now a covered case, not a discovery.**
  `tests/Migrations/MigrationRollbackTest.php` plants a table under a migration's name,
  leaves it unrecorded, and requires the migrator to run over it and leave the corrected
  schema behind. It runs on every engine the suite is pointed at, MySQL and MariaDB
  included — where DDL is not transactional and this failure shape is possible at all.

## [0.77.0] - 2026-08-02

> **Withdrawn 2026-08-02.** This release cannot be installed on MySQL or MariaDB: the
> `saml_idp_sessions` migration below builds an index InnoDB refuses, which leaves the
> table created, the migration unrecorded, and every later deploy stopping on *table
> already exists*. Use 0.77.1. Appended per the immutability note above — nothing in the
> entry itself has been altered.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Any registered service provider could log out any subject in the environment.** Single
  Logout took the NameID from a signed `LogoutRequest`, resolved it as a subject id OR an
  email, and revoked every session that person had — anywhere. A NameID is not a secret;
  for the default `emailAddress` format it IS the person's email address. So an SP an
  administrator had added for one purpose held a logout primitive over users it had never
  seen, usable repeatedly.

  Assertions are now recorded as they are issued (`saml_idp_sessions`: environment, SP
  EntityID, subject, NameID, SessionIndex), and SLO resolves the NameID **through the SP
  that presented it**. Only a subject we actually issued an assertion to, for that SP,
  under that name, can be logged out by it. An unresolvable NameID is a silent no-op — a
  logout that does not happen is a nuisance; one that happens to the wrong person is an
  outage.

  The `SessionIndex` was already minted into every assertion's `AuthnStatement` and thrown
  away. Recording it is what will let a conformant SP end one session rather than all of
  them.

### Fixed

- **A role orphaned after its mapping existed aborted the whole directory reconcile.**
  0.75.0 made `assertAssignableIn()` refuse orphaned roles but left `assignableOnly()` —
  the pre-filter whose entire job is to drop unresolvable ids *rather than let `assign()`
  throw* — matching the old predicate. The two diverged, and `assertAssignableIn()` throws
  `UnknownRole`, which the `GrantRefused` catch does not cover.

  This is the ordinary manifest lifecycle, not an attack: an app drops a role, the sync
  flags it, the mapping row survives by design. The next reconcile then aborted on the
  first member of that group — so the **revocation** pass never ran and a user removed
  upstream kept the role indefinitely — and because listeners run in registration order
  with access control ahead of webhooks and provisioning, every downstream listener was
  skipped on each attempt until the event dead-lettered. My regression; found by
  re-reviewing the change.

## [0.76.0] - 2026-08-01

Four SCIM defects, all of them silent — the connector sees a 200 and never retries, so
the directory and the downstream app diverge with nothing to reconcile them.

### Fixed

- **`members[value eq "x"].display` emptied the group.** The path addresses a
  sub-attribute of one member, passed the `members` prefix check, and arrived at
  `sync(valueIds("Some Name"))` — and `valueIds()` of a plain string is the empty array,
  so the branch that reads like "rename a member" detached every one of them. Refused
  rather than guessed at: this server stores no per-membership display value.

- **A pathless `replace` naming both a displayName and members applied only the rename.**
  A pathless operation carries the whole resource, so it means both; the rename branch
  fired first and returned, discarding the membership with a 200. Half an operation
  reported as all of it is worse than a refusal.

- **An outbound profile push wiped `givenName` and `familyName`.** RFC 7644 §3.5.2.3
  makes a pathed `replace` of a complex attribute a whole-attribute replacement, and the
  push emitted `{"op":"replace","path":"name","value":{"formatted":"…"}}`. Leaf paths
  (`name.formatted`) now replace one sub-attribute and leave its siblings alone. This is
  the same bug the INBOUND side found and fixed, never mirrored outbound — and its comment
  there explains that Entra's read-modify-write reconciliation pushes the omission back
  over the stored values on the next cycle. A multi-valued attribute like `emails` is
  still replaced whole, or a push could never remove an address.

- **A rotated downstream bearer token dead-lettered every queued operation.** 401 and 403
  were terminal, so a connection fixable in thirty seconds by pasting a new token had
  nothing left to retry by the time anyone did. Unlike the OAuth path, which refreshes
  with an expiry margin, a static bearer gives no warning it has been replaced. Retrying
  a genuinely revoked credential costs a bounded number of identical failures; dead-
  lettering a rotated one costs a silent, unrecoverable divergence.

## [0.75.0] - 2026-08-01

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **A role its declaring app had retired was still grantable.** Orphaning keeps the row
  and its existing assignments — deleting them would revoke access on a deploy blip — and
  the console stops offering the role. But `assign()` did not refuse it, so an
  administrator who knew a retired role's id could map a directory group to it by calling
  the action directly, and every reconcile then granted a role the owning application no
  longer believes in: carried in tokens, understood by nothing the app ships. A role that
  has vanished from the UI is exactly the one someone would name by hand.

  `assertAssignableIn()` now refuses an orphaned role, so the console's narrower rule and
  the framework's chokepoint agree. Re-declaring the role in a manifest makes it grantable
  again, so this tracks the manifest rather than being a one-way door.

## [0.74.0] - 2026-08-01

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **A SAML assertion naming no audience was accepted.** php-saml checks the audience only
  when one is PRESENT — `if (!empty($validAudiences))` — and nothing here re-checked it,
  while SAML 2.0 Profiles §4.1.4.2 makes it a MUST that the SP verify an
  `<AudienceRestriction>` exists and names it. Where an IdP can be made to emit
  audience-less assertions (Shibboleth and Keycloak custom mappers, a blanked Okta
  audience), an assertion that IdP legitimately minted for a DIFFERENT relying party was
  accepted here as a login. `InResponseTo` covers the solicited path, so the exposure was
  a connection with IdP-initiated sign-in enabled — the configuration with no other
  binding between request and response. Absent and wrong are now refused alike.

- **CIBA accepted public clients.** `authenticate()` admits a public client on `client_id`
  alone, which is safe where a front channel and PKCE bind the flow to the browser that
  started it. CIBA has neither, and its only human check is the approval prompt it puts on
  someone's phone — so a public `client_id`, which is not a secret and ships in every copy
  of an app binary, was enough to spray prompts at arbitrary users via `login_hint`. That
  attacks precisely the human-in-the-loop CIBA exists for: a person who has dismissed
  thirty prompts approves the thirty-first.

### Fixed

- **`client_credentials` answered 200 when it granted nothing.** Down-scoping a request to
  what a client registered for is deliberate and correct — §5.1 permits a granted set that
  differs from the request provided the response says so, and it does. But §5.1's ABNF has
  no empty production for `scope`, so when NOTHING survived the filter the echo could not
  be sent and the response was indistinguishable from "you got everything you asked for".
  A request where nothing survives is a refusal, and §5.2 has the error for it. The
  partial-grant behaviour is unchanged and now pinned by its own test.

### Testing

- **Three outbound federation SSRF sites had no test at all** — OIDC discovery, JWKS fetch
  and SAML metadata import. `pinnedOptions()` is the only protection on those paths. That
  absence is not theoretical: the equivalent pin on the outbound SCIM client was replaced
  with an empty array during this review's own falsification work, swept into a commit and
  released, and every suite stayed green. Each is now armed with `Http::fake` on the
  blocked address, so a bypass SUCCEEDS visibly rather than erroring on an unreachable
  network.

- **`--group=isolation` contained 34 tests when 149 belonged in it.** Pest ignores a
  file-level `@group` docblock — membership comes from `uses()` or a per-test `->group()`
  — so seventeen files that declared it contributed nothing, including
  `EnvironmentIsolationTest` itself. `docs/core-concepts/environments.md` tells operators
  to run exactly that command as the evidence that tenants are separated, so someone ran
  it, saw green, and drew a conclusion about the wrong 34. A meta-test now fails if a file
  claims the group without joining it.

## [0.73.0] - 2026-08-01

### Added

- **`Subjects::update()`** — change a subject's name and/or email, audited as
  `user.updated` and emitted as a domain event. There was no verb for this, so the host
  console reached past the contract and called `$user->save()` on the model: the only
  direct model write left in it, while every neighbouring action went through a contract.

  Three things followed. No audit record for the most security-relevant mutable attribute
  on an account — email is both the primary identifier and the recovery channel.
  `user.updated` offered in the console's webhook picker with nothing anywhere emitting
  it, so subscribers got silence. And the outbound SCIM path's `'user.updated' => Upsert`
  branch permanently dead, so a legal name change propagated to no downstream application,
  ever.

  A changed email lands **unverified**: an administrator asserting an address is not its
  owner proving one, and keeping the flag would make this an account-takeover primitive —
  set an address you control, and every recovery path points at you. A no-op update
  records nothing, because an access review reading "the email changed" when it did not is
  worse than silence.

## [0.72.0] - 2026-08-01

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **`POST /oauth/decisions` now pins the audience.** It accepted any active access token
  and checked neither the audience nor a scope, while answering with strictly more than
  UserInfo does — the subject's entire permission and entitlement set in the organization.
  UserInfo has refused a wrong-audience token for some time, with a docblock explaining
  that a token minted for a specific RFC 8707 resource must not be replayable to harvest
  identity claims; the same reasoning applies here with more at stake.

  Concretely: an organization registers an app with `resource=https://app-a.example`.
  Anyone holding a token audienced to that app — the app, or whoever compromises it —
  could replay it here and enumerate that user's whole authorization surface. UserInfo
  says no to the identical token.

### Added

- **`cbox-id.oauth.decisions.require_scope`** (`CBOX_ID_OAUTH_DECISIONS_REQUIRE_SCOPE`),
  requiring `decisions:read` on the presented token. **Off by default**, because the
  endpoint has always accepted any active token and turning this on unannounced refuses
  every integration that has not been updated to ask for the scope. The audience check
  above is not optional and is always enforced.

### Fixed

- **The endpoint's three distinct 401s are distinguishable.** No token, an inactive token
  and a failed DPoP proof all emitted the same bare `{"error":"invalid_token"}`, two of
  them with no `WWW-Authenticate` at all — which RFC 6750 §3 makes a MUST, and which
  `TokenController` had already solved one file over, noting that several real client
  libraries treat a bare 401 as fatal. Each now carries its own `error_description` and a
  challenge header.

## [0.71.0] - 2026-08-01

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Segregation of duties now runs at the grant chokepoint, not in front of it.** The rule
  was correct and was only ever asked on the paths a host can intercept — the console's
  four manual grant paths. Directory group→role mappings are reconciled INSIDE the
  framework, so a user added to two upstream groups received the forbidden pair silently
  on the next reconcile: the automation a customer buys was the way around the control
  they bought. `RoleService::assign()` already called itself "the chokepoint every caller
  funnels through", and it was — for ownership only.

  Enforced through a new `AccessControl\Contracts\GrantGuard` rather than a direct
  dependency, because `Governance` already depends on `AccessControl` and pointing it back
  would close a module cycle. The default binding permits everything; `Governance` replaces
  it, so loading governance is what turns the gate on. A vetoed directory grant is skipped
  and audited as `role.grant_withheld` rather than aborting the reconcile — one person's
  conflicting membership must not abandon everyone else's sync.

  Note the consequence for the detective control: `scan()` still matters, because a
  violation can now only arise from a policy defined AFTER the roles were held, which is
  the ordinary way rules get written.

- **One TOTP code or recovery code admitted two sign-ins under a race on the operator and
  account-member planes.** Both did a read-then-write; the subject plane has used a
  conditional UPDATE from the start, with a comment explaining that two requests
  presenting the same intercepted code both pass the replay check. `DatabaseOperatorMfa`'s
  own docblock claimed the planes could not drift on the security-relevant parts. Both now
  consume with a conditional update and return whether they won it.

- **SCIM Group `PATCH` with no `path` emptied the group and answered 200.** RFC 7644
  §3.5.2.2 requires 400 with `scimType: noTarget`, which `/Users` has always answered and
  `docs/security/standards.md` already claimed for both. A connector that dropped `path`
  on a membership reconcile therefore detached every member, recorded a success, and never
  retried — and because membership drives the group→role bridge, every mapped role went
  with it.

### Changed

- **`Mfa::disable()` takes an optional actor.** It hardcoded the subject, so an
  administrator removing someone's second factor was recorded as that person doing it
  themselves — erasing the one distinction the verb was added to capture. Defaults to
  self-service, so existing callers are unaffected.

## [0.70.0] - 2026-08-01

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

**Restores two controls that 0.68.0 and 0.69.0 shipped without.** Both were deleted by
accident, not by decision, and both were released. Those two versions have since been
**withdrawn** — their tags are deleted, so neither can be installed. Earlier versions
are unaffected.

- **The SAML digest-algorithm pin was removed**, leaving an empty loop where the check
  had been. A response signed RSA-SHA256 but digested with SHA-1 was accepted — the
  signature pin still held, so only the weaker half of the pair was open.

- **The outbound SCIM client's SSRF pinning was replaced with an empty option set**, so
  delivery-time DNS pinning was off. Registration-time validation still applied, which
  means the exposure was specifically the rebind window: a host that resolves publicly
  when a connection is registered and privately when an operation is delivered.

How it happened, because the mechanism matters more than the diff: both edits were
falsification probes from this review's own testing pass — deliberate deletions made to
check whether a guard was actually guarded. They were still in the working tree when a
`git add -A` swept them into an unrelated commit. Neither test suite went red, because
neither control had a test that failed when it was deleted, which was the very finding
the probes were confirming.

### Testing

- **A mixed-algorithm SAML response** — RSA-SHA256 signature, SHA-1 digest. Every existing
  SAML test used an all-SHA-1 document, which trips the signature pin first, so the digest
  pin was never the reason any test passed and could be deleted in silence. The fixture's
  single `sha1` flag now splits in two so the two pins can be exercised apart.

- **Delivery-time SSRF refusal on the outbound SCIM client**, which had no test at all.
  The connection is registered with the guard off and the guard enabled for the delivery,
  so it proves the delivery-time check specifically rather than the registration one.

## [0.69.0] - 2026-08-01

> **Withdrawn 2026-08-01.** The tag for this version was deleted, so it can no longer be
> installed. It shipped without the SAML digest-algorithm pin and without the outbound
> SCIM client's delivery-time SSRF pinning — see [0.70.0](#0700---2026-08-01) for what was
> removed, how, and what now proves it cannot happen unnoticed again. The entry below is
> left as written, because a changelog that quietly loses a version is worse than one that
> records a withdrawn one.


No behaviour change. Two guards that did not guard, found by deleting the code they
claim to protect and watching the suite stay green.

### Testing

- **The SAML XML-Signature-Wrapping test proved nothing.** Making both binding checks in
  `EmbeddedSignature` return unconditionally left all 19 tests passing. The wrapper the
  test built omitted `Destination`, so the parser rejected it at an unrelated check long
  before the binding checks ran — and since `InvalidAuthnRequest` is the single exception
  class for every rejection reason, asserting only the class could not tell the two
  apart.

  What was unguarded: an SP whose certificate we trust lifting its own valid signature
  onto an `AuthnRequest` root it controls, and the IdP treating it as authentic. That is
  SP impersonation on the IdP's front door.

  Now three cases, each asserting the MESSAGE: signature at the root referencing the
  decoy, signature buried below the root, and two signatures on the root. Each binding
  check falsified independently.

- **Nine of the eleven fields in the audit-chain hash were not proven to be in it.**
  Only `action` and `environment_id` had a tamper test. Removing `actor_type`,
  `actor_id`, `target_type`, `target_id`, `context`, `ip` and `recorded_at` from
  `canonicalPayload()` left the Audit, AuditQuery, AuditStreaming and Maintenance suites
  green — so a refactor could drop WHO acted, FROM WHERE, ON WHAT and WITH WHAT DETAIL
  out of the hash, and anyone with database write access could rewrite all four while
  `verifyChain()` still answered "valid". In the one subsystem whose entire product claim
  is tamper-evidence.

  Now one case per column. `environment_id` and `scope` break at the FOLLOWING entry
  rather than the tampered one, because they identify the chain — rewriting either
  removes the row from the chain being read instead of corrupting it in place, which is
  the property that makes a row unmovable between environments.

## [0.68.0] - 2026-08-01

> **Withdrawn 2026-08-01.** The tag for this version was deleted, so it can no longer be
> installed. It shipped without the SAML digest-algorithm pin and without the outbound
> SCIM client's delivery-time SSRF pinning — see [0.70.0](#0700---2026-08-01) for what was
> removed, how, and what now proves it cannot happen unnoticed again. The entry below is
> left as written, because a changelog that quietly loses a version is worse than one that
> records a withdrawn one.

### Changed

- **`AuthPolicies` gained `overridesFor()`** — every organization's override in one read,
  keyed by id, omitting the ones with none. Breaking for a host that implements the
  contract itself; [`UPGRADING.md`](UPGRADING.md) carries a working fallback.

  Memoising `overrideFor()` in 0.67.0 removed the DUPLICATE reads — two per organization
  down to one — but left the shape untouched: a subject in nine organizations still cost
  nine queries on every authenticated request, and the Sign-in rules console page pays it
  once per organization in the whole environment, unpaginated. Absences are memoised as
  well as hits, because a subject with no overrides would otherwise re-read every one of
  their organizations next request — the exact cost this replaces.
  `DatabasePasswordExpiry` and `DatabaseMfaMandate` both use it.

### Testing

- Proven at twelve organizations, half with an override and half without: one query cold,
  none warm.

## [0.67.0] - 2026-08-01

Found in the sixth whole-platform review loop. One of these is a shared-fate performance
ceiling rather than a security bug, and it is the more urgent of the two.

### Fixed

- **Every authenticated request scanned every tenant's memberships.** `memberships` was
  created with indexes on `environment_id` and `organization_id` plus
  `unique(organization_id, user_id)`. `user_id` is the SECOND column of that unique, and
  no composite index can serve a predicate on its second column alone — so a lookup by
  `user_id` had nothing at all. That would be a footnote if the query were rare;
  `MembershipService::forUser()` runs `withoutScope` by design, so the SQL carries no
  environment filter either, and the host calls it from its authentication middleware on
  every request. One customer's page load therefore got slower as OTHER customers signed
  up. Indexed as `(user_id, created_at, id)`, which answers the sort as well as the
  filter.

- **`DatabaseAuthPolicies::overrideFor()` was the one policy read not memoised**, and the
  one called in a loop: `PasswordExpiry` and `MfaMandate` both walk the signed-in
  subject's memberships asking for each organization's override, from that same
  middleware. Measured on a console page before the fix: 17 queries at one organization,
  22 at four, 32 at nine — exactly two per organization, on every request. Now memoised
  per request, keyed by environment AND organization for the same reason
  `forEnvironment()` is, and cleared on every write.

### Testing

- The membership index is proven two ways: the sqlite query plan names it, and an
  engine-independent assertion checks it exists — the second is what runs on the Postgres
  and MySQL legs, where the plan syntax differs.
- The memo is proven by measuring from WARM and asserting zero further reads, rather than
  pinning a query count that would stop meaning anything the moment an unrelated read was
  added. Its invalidation and its environment keying are separately falsified.

## [0.66.0] - 2026-08-01

Found during a whole-platform review. Two of these are cross-tenant defects on the
sign-in path, and one is a migration blocker that presented as "wrong password".

### Fixed

- **`$2a$` and `$2b$` bcrypt hashes were rejected as if the password were wrong.**
  `NativePasswordVerifier::supports()` decided a hash was native by asking
  `password_get_info()`, which only ever recognizes what `password_hash()` EMITS — on
  PHP 8 that is `$2y$` alone, and it answers `algo: null` for `$2a$` and `$2b$`.
  Because the verifier is deny-by-default, every hash exported by a provider that
  writes those prefixes — most of them — failed authentication as an ordinary bad
  password. A customer migrating onto the platform would have watched their entire
  user base locked out, with nothing in any log saying why. `password_verify()` had
  handled all three correctly the whole time; only the gate in front of it was wrong.
  The class docblock had promised this support since it was written, so the claim was
  never true. Now proven against the canonical crypt_blowfish vectors rather than
  against hashes this process made itself.

- **A SAML assertion ID consumed by one tenant blocked every other tenant's.**
  `consumed_assertions.assertion_id` carried a GLOBAL unique index, but an assertion
  ID is chosen by the issuing identity provider and is only required to be unique
  within it — short and sequential IDs are common in the wild. Two customers' IdPs
  minting the same ID meant the second one's perfectly valid login was refused as
  "assertion replay detected": a cross-tenant denial of service on sign-in, and a
  targetable one. The replay key is now `(environment, connection, assertion id)` —
  single-use per issuing IdP, which is what the guard was ever defending. Same
  correction as `unique(jti)` on the DPoP table in 0.61.0, for the same reason.

- **Domain capture could be enabled on a domain nobody had proved they own.**
  `DomainVerification::setCapture()` left the verification check to its callers, and
  the callers disagreed — one console refused an unverified domain, the other did not,
  so the weaker of the two decided the rule. Capture routes every sign-in on an email
  domain to one organization's connection, so on an unverified domain it is one tenant
  claiming another's addresses. The check now lives in the service, where nothing can
  route around it. Disabling capture stays unconditional: withdrawing a claim is
  always safe.

### Added

- **`Mfa::disable()`** on the subject plane, audited as `user.mfa_disabled` — the same
  shape the account and operator planes have recorded from the start. Without this
  verb, an administrator resetting a second factor for someone who lost their
  authenticator had to delete the rows directly, so the single most privileged MFA
  mutation in the platform was the only one that left no trail. Every other MFA
  mutation was already audited.

- **`DomainNotVerified`**, thrown by `setCapture()`. Hosts that surface federation
  settings should catch it and show the DNS challenge rather than a generic failure.

### Testing

- **Frozen envelope vectors for `LibsodiumSecretBox`.** Every prior test sealed and
  opened in the same process, which moves both sides together: change the nonce
  length, add a version byte, swap base64url for base64, and a round-trip still passes
  while every secret already at rest becomes permanently unreadable. This box seals
  private signing keys, directory credentials and vault secrets. Two checked-in
  ciphertexts now pin the envelope format, so breaking it is a migration rather than a
  silent refactor.

- **Foreign password hashes** — the canonical openwall `$2a$` vectors, a `$2b$` hash,
  and argon2i/argon2id hashes generated out-of-process. These are what caught the
  bcrypt bug above; the previous coverage could only ever produce `$2y$`.

## [0.65.0] - 2026-07-27

### Removed

- **`EntitlementSource::License`.** The framework never wrote it; it existed so
  `cboxdk/laravel-id-licensing` could mark entitlements unlocked by a signed offline
  key. That layer is retired — the application this framework backs is now free to
  self-host with no key and no limits, so a source meaning "granted by a licence" has
  nothing left to mean. The on-prem licensing entry is gone from the docs for the same
  reason.

  A `license` value stored by a real licensed deployment will no longer hydrate. See
  [`UPGRADING.md`](UPGRADING.md).

## [0.64.0] - 2026-07-27

### Fixed

- **The audit chain's first entry deadlocked on MariaDB.** Appending serialises on the
  chain's anchor (sequence 1); on an *empty* chain there is none, and the locking read
  looking for it matched no row — which InnoDB answers with a **gap lock**. Eight
  processes opening one brand-new chain each held that gap and then needed an
  insert-intention lock inside it, so MariaDB 11.8 resolved the pile-up as SQLSTATE 40001
  rather than the duplicate key `record()` is written to absorb, and `attempts: 3` ran
  out. **6 of 800 appends lost.** Fixed by removing the cause rather than raising the
  budget: the anchor is now *found* with a plain read and *locked by primary key*, and an
  exact primary-key match takes a record lock that can never be a gap lock — so an empty
  chain takes no lock at all. The search runs **outside** the transaction, because under
  `REPEATABLE READ` a consistent read inside it fixes the snapshot the head read is then
  answered from; an earlier attempt that kept it inside made things strictly worse. Now
  **800/800 on `mariadb:11`**, and the full suite runs green there for the first time.
- **CI's rollback step never rolled anything back.** Testbench's rollback is `--path`-
  scoped to a single publishable migration, so 83 tables and 90 ledger rows survived it on
  an empty PostgreSQL, and `down()` was unverified on every engine. The replacement
  migrates every registered path into a throwaway database, resets across all of them, and
  requires **zero** tables and **zero** ledger rows before migrating back up. The assertion
  is the point — a rollback that does not verify emptiness is exactly how this went
  unnoticed. It found **five** broken `down()` methods, the worst of which left a stray
  `password_reset_tokens` behind after a full reset, under the very name whose collision
  with Laravel's skeleton migration breaks a greenfield install.

### Added

- **Audit checkpointing is schedulable** — `php artisan cbox-id:audit:checkpoint` signs
  every `(environment, scope)` chain that has advanced, idempotently and without locking.
  Nothing had ever scheduled `checkpoint()`, so `audit_checkpoints` was empty everywhere
  and `verifyCheckpointAnchor()` returned null on every call: the chain detects
  modification and sequence gaps by itself, but it cannot detect **truncation**, and a
  signed checkpoint is the only thing that catches that.
- **The schedule defaults to `false`, deliberately.** The GDPR-erasure design still to come
  needs exactly one *re-chain* of existing rows — hashing ciphertext instead of plaintext,
  so destroying a per-subject key leaves every hashed byte unchanged. Any checkpoint signed
  *before* that would afterwards report tampering that never happened, permanently, on
  evidence you may already have handed to a third party. Nothing has ever signed one, so
  the window is open and **the first signature closes it**. `UPGRADING.md` carries the
  four-step order — and says plainly that a deployment with no re-chain ahead of it should
  turn this on today rather than run an audit trail whose truncation nobody would notice.
- `OrganizationStatus::revokesAccess()`. The enum now answers the question the security
  layer was asking by hand, with an exhaustive `match` and no `default`, so a status added
  later fails static analysis instead of defaulting to "allowed" — which is precisely how
  `Deleted` slipped past three enforcement points in the consuming app.
- `Organizations::archive(string $id, string $actorId)`, so the status write and its audit
  entry both live behind the contract instead of a raw `save()` in a console view.

### Changed

- **BREAKING:** `Accounts::suspend()` and `Accounts::reactivate()` now take an `$actorId`
  and audit internally, matching `Organizations` and `PlatformOperators`. They previously
  took an id alone and recorded nothing, which forced every caller to remember the audit —
  and a second caller would have silently forgotten it. `reactivate()` is included even
  though only `suspend()` was reported: leaving it unaudited would make "who lifted this
  suspension" unanswerable directly beside an audited suspend.

## [0.63.0] - 2026-07-27

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **`POST /user-tokens/introspect` checked no scope at all.** It resolved the caller's
  environment API key and verified only that it was *valid*, while every other management
  route gates on a scope. A key issued with, say, only `directories:read` could introspect
  **every personal access token in the environment** and read back `sub`, `org`, `name`
  and `scope` — a deliberately narrow credential holding a capability it was never
  granted. Now gated on the existing `EnvironmentApiScope::UsersRead`: a successful
  response discloses user data about any user in the environment, which is exactly what
  `GET /users` already gates on, so minting an `introspect:*` scope would have added scope
  surface for a capability an existing scope already describes — and would have broken
  every key rather than only those that genuinely lacked user-read rights.
  **BREAKING:** an environment API key calling this endpoint without `users:read` now gets
  `403 insufficient_scope`. Audit issued keys before upgrading. The refusal is a 403 and
  not `active: false` deliberately: it is decided *before* the token is resolved, so the
  response is a constant function of the caller's own key and leaks nothing about any
  token — whereas answering `active: false` would make a relying party silently treat
  every live credential its users hold as revoked, reading a misconfiguration as a
  fleet-wide revocation. A test pins that the 403 is byte-identical for a known and an
  unknown token, so it cannot become an oracle by accident later.
- **An empty resource-family allow-list granted every family.** `UserApiTokenService`
  stored `$families === [] ? null : $families`, and `allowsFamily()` reads `null` as
  "unrestricted" — so a caller passing an **empty** allow-list, the most restrictive input
  possible, received a token permitted on **all** families. The most restrictive request
  produced the least restrictive result. Fixed with a `ResourceFamilies` value object that
  keeps *unrestricted*, *a list*, and *none* apart; the collapsing line is gone because
  `[]` is no longer a value the parameter can hold. An array cannot express the difference
  between absent and empty, and here that difference is a security boundary. Existing rows
  are untouched — `NULL` still means unrestricted, and the empty array is a value the old
  code could never write. The wire format is unchanged.
  **BREAKING (source-level):** `UserApiTokens::issue()` now takes `?ResourceFamilies`
  instead of `?array`.

### Fixed

- **A greenfield install could not migrate.** The package created `password_reset_tokens`,
  which Laravel's own `create_users_table` skeleton migration — present in every freshly
  scaffolded app — also creates, with a different shape. So `composer require
  cboxdk/laravel-id && php artisan migrate` failed with "table already exists" on every
  engine: the package's entire first-run experience for anyone who did not start from a
  stripped skeleton. Renamed to `cbox_id_password_reset_tokens`, with a rename migration
  guarded three ways — it returns early if the new name exists, if the old one does not, or
  if the table it finds lacks `environment_id` **and** `token_hash`. Laravel's skeleton
  table has neither, so this migration can never adopt, reshape or drop a table it did not
  create. The suite could not have caught this: the harness publishes the package's own
  users migration, so no test had ever migrated against a stock Laravel schema.
  `GreenfieldMigrationTest` now does, on SQLite and against a throwaway schema on a real
  PostgreSQL server.

### Added

- **A verified capability matrix** — a "What's supported" table in `README.md` and a new
  `docs/capabilities/` section, so an adopter can answer "do you support X?" in seconds.
  Five grades defined at the top of every table, and `docs/security/standards.md` becomes
  the canonical RFC/protocol matrix. Every row was checked against `src/` rather than
  written from the existing docs — which disproved eleven claims, corrected below.

### Changed

- **Documentation claims that the code does not back have been corrected.** The matrix
  above was built by verification, and these are what it found:
  `compliance.md` offered *signed commits* as the SOC 2 CC8.1 control (`git log
  --format=%G?` returns `N` for every commit, releases included); the GDPR Art. 17 claim
  survived an earlier rewording and was still false, since no erasure primitive exists and
  the package holds contact PII in its own never-pruned tables; `fapi.md` claimed PAR was
  *enforced* (`require_par` is read in exactly one place — building the discovery
  document) and RFC 9207 `iss` *always on* (the package emits no authorization response);
  step-up "sudo" re-authentication was claimed as a mitigation in four control rows and
  does not exist; and `standards.md` described `/authorize` behaviour throughout —
  **this package does not serve `/authorize`**, and was claiming the host app's work as
  its own. Password policy had moved into the framework several releases ago and was still
  attributed to the app layer; under-claiming is a documentation bug too.
- `TotpAuthenticator`'s docblock cited **RFC 4238** for HOTP. HOTP is **RFC 4226**.
- The SCIM `ServiceProviderConfig` advertised `documentationUri` as `<app>/docs`, a route
  this package does not register and most hosts do not either — so a connector surfacing
  that link during setup sent the operator to a 404. It is OPTIONAL in RFC 7643 §5 and is
  now omitted unless `cbox-id.scim.documentation_uri` is set.
- `Directories::resolveByToken()` promised a constant-time comparison the implementation
  never performed.
- `UPGRADING.md` carried the last surviving copy of the fabricated
  `urn:oasis:names:tc:SAML:2.0:nameid-format:unspecified`. No such value exists — SAML 2.0
  carries the 1.1 URN forward, and `tryFromPolicyUrn()` returns null for the 2.0 spelling,
  so an SP configured from that line is answered `InvalidNameIDPolicy`.

## [0.62.0] - 2026-07-27

### Fixed

- **PostgreSQL handed every short identifier back to PHP blank-padded, and the whole
  platform mis-compared it.** `$table->ulid($column)` is `$table->char($column, 26)`,
  and PostgreSQL implements `CHAR` as `bpchar` — blank-padded — so a value shorter than
  the declared width is stored padded and PDO passes the padding straight through.
  `$row->environment_id === 'env_test'` was therefore **false** for a row whose
  `environment_id` is `env_test`. It hid perfectly: Postgres' own `=` and `length()`
  strip trailing blanks, so every check from a SQL client passed, and real ULIDs are
  exactly 26 characters so nothing pads in a normal deployment. It cost **338 of 1358
  tests on postgres:16** — `BelongsToEnvironment` throwing `CrossEnvironmentAccess` on
  a row's own environment, and `DatabaseAuditLog::verifyChain()` reporting `content
  hash mismatch (tampered)` on an untouched chain because `canonicalPayload()` hashes
  `organization_id` unpadded at write and padded at read. All 225 identifier columns
  are `varchar` now: the create migrations say `string($column, 26)`, and
  `2026_07_26_000100_convert_char_columns_to_varchar` converts an existing database
  (casting `bpchar` to `varchar` strips the padding already on disk, so no backfill is
  needed). Verified by diffing `pg_dump --schema-only` of an upgraded v0.61.0 database
  against a fresh install: zero difference, indexes and foreign keys intact under their
  original names. See `UPGRADING.md` for locking, sizing and rollout order.
- **Membership rosters were not totally ordered, so a page could start in the middle.**
  `MembershipService::paginateForOrganization()` sorted on `created_at` alone — a
  second-granularity timestamp that ties across every row of a roster built in one
  request. `ORDER BY` a tied key promises nothing, and under `LIMIT`/`OFFSET` it lets a
  row appear on two pages or on none; PostgreSQL's top-N heapsort made it visible by
  returning the second member first. Now ordered by `created_at` then `id` (a ULID, so
  the tie-break runs the same direction). A pre-existing defect that the padding bug
  above was masking — both fail the same test, and only the second one is left once the
  padding is fixed.

### Changed

- **CI runs the full test suite on PostgreSQL**, not just the migrations. The `engines`
  job promoted `postgres:16` from migrations-only now that the padding defect above is
  fixed and the cell is green — 1359 passed, measured twice, against a real
  PostgreSQL 16. MySQL 8 also lands 1359, and SQLite 1358 passed with 1 skipped.
  MariaDB stays migrations-only for the first-append deadlock documented in
  `docs/requirements.md`; its failure count is carried forward from v0.61.0 rather
  than re-measured.
- **`tests/Feature/SchemaPortabilityTest.php` fails the build if a `CHAR` column
  helper reappears** in a migration — `char()`, `ulid()`, `uuid()`, `foreignUlid()`,
  `ulidMorphs()` and friends. It is a token scan rather than a schema assertion so it
  runs on SQLite, catching the mistake on a contributor's first local run instead of in
  the server-engine job.
- **`docs/requirements.md` no longer claims the migrations are tested in both
  directions.** The `Migrations up` CI step does not roll back: measured on
  `postgres:16` against an empty database, 83 tables and 90 rows in `migrations` remain
  when it finishes, on this commit and on v0.61.0 alike. Testbench's rollback is scoped
  by `--path` to the one publishable migration the TestCase loads directly. The step is
  renamed and the docs corrected; making it real is separate work.

## [0.61.0] - 2026-07-27

### Fixed

- **The migrations could not run on MySQL or MariaDB at all**, while
  `docs/requirements.md` and the installation guide promised "any database Laravel
  supports — MySQL/MariaDB, PostgreSQL, SQLite, SQL Server". `php artisan migrate` died
  on the fifth table: twenty `json` columns across sixteen migrations carried a literal
  `DEFAULT '{}'` / `DEFAULT '[]'`, which MySQL has never allowed on a BLOB/TEXT/JSON
  column (error 1101 — since 8.0.13 it takes only the parenthesised *expression* form).
  Behind that were three more walls, each of which also stops the migration dead:
  `relationship_tuples` and `vault_secrets` had composite indexes over InnoDB's
  3072-byte key limit (utf8mb4 charges 4 bytes per character, so seven `varchar(255)`
  columns is 6224), and two generated index names exceeded MySQL's 64-character
  identifier limit (error 1059). `json` defaults now go through
  `Cbox\Id\Kernel\Database\JsonDefault`, which emits `DEFAULT (json_object())` /
  `DEFAULT (json_array())` on MySQL and MariaDB and the **unchanged literal** on every
  other engine — the PostgreSQL and SQLite DDL is byte-identical to before. Columns
  inside the over-long indexes were given explicit lengths and three index names were
  shortened; see `UPGRADING.md` for the exact list and why no `ALTER` is shipped.
- **Three index names were over PostgreSQL's 63-character identifier limit** and were
  being silently truncated, so the same index carried a different name depending on the
  engine. All three are now named explicitly.
- `InteractsWithFederation::fakeDns()` tripped static analysis at level max after a
  dependency update taught larastan to infer `app(DnsResolver::class)` from the container
  *binding* — from which it concluded the concrete resolver is the only possible result
  and the `FakeDnsResolver` short-circuit is unreachable. Rebinding that contract is
  exactly what the method does, so the inference was wrong about runtime rather than the
  code being wrong. Resolved through the PSR-11 `get()` accessor, which returns `mixed`
  and lets the `instanceof` mean what it says — rather than silencing the check.

### Added

- **CI runs against real database servers.** A new `engines` job migrates forwards and
  back against `mysql:8`, `mariadb:11` and `postgres:16` service containers, and runs
  the full suite on MySQL (1358 passed, against MySQL 8.4). Running only on sqlite —
  which accepts literal json defaults and caps neither index keys nor identifiers — is
  precisely why the MySQL claim went sixty releases without anyone noticing it was
  false.
- The MariaDB and PostgreSQL cells run **migrations only**, and the job says why in
  full. Adding it surfaced two pre-existing product defects that stop the suite passing
  there, neither of them a schema problem:
  - PostgreSQL: `$table->ulid()` is `char(26)`, PostgreSQL blank-pads `CHAR` on read
    where MySQL and SQLite strip it, so every environment key shorter than 26
    characters fails the tenancy guard (`row belongs to [env_test⎵⎵⎵…], acting as
    [env_test]`) — 338 of 1358 tests. Invisible in production because a real
    environment id *is* a 26-character ULID.
  - MariaDB: eight processes appending to an **empty** audit chain deadlock on the gap
    lock the `FOR UPDATE` takes where the anchor row does not exist yet. MariaDB raises
    SQLSTATE 40001 rather than the duplicate key `DatabaseAuditLog::record()` absorbs,
    and `attempts: 3` is not enough for eight contenders: 6 of 800 appends failed —
    loudly, with an exception, not silently. The identical test lands 800/800 on
    MySQL 8.4.

### Changed

- **`docs/requirements.md` and the installation guide now state which engines are
  tested, not which are hoped for.** SQL Server was never run by anybody and is no
  longer claimed. MySQL's floor is documented as 8.0.13 and MariaDB's as 10.2, the
  releases that introduced expression column defaults.
- On a server driver (`DB_CONNECTION=mysql|mariadb|pgsql`) the suite now runs under
  `RefreshDatabase` — migrate once, then a transaction per test — instead of Testbench's
  migrate-and-roll-back-around-every-test. The sqlite default is unchanged. Rebuilding
  ~390 DDL statements per test costs over a minute a test on a real server, which would
  have made the job above unrunnable.

## [0.60.0] - 2026-07-27

### Fixed

- **Audit entries were silently lost whenever two writers appended to the same chain.**
  Appends serialised on the chain HEAD, chosen by `ORDER BY sequence DESC LIMIT 1 FOR
  UPDATE`. Under `READ COMMITTED` a blocked `FOR UPDATE` re-checks its predicate against
  the row it waited on, not against the `ORDER BY` that selected it — so a waiter woke
  still holding the old head, computed a sequence that had just been taken, and died on
  the unique key with SQLSTATE 23505. `DB::transaction(…, attempts: 3)` never covered it:
  Laravel's `ConcurrencyErrorDetector` matches 40001 and deadlock messages, not 23505.
  Measured on PostgreSQL 16, 8 processes × 100 appends to one chain landed **101 of 800**
  rows; it now lands 800 of 800, gapless, with `verifyChain()` valid. These writes sit on
  pre-authentication paths, so a credential-stuffing burst was the trigger, and callers
  that `report()` and continue lost their entry without a trace. Appenders now serialise
  on the chain's anchor row (sequence 1), whose predicate is an equality on the unique key
  and therefore cannot go stale. Costs one extra indexed round-trip: single-writer p50
  12.4 ms → 13.3 ms. The docblock claiming a concurrent write "is never silently lost" was
  false and has been replaced with the actual semantics.

### Changed

- **BREAKING (error paths only):** an append that cannot claim a free position within its
  retry budget now throws `CannotAppendToAuditChain` instead of surfacing the driver's
  `UniqueConstraintViolationException`. A hole in a tamper-evident trail is
  indistinguishable from a deletion when someone later runs `verifyChain()`, so it must be
  loud. Callers catching `QueryException` around `AuditLog::record()` should catch
  `CannotAppendToAuditChain` as well.

## [0.59.1] - 2026-07-27

### Added

- `HookPoint::label()` and `::description()`. A hook point is chosen by a human in a
  console, and without copy a view renders `$case->name` — so an admin picked between
  "PrePasswordChange" and "PostPasswordChange", PHP identifiers as product copy. Tolerable
  while there was one point; not with six. The copy lives on the enum rather than in a
  host's view because the enum is a public contract and every console would otherwise
  restate it. `description()` always says whether the hook can refuse, since that is the
  difference an admin needs before wiring a URL that can stop people signing in.

## [0.59.0] - 2026-07-27

### Added

- **Five new inline-hook points, so a host can gate more than token issuance.**
  `HookPoint` shipped exactly one point, `token_minting`, and the file's own comment
  admitted it. The pipeline underneath it was always generic, so the gap was call sites,
  not machinery. Added `post_login` (after authentication, before the session row is
  written — every login path, because it fires from `SessionManager::start()`),
  `pre_registration` / `post_registration` (around subject creation) and
  `pre_password_change` / `post_password_change` (around a credential write). Each has a
  typed payload value object under `ExternalActions\Payloads\`, so the wire shape lives
  somewhere a change to it is a reviewable edit rather than an array literal buried in a
  service. `ActionContext::for()` builds a context from one, and cannot mismatch the hook
  point with its payload.
- **A per-hook-point fail policy, because "fail closed" is not one answer.** A hook that
  is consulted and denies always denies — that is not configurable. A hook that could not
  be consulted at all now answers to `HookPoint::failPolicy()`: the gates
  (`token_minting`, `pre_registration`, `pre_password_change`) deny, because a control
  that fails open is not a control; `post_login` allows, because failing closed on the
  hottest path in the product hands one customer-controlled URL the power to lock a whole
  tenant out of everything, the admin console included. Override per point with
  `external_actions.fail_policy.<hook>`, or globally with `external_actions.fail_open`.
- **`docs/extension-points/hook-points.md`** — every point, its payload, what a deny
  stops, and what an unreachable endpoint means there.

### Changed

- **`external_actions.fail_open` now defaults to unset rather than `false`.** A literal
  `false` means "close every point", which would have overridden `post_login`'s
  deliberately open default. Unset lets each point's own default apply. Behaviour for
  `token_minting` is unchanged either way, since its default is closed.
- **A deny at a `post_*` hook point is audited and then folded to an allow.** Those points
  run after their operation has committed, so a veto has nothing to stop. Enforced in
  `DefaultActionPipeline` rather than trusting each call site to ignore the outcome; the
  `external_action.denied` audit entry carries `vetoable: false` so the operator still
  sees it.
- **`fakeActionTransport()` now also rebuilds the singletons that hold the pipeline**
  (`SessionManager`, `Subjects`, `TokenIssuer`), which otherwise kept calling the real
  transport through the instance they already had.

### Notes

- No separate `credentials_exchange` point was added. `token_minting` already fires on the
  `client_credentials` grant, with `user_id` null and `grant` set — a second point would
  be a second name for the same call, with a second endpoint to register and a second
  timeout to pay.
- The registration and password-change points carry no organization (neither operation
  has one), so only environment-level endpoints fire for them. `token_minting` and
  `post_login` are org-scoped as before.

## [0.58.0] - 2026-07-26

Typed-model debt from the platform review. **Two breaking contract changes** — see
`UPGRADING.md`.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **A transposed key pair could publish the private key at the JWKS endpoint, and
  nothing caught it.** `DatabaseKeyManager` returned `array{0: string, 1: string}`
  destructured as `[$public, $private]` — both `string`, so swapping them was invisible
  to PHPStan, Pint and the type system, and the two build sites (sodium, OpenSSL) look
  nothing alike. Replaced with a `GeneratedKeyPair` value object, constructed with named
  arguments so reordering the constructor cannot re-transpose them.

  Six swap-detection tests were added across RS256/ES256/EdDSA, and they were needed:
  under a deliberate transposition the **pre-existing** EdDSA test still passed, so the
  Ed25519 secret key would have been published as an OKP JWK silently. The new guards
  assert the stored public column carries no private material, that the sealed half is
  the private key, that the two are provably the same pair, and that the JWKS contains
  no `d`/`p`/`q` and no PEM private block.

### Changed — breaking

- `Memberships::add()`, `Memberships::changeRole()` and `Invitations::invite()` take
  `MembershipRole`, not `string`. The enum's own docblock said an invalid role should be
  "a type error, not a silent fail-open" — the contract signature defeated that, so a
  typo was an uncaught `ValueError` (a 500) invisible to static analysis, on data feeding
  the last-owner guard and the console's admin checks. Parsing moved to the real edges:
  the CLI validates `--role` up front, and an unrecognised role in an import row is now a
  per-row `ImportError` naming the accepted values.
- `Connections` gains `samlConfig()` / `oidcConfig()` returning typed configuration.
  `config(): array` remains the unseal primitive, and `create()` deliberately keeps its
  array — a Draft connection is legitimately incomplete, and validating at create would
  make drafts unrepresentable.

### Fixed

- The membership audit payload recorded the raw string while the row persisted the enum,
  so a case-variant input diverged between the audit trail and the stored value.
- Eight `@var` annotations asserted a shape over decoded JSON that nothing verified;
  replaced with validating parses.
- `DatabaseDirectoryGroups` still carried a duplicated copy of the RFC 7644 PATCH op list
  as string literals; it now uses `ScimPatchOp` with an exhaustive `match`.

## [0.57.0] - 2026-07-26

Output of a whole-platform review loop: ten specialist passes, an independent
second-vendor review, adversarial verification of every high-severity finding, and a
re-review that caught eight regressions the fixes themselves introduced. Four findings
were refuted and dropped rather than "fixed"; several were re-priced down. See
`UPGRADING.md` — **this release refuses things earlier versions accepted.**

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Invitations are environment-scoped.** `invitations` was the only credential-bearing
  table without an `environment_id`, and `byToken()` matched on the hash alone — so a
  token minted in one environment was redeemable on any host, minting an active user, a
  session, and tokens from the *victim* environment's issuer. Adding a plane gate would
  not have fixed it: a tenant subdomain is a valid subject-plane host.
- **`MembershipService::add()` refuses an organization from another environment.**
  `runAs()` sets only the tenant dimension, `BelongsToEnvironment` auto-fills on INSERT,
  and `memberships` has no foreign key — so a foreign org id was taken on trust.
- **Singletons no longer capture the `scoped` tenancy context.** A queue worker's
  `forgetScopedInstances()` unsets the binding without resetting an object a singleton
  already holds, so job B was written, keyed and delivered under job A's environment.
  Environment-owned models failed closed; the outbox, the audit chain and the JWKS cache
  did not. **Fifteen** classes were affected. `ScopedContextCaptureTest` now enforces the
  rule that a code comment had failed to.
- DPoP replay keys on `(jkt, jti)` rather than a global `jti`, closing a
  pre-registration DoS; proofs carry `environment_id`.
- `Permission`'s global scope fails closed instead of exposing the cross-environment
  catalog when no environment is in context.
- Entra directory pagination pins `@odata.nextLink` to the Graph host — the last
  outbound path not behind the SSRF gate.
- Webhook endpoints refuse plaintext `http://`.
- Tenant-routing cache keys use SHA-256 rather than a non-cryptographic hash.

### Added

- `cbox-id:prune` with per-table retention. **`audit_logs` is deliberately excluded**:
  the chain is hash-linked and checkpoint-anchored, so pruning below a checkpoint breaks
  verification and pruning to one removes the row the tamper check reads. Bounding audit
  growth needs export-then-rechain, not a sweep.
- `cbox-id:events:backlog` (`--json`, `--fail-over=N`), a `RelayBacklog` contract, and a
  configurable relay limit/cadence. Relay lag was previously silent.
- Webhook circuit breaker with self-healing, and outbox dead-lettering with an attempt
  counter — a listener that always throws no longer retries forever.
- SAML: POST-binding SLO, per-environment frozen EntityID, SP key material (so logout
  responses are signed and SP metadata carries a `KeyDescriptor`), multi-cert IdP
  rollover.
- `PackageConfigMerger` — published config now merges key-by-key, so a partial host
  config no longer discards package defaults. Lists replace rather than append.
- Cross-language golden fixtures for webhook signing and RFC 7638 thumbprints; real-vector
  tests for PKCE (RFC 7636 App. B), `at_hash`, and JWKS-only verification.

### Changed — behaviour visible to integrators

- Webhook delivery is **queued**. A host without a running queue worker will persist
  delivery rows and send nothing.
- `/authorize` returns `invalid_scope` for scopes outside the client's registered set,
  instead of silently narrowing. **Audit registered scope lists before deploying.**
- `scope` is echoed from `/oauth/token` whenever granted differs from requested
  (RFC 6749 §5.1).
- `max_age` and `acr_values` are honoured; an unsatisfiable request returns
  `unmet_authentication_requirements` rather than a downgraded token.
- SCIM: malformed `Operations` → 400; unknown-id DELETE → 404; `active` parsed strictly
  (case-insensitively); `GET /Groups` omits `members` unless requested;
  `userName`/email equality is case-insensitive on **all** drivers — Postgres tenants
  with case-variant duplicates will newly see `409` and need reconciliation first.
- SAML: `NameIDPolicy` enforced; signed `AuthnRequest`s require `Destination` and must
  address the receiving location; requests are single-use and time-bounded.
- `/up` returns JSON.

### Fixed

- `deleteRole()` left `group_role_mappings` behind, wedging directory reconciliation and,
  because the relay released the claim, blocking every listener registered after it —
  permanently.
- Orphaned webhook deliveries starved the retry sweep at the head of an ascending queue.
- The whole env-console role surface wrote through the query builder, leaving privileged
  changes with no audit entry and no domain event.
- `CachedEntitlements` no longer resurrects a pre-invalidation snapshot when its version
  counter is evicted.
- Redirect-binding SAML signatures verify over the transmitted octets, and survive the
  login hand-off.
- Missing indexes on token, session and delivery sweep columns.

## [0.56.0] - 2026-07-25

**Upgrading:** two contract changes. `PasswordPolicyGuard::assertAcceptable()` now
REQUIRES the subject id — the no-subject case is `assertAcceptableForNewSubject()`.
`Roles` gains `unassignAll()`; a custom implementation must supply it.

### Fixed

- **A removed member kept their RBAC grants.** `MembershipService::remove()` deleted the
  membership and left `role_assignments` behind. Assignments are read by (organization,
  user) with no membership join, so this was not litter: re-adding the person later
  silently restored privileges nobody re-granted, and anything reading assignments
  directly still saw them held. Removal now revokes them in the same transaction, one
  `role.unassigned` event per role. A deployment binding external RBAC owns its own
  grants, so its refusal is caught and the removal proceeds.

### Changed

- `PasswordPolicyGuard::assertAcceptable()` takes a non-optional `string $userId`, and
  the genuine no-subject case — signup, or an administrator seeding an account — is the
  separate `assertAcceptableForNewSubject()`. The optional argument used to buy a caller
  a weaker check for free: no reuse history, and the bare environment baseline instead of
  the organizations binding the subject. An exemption reachable by forgetting an argument
  looks identical to the case where it is correct.

## [0.55.1] - 2026-07-25

### Fixed

- `DatabaseAuthPolicies` memoized the environment baseline without keying the memo by
  environment. It is a singleton, and one process legitimately visits several
  environments — a queue worker draining jobs for different tenants, and every
  `PlatformRoot::run()` that steps into tenant 1 and back — so the first environment's
  policy was answered for all of them. Latent while the policy had few consumers;
  load-bearing since 0.53.0 put it on every credential path, where it would apply one
  tenant's password floor to another's people, in the direction tighten-only exists to
  forbid.

## [0.55.0] - 2026-07-25

**Upgrading:** `PlatformRoot::environment()` no longer accepts a configured default that
matches no environment row, or one that belongs to an account. A deployment relying on
either loses its platform root — which is the point; see below. `cbox-id:doctor` reports
which case you are in.

### Fixed

- **The platform root could be a customer's environment.** `PlatformRoot` fell back to
  `cbox-id.environments.default` without checking what that key pointed at. A deployment
  that never stamped an `is_default` row and aimed the config at a tenant environment
  wrote every account member's subject INSIDE that customer's tenant — where that
  customer's environment admins (including a Developer, a role explicitly denied the
  member roster) could set the password through the admin-password feature and sign in
  as an account member. The fallback now resolves to a real row and refuses one an
  account owns.
- **Three components resolved "the default environment" in two different orders.**
  `Api\Http\Middleware\ResolveEnvironment` preferred the config key while
  `PlatformRoot` and the console's `SetEnvironment`/`PlaneResolver` preferred the
  `is_default` row, so a deployment with both would answer "which tenant is this
  request" one way over the API and another on the web. All of them now take the row
  first: it is what the installer stamps and it survives horizontal scaling.

### Added

- A `cbox-id:doctor` check for the platform root. It fails on a configured default that
  belongs to an account, and warns when the root is resolved from config rather than a
  stamped row — the silent-at-runtime misconfigurations, which otherwise surface as an
  incident rather than a deploy-time message.

## [0.54.0] - 2026-07-25

`AuthPolicy`'s remaining three fields stop being decoration. `maxAgeDays`, `mfa` and
`lockoutThreshold` were stored, inherited and tightened correctly, and read by nothing.

**Upgrading:** two new tables. `password_ages` is seeded with every existing subject at
the upgrade time, so a `maxAgeDays` policy starts its clock for everyone at once rather
than never applying to anyone who predates it. Turning any of the three fields on now
changes behaviour where it previously changed nothing — review what your environments
have set before deploying.

### Added

- **`Identity\Contracts\PasswordExpiry`** — whether a subject's password has outlived
  `maxAgeDays`. Backed by `password_ages`, stamped by the credential primitive. A
  subject with no recorded age never expires: their credential predating this being
  tracked is not evidence of an old password.
- **`Identity\Contracts\MfaMandate`** — whether a subject still owes the tenant a second
  factor. Expressed as a question rather than a refusal, because turning away someone
  with no factor locks out precisely the people who need to enrol. A confirmed TOTP
  factor and a registered passkey both satisfy it.
- **`Identity\Contracts\LoginAttempts`** — per-SUBJECT failed-attempt counting and
  lockout at `lockoutThreshold`. Distinct from the IP-keyed rate limiting a sign-in form
  does: an attacker spreading guesses across a botnet never trips an IP limit, and a
  shared office NAT trips one with nobody being attacked.

### Changed

- `DatabaseAccountMembers` and `DatabaseSubjects` stamp the password age wherever a
  credential is written, for the same reason the policy is applied there.
- `docs/security/password-policy.md` documents all three, including the two durations
  that are deliberately NOT tenant-configurable: an indefinite lockout is a
  denial-of-service tool, and a counting window that never resets locks out people who
  occasionally mistype.

## [0.53.0] - 2026-07-25

The authentication policy is now applied where credentials are written, instead of on
whichever caller remembered to ask for it.

**Upgrading:** behavioural. `Subjects::create()` and `Subjects::setPassword()` throw
`PolicyViolation` for a password below the tenant's floor. Any code path that sets a
password with a value the policy refuses now fails where it previously succeeded —
including seeders, factories that go through `Subjects`, and plaintext bulk import.
Hash import (`storeCredential()`) is unaffected. A host application binding its own
`Subjects` resolver should apply the guard in the same two methods; the contract's
docblock says so.

### Added

- **`Identity\Rules\PasswordMeetsPolicy`** — a validation rule so a form surfaces a
  policy refusal on the field instead of as an unhandled exception. Use it *instead of*
  a hardcoded `min:` rule, not beside one: a fixed number cannot know what the tenant
  requires, and the smaller of the two silently defines the experience.
- `docs/security/password-policy.md` — where enforcement lives and why, how the
  organization is inferred when a caller does not name one, and what plaintext import
  means.

### Changed

- `DatabaseSubjects::create()` and `setPassword()` apply the policy and record the
  resulting hash in the reuse history themselves. Signup, invitation acceptance,
  self-service reset, administrative assignment and plaintext import all inherit it.
  `PasswordResetService` and `AdminPasswordService` lose their bolted-on copies.
- When no organization is named, `PasswordPolicyEnforcer` resolves the environment
  baseline tightened by **every** organization the subject belongs to. Resolving the
  bare baseline would let a member of a strict organization satisfy the looser
  environment floor through any path that did not carry org context.
- `DatabaseAccountMembers::activate()` and `resetPassword()` are transactional, so a
  policy refusal cannot leave the member row holding a rejected password or spend a
  single-use reset link on the way out.

### Fixed

- The password policy was enforced on administrative assignment and nowhere else. An
  environment demanding 24 characters got 24 from an admin and 12 — whatever the calling
  form hardcoded — from every self-service path.

### Known limitations

- `AuthPolicy`'s `mfa`, `lockoutThreshold` and `maxAgeDays` are stored, inherited and
  tightened correctly but **no sign-in path reads them**. They describe an intent the
  authentication flow does not yet act on.

## [0.52.0] - 2026-07-25

Unified account identity. An account member's **subject** becomes the credential of
record: members are ordinary subjects in the platform-root environment, holding a
membership in their account's organization. The account keeps its ownership and billing
role — what it loses is its own parallel way of authenticating people.

**Upgrading:** breaking. `account_members` gains `subject_id`, and credential operations
(`verifyPassword`, `resetPassword`, `activate`) now act on the member's subject. A
deployment with existing account members needs those subjects minted before sign-in
works; there is no backfill migration, because the platform had no external consumers at
the time of the cut.

### Added

- **`Platform\PlatformRoot`** — the single answer to "which environment is tenant 1".
  Subject and membership writes run inside its scope, since both rows are
  environment-owned and would otherwise be written against whatever scope happened to be
  current.
- `accounts.organization_id` and `account_members.subject_id`; `AccountProvisioner`
  creates the account's organization in the platform root alongside the account.
- `EnvironmentAdminGrant::$subjectId` — the signed handoff now carries the subject.

### Changed

- `DatabaseAccountMembers::create/invite` mint the member's subject in the platform root
  and add a membership in the account's organization. Credential verification and reset
  go to that subject.
- `remove()` revokes the organization membership and deactivates the subject unless
  another account still holds them.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **An invited member's subject is minted deactivated.** An invitation must not be a way
  in before it is accepted.
- **An address that already has a subject is reused, never re-credentialed.** Otherwise
  inviting an email you do not control would reset that person's password.
- Account members inherit the tenant password policy, administrative password expiry and
  the SSO mandate, because they authenticate as subjects — previously none of those
  applied on the account plane.

## [0.51.0] - 2026-07-25

Second platform-review loop. Every finding was adversarially verified before it was
fixed: four of nine P1 reports were refuted and dropped (SAML SSO's missing org gate is
the intended environment-owned model; WebAuthn challenge replay is closed by the host
contract; device/CIBA approval derives the organization server-side; the JWT leeway
window is guarded by try/finally and unreachable without Octane).

**Upgrading:** `tenant_assignable` in an app manifest is now OPT-IN. A declared
permission without an explicit `"tenant_assignable": true` becomes internal on the next
manifest sync, where it was previously tenant-assignable by default. Review your
manifests before upgrading if tenants compose app permissions into their own roles.

### Added

- **Per-environment and per-organization authentication policy** (`AuthPolicies`,
  `AuthPolicy`). Minimum length, breach checking, maximum age, reuse history, MFA
  requirement and SSO enforcement. An environment sets the baseline; an organization may
  override it, but `AuthPolicy::tightenedWith()` takes the STRICTER value of every field,
  so an override can never weaken the operator's floor. `PasswordPolicyGuard` is the one
  enforcement point every credential path runs through. Two additive migrations
  (`auth_policies`, `password_history` — hashes only, pruned to the configured depth).
- **Administrative password assignment** (`AdminPasswords`). Sets a subject's credential
  directly — legitimate because this platform owns its user records — as either a
  temporary hand-off (must be replaced at next sign-in, with an optional deadline after
  which it stops authenticating) or a permanent password, with the revocation blast
  radius an explicit choice (`PasswordRevocationScope`). Every call is audited with the
  actor and their stated reason, and is held to the tenant's password policy.
  Authorization is deliberately the caller's responsibility. Additive migration
  (`password_change_requirements`).
- **`BreachedPasswordCheck`** contract, shipped with a deliberately-inert
  `NeverBreachedCheck` default: the lookup is a network call against a service the host
  operates, so the library refuses to imply protection it never wired up.
- **`cbox-id:doctor` warns when `authorization_endpoint` is unconfigured.** OpenID
  Connect Discovery §3 marks it REQUIRED, and a host that never set it shipped a
  discovery document conformant OIDC clients refuse to initialize against, with nothing
  surfacing that. A warning rather than a failure, because an OAuth-only
  (client_credentials) deployment legitimately has none.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **One-time credentials are claimed with a conditional update, not a read-then-write.**
  Password-reset tokens, TOTP steps and MFA recovery codes could each be consumed twice
  by concurrent requests presenting the same value — spending one reset token on two
  password changes, or one recovery code on two sessions. Each now acts only if it won
  the row.
- **Last-owner protection locks the owner rows before counting.** Two owners each
  demoting or removing themselves at the same moment both read a count of two, both
  concluded they were not the last, and both committed — leaving an organization with no
  owner and no way to appoint one.
- **SCIM `User` PATCH rejects an unknown or missing `op`** with `400 invalidSyntax`
  (RFC 7644 §3.5.2). It previously fell through to a silent `replace`, so a typo'd
  operation mutated the resource and the calling IdP recorded a write that never
  happened. The Group path already enforced this; Users did not.
- **`tenant_assignable` is opt-in** (see Upgrading above): an omitted field no longer
  widens tenant self-serve access.

### Fixed

- **`at_hash` derives from the id_token's own signing algorithm** (OIDC Core §3.1.3.6)
  rather than a hardcoded SHA-256. Correct only because id_tokens happen to be RS256;
  an EdDSA id_token (Ed25519 signs over SHA-512) would have carried a digest a strict
  relying party rejects.
- **Environment-wide audit browse no longer filesorts.** Adds the
  `(environment_id, sequence)` index; the organization-filtered export cursor already
  had its own composite and is unaffected.
- Manual permissions authored in a console are stamped with their authoring environment.
  Additive backfill migration derives the environment from each row's bound roles where
  unambiguous; it is intentionally irreversible (`down()` is a no-op, because a set value
  cannot be told apart from a pre-existing one).

### Changed

- **The Usage kernel no longer imports a domain module.** `UsageReconciler` depends on a
  new `SeatCensus` contract (implemented in the Organization module) instead of
  `Organization\Contracts\Memberships`. `src/Kernel` now imports no domain module at all.
- Device/CIBA poll status and service-account status are typed enums (`GrantPollStatus`,
  `ServiceAccountStatus`) — the token-mint guard was a string comparison. Platform
  repositories write those enums instead of raw strings past their casts.

### Tests

- **SAML XML Signature Wrapping**, both classic placements: the genuine signature stays
  valid and a forged assertion is smuggled beside it. Refused by the single-assertion
  rule. Verified non-vacuous — the test fails if that guard is removed.
- Recovery-code single-use, the org-can-only-tighten policy invariant, and an
  administrator being held to the tenant policy.
- Two test files declared `SP_ACS` at global scope with different values; load order
  silently decided which URL was tested.

## [0.50.0] - 2026-07-24

Bring-your-own RBAC. The platform can now run its AuthN/SSO/OAuth/OIDC/SCIM stack on
top of an external authorization backend (e.g. an existing `spatie/laravel-permission`
install) instead of its own RBAC — see the `cboxdk/laravel-id-spatie` adapter.

### Added

- **External access-control driver** (`access_control.driver`, `builtin` default or
  `external`). Under `external` the built-in RBAC tables and their migrations are not
  loaded, and the `AccessChecker`/`Roles`/`GroupRoleMappings` contracts fall back to a
  deny-by-default: `NullAccessChecker` refuses every check and stamps empty token
  claims, while `UnboundRoles`/`UnboundGroupRoleMappings` throw `ExternalRbacNotBound`
  so a write or SCIM group→role sync fails loud rather than writing to absent tables.
  A host binding wins over the fallback. See `docs/extension-points/custom-rbac.md`.

### Changed

- The built-in RBAC migrations moved into a `database/migrations/access-control/`
  subdirectory so the auto-loader can gate them on the driver (the shared loader's glob
  is non-recursive). Migration publishing flattens every migration into the host's
  `database/migrations`, so published output is unchanged. No behavior change under the
  default `builtin` driver.

## [0.49.0] - 2026-07-24

Platform-review remediation. Every finding was adversarially verified before it was
fixed; the SSRF-redirect and PAR-under-validation reports were refuted and dropped.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Refresh-token rotation is now idempotent within the reuse-grace window.** A replayed
  token in the window returned a second, independent live token; it now returns the same
  successor, so a stolen token cannot be laundered into its own lineage. Reuse detection
  past the window (whole-family revocation) is unchanged. Adds an encrypted
  `successor_token` column (additive migration).
- **Token exchange requires proof-of-possession for sender-constrained tokens (RFC 9449).**
  A DPoP-bound subject token can no longer be exchanged without a DPoP proof matching its
  `cnf.jkt`; the issued token inherits the binding.
- **OIDC federation enforces `azp` on multi-audience id_tokens (OIDC Core §3.1.3.7).** A
  token naming more than one audience is rejected unless it carries an `azp` equal to the
  configured client id.
- **Permission catalog is environment-scoped.** App-declared permissions carry an
  `environment_id` (backfilled from the declaring client) and are visible only within
  their environment; manual permissions remain platform-global. Closes a cross-environment
  read/bind of another tenant's declared permission keys. (Additive migration.)
- **Passkey registration rejects credential reassignment** (WebAuthn §7.1 step 22), and the
  signature-counter check is now atomic under a row lock (no concurrent same-counter pass).
- **Device authorization authenticates confidential clients** (RFC 8628) via the shared
  client authenticator, closing prompt-spam under a confidential client's identity.

### Fixed

- **Discovery advertises only what it serves:** `id_token_signing_alg_values_supported` is
  derived from the live JWKS (RS256 only, not an aspirational superset), and `fragment` is
  dropped from `response_modes_supported`.
- **CIBA binds the id_token to the request `nonce`** (previously dropped).
- **SCIM Group PATCH/PUT reject invalid operations** (RFC 7644): unknown op/path return a
  `invalidSyntax`/`invalidPath` SCIM error instead of a silent 200, and full PUT requires
  `displayName`.

### Changed

- **Usage kernel depends on a `ReconcilableScopes` contract** instead of importing the
  Organization domain model (kernel→domain dependency reversal removed).
- **Environment status is typed** with the new `EnvironmentStatus` enum.
- **`final` removed from value objects** — the library must not seal classes host code may
  extend.

## [0.15.0] - 2026-07-15

### Added

- **External actions / inline hooks (`src/ExternalActions/`).** Synchronous extension
  points where the platform consults registered logic that can ENRICH or VETO an
  operation — the Okta-inline-hook / Auth0-Actions capability. Distinct from webhooks
  (which only notify, async): a hook participates in-band and changes the outcome. No new
  runtime dependency (reuses the crypto SecretBox, the already-present
  `cboxdk/laravel-ssrf` guard, the audit trail and the environment scope).
  - **`Contracts\ActionPipeline` + `DefaultActionPipeline` (new contract).** For a hook
    point, runs the in-process actions then the external endpoints and folds the results:
    the first deny short-circuits (vetoes the operation); enrichment is merged (later
    wins). A hook point with no actions is a cheap allow, so callers invoke it
    unconditionally on the hot path.
  - **In-process actions (`Contracts\Action` + `ConfigActionRegistry`).** A host class
    that runs synchronously at a hook point, returning `ActionResult::continue([...])` or
    `deny($reason)`. Deny-by-default: only classes listed in
    `cbox-id.external_actions.hooks.<point>` run.
  - **External HTTP actions (`Contracts\ExternalActions` + `HttpActionTransport`).**
    Register a customer HTTPS endpoint; the platform POSTs a SIGNED
    (HMAC-SHA256 over `"{ts}.{body}"`, `X-Cbox-Signature`), SSRF-GUARDED (URL asserted at
    registration, IPs pinned per send, redirects off, TLS on), SHORT-TIMEOUT, NO-RETRY
    request and interprets `{"action":"continue"|"deny","claims":{…},"reason":"…"}`. The
    per-endpoint signing secret is reveal-once and sealed at rest.
  - **Fail-closed by default.** A hook that throws / times out / errors / returns non-2xx
    DENIES the operation (a security control that fails open is not a control). Config
    `external_actions.fail_open` trades that for availability on enrichment-only hooks.
  - **Flagship wiring — the `TokenMinting` hook in `JwtTokenIssuer`.** Runs just before an
    access token is signed, on every grant (client-credentials, authorization-code,
    refresh, device, CIBA). An action can add claims (reserved protocol/security claims —
    `iss`/`sub`/`exp`/`scope`/`aud`/`cnf`/`ent`/… — can never be overwritten) or veto
    issuance (`ActionDenied`, mapped by the token endpoint to `access_denied`) BEFORE the
    `jti` row is written, so a denied token leaves no trace.
  - **Models + config + testing.** Env-owned `ExternalActionEndpoint` (migration
    `external_action_endpoints`); config `cbox-id.external_actions.*` (verify_url, timeout,
    connect_timeout, fail_open, hooks map); `Testing\InteractsWithExternalActions` +
    `Testing\FakeActionTransport` (network-free), dogfooded by 17 tests (enrichment,
    reserved-claim protection, veto→no-jti + `access_denied`, fail-closed/open, SSRF
    refusal, sealed-secret at rest, environment isolation, HTTP sign/interpret).

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- Inline hooks fail CLOSED, veto before any token row is written, cannot overwrite reserved
  claims, and make signed, SSRF-guarded, no-redirect egress calls. See
  [security/external-actions.md](docs/security/external-actions.md).

## [0.14.0] - 2026-07-15

### Added

- **`DeviceAuthorization::pending()` (device flow consent lookup).** A read method on
  the existing device-grant contract that resolves a live (pending, unexpired) request
  by its `user_code`, returning a new `PendingDeviceAuthorization` value object
  (`clientId`, `scopes`, `expiresAt`). This lets a verification/consent screen show
  **which** client and scopes are asking BEFORE the user approves — the piece a
  deployable app needs to build the RFC 8628 "enter the code on your TV/CLI" screen. It
  returns null for an unknown, expired or already-decided code and never exposes the
  `device_code` (the requesting device's polling secret). Additive; the rest of the
  device grant is unchanged.

## [0.13.0] - 2026-07-15

### Added

- **Access governance — IGA (`src/Governance/`).** The Identity Governance &
  Administration layer over the platform's RBAC roles and organization memberships:
  periodic access reviews and Segregation-of-Duties policies. No new runtime dependency
  — it composes the existing `Roles`, `Memberships`, audit and events, all
  environment-owned and deny-by-default.
  - **`Contracts\AccessReviews` + `DatabaseAccessReviews` (new contract).** `open()`
    snapshots every DIRECT role assignment and membership in an organization as pending
    certification items; `certify()`/`revoke()` record a reviewer's decision (reversible
    while the campaign is open); `close()` **applies** every revoke against the real
    contracts (`Roles::unassign()` / `Memberships::remove()`) and marks the campaign
    closed. Items left un-reviewed at close follow the campaign's `PendingPolicy`
    (default **Revoke** — unattested access is removed). A revoke the domain refuses
    (removing an org's last owner) is recorded un-applied with the reason and audited
    (`governance.access.revoke_blocked`), never silently dropped.
  - **`Contracts\SegregationOfDuties` + `DatabaseSegregationOfDuties` (new contract).**
    Policies over a mutually-exclusive set of roles. `evaluate()` returns a reasoned
    `Decision` (the authorization kernel's value object; deny carries `sod:{policyId}`)
    as a pre-grant gate the host calls before assigning a role; `wouldViolate()` is the
    boolean convenience; `violationsFor()` / `scan()` detect conflicts that already
    exist. Policies scope to one org or environment-wide (`organizationId: null`).
  - **Scheduled auto-close.** `cbox-id:governance:close-overdue` (registered + scheduled
    every minute, config-gated by `cbox-id.governance.schedule`) closes any open campaign
    past its `due_at`, reconstructing each campaign's environment first
    (`withoutScope` → `runAs`).
  - **Additive read methods on `Roles`.** `assignmentsForSubject()` and
    `assignmentsInOrganization()` were added to the `AccessControl\Contracts\Roles`
    contract (and `RoleService`) so governance enumerates real grants through the
    contract rather than the model.
  - **Models.** `CertificationCampaign`, `CertificationItem`, `SodPolicy` — all
    `BelongsToEnvironment`. Migration adds `governance_campaigns`,
    `governance_certification_items`, `governance_sod_policies`.
  - **Config.** New `cbox-id.governance.schedule`.
  - **Testing.** `Testing\InteractsWithGovernance`, dogfooded by the suite (snapshot,
    apply-on-close, certified-survives, pending policies, last-owner block, closed-freeze,
    idempotent re-close, SoD gate + detection, environment isolation, scheduled close).

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- Certification **applies** revokes against the real access contracts rather than
  recording paper decisions; un-reviewed items default to revoke; a refused revoke is
  surfaced and audited, never dropped; every decision and application is correlated by
  `campaign_id` on the hash-chained trail. See
  [security/governance.md](docs/security/governance.md).

## [0.12.1] - 2026-07-15

### Changed

- Add `keywords` to `composer.json` (identity, authentication, sso, saml, scim,
  oauth, oidc, rbac, audit) so the package is discoverable on Packagist and its
  GitHub topics are populated. Metadata only — no code changes.

## [0.12.0] - 2026-07-15

### Added

- **AI token vault (`src/TokenVault/`).** A deny-by-default broker for the downstream
  third-party credentials (OpenAI/GitHub/Google API keys and OAuth tokens) that
  autonomous / AI agents must present to the services they call. The agent never holds
  the long-lived secret; the vault does, sealed, and hands out short-lived audited
  leases. No new runtime dependency — it reuses the Crypto `SecretBox`, the hash-chained
  audit trail and the hard environment scope.
  - **`Contracts\SecretVault` + `DatabaseSecretVault` (new contract).** `store()` seals a
    credential via `SecretBox` (recoverable, AEAD-bound to the row — not a hash, because
    the vault must replay it); `grant()`/`revokeGrant()` are the deny-by-default
    authorization edge (a `client_id` → secret); `lease()` returns the plaintext to an
    authorized agent for immediate use with an advisory TTL; `rotate()`/`revoke()` are
    immediate. Every op is audited with actor + purpose, never the value.
  - **Uniform lease denial (no enumeration oracle).** Unknown secret, missing grant,
    revoked or expired all raise the same `LeaseDenied`; the real reason is written to
    the audit trail (`vault.lease.denied`), never returned. Management ops throw
    `SecretNotFound`.
  - **Environment-owned models (`Models\VaultSecret`, `Models\VaultGrant`).**
    `BelongsToEnvironment`; a `key_version` column makes a future manual master-key
    re-seal auditable (the crypto kernel has no master-key rotation). Migration adds
    `vault_secrets` + `vault_grants`.
  - **Config.** New `cbox-id.token_vault.default_lease_ttl_seconds` (the vault-wide lease
    ceiling; a per-grant `max_ttl_seconds` can only shorten it).
  - **Testing.** `Testing\InteractsWithTokenVault` + an in-memory `Testing\FakeTokenVault`
    that mirrors the deny-by-default semantics — dogfooded by the suite (lifecycle,
    grant-required + revoked/expired refusal, uniform denial, environment isolation,
    sealed-at-rest + AEAD context binding, value-absent-from-audit).
- **OpenID Connect CIBA — backchannel approval (`src/OAuthServer/`).** A new OAuth grant
  and endpoint for human-in-the-loop approval of agent actions, modelled on the device
  authorization grant. An agent starts a decoupled authentication naming the user; the
  user approves out-of-band; the agent polls for its tokens.
  - **`Contracts\BackchannelAuthentication` + `CibaAuthenticationService` (new contract).**
    `request()` resolves the user from `login_hint`, persists a pending request and emits
    `oauth.backchannel_authentication_requested` for the host to notify + drive its
    approval UI; `approve()`/`deny()` key off the INTERNAL request id (never the client's
    `auth_req_id`); `redeem()` is the poll grant. The `auth_req_id` is a CSPRNG secret
    stored only as a hash, single-use under a `lockForUpdate` mint, TTL-bounded and
    poll-throttled (`slow_down`) — the device grant's hardening, without a user_code.
  - **`POST /oauth/backchannel_authentication`** (client-authenticated) + the
    `urn:openid:params:grant-type:ciba` arm on `POST /oauth/token`, which returns an
    access token AND an id_token bound to the approving user (auth_time, nonce). Discovery
    advertises `backchannel_authentication_endpoint`,
    `backchannel_token_delivery_modes_supported: ["poll"]` and the grant type.
  - **Host boundary.** As with the OAuth consent screen, the user notification + approval
    surface is the host's; the package ships the protocol and emits the domain event.
    Poll mode only (ping/push not implemented).
  - **Config.** New `cbox-id.oauth.ciba.*`: `ttl_seconds` (approval window / ceiling on
    `requested_expiry`) and `poll_interval`.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- The token vault seals downstream credentials at rest and never returns which secret ids
  exist (uniform `LeaseDenied`); CIBA keeps the client's polling secret and the host's
  approval handle as separate identifiers so a client can never approve its own request.
  See [security/token-vault.md](docs/security/token-vault.md) and
  [security/ciba.md](docs/security/ciba.md).

## [0.11.0] - 2026-07-15

### Added

- **Delivered OTP channels (`src/Otp/`).** One-time passcodes over email / SMS as a
  verification and MFA factor, sitting alongside the existing authenticator-app TOTP,
  passkeys and magic links. A host wires it into its own step-up / second-factor /
  contact-verification flows — the module ships primitives, no UI. No new runtime
  dependency: it reuses the framework mailer (via the `Mailer` contract only), the
  crypto master key, Laravel's `RateLimiter`, the hash-chained audit trail and the
  hard environment scope.
  - **`Contracts\OtpService` + `DatabaseOtpService` (new contract).** `issue(purpose,
    recipient, channel, ip?)` generates a CSPRNG numeric code (`random_int`,
    configurable length, default 6), stores only its hash with a short TTL (default
    5 min), delivers the plaintext via the channel, and returns an `OtpChallenge`
    value object that never carries the code. `verify(challengeId, code, ip?)` /
    `verifyLatest(purpose, recipient, code, ip?)` are constant-time, single-use, and
    deny-by-default — unknown, expired, consumed, locked or wrong all fail with a
    uniform `OtpResult`, and the hash-compare runs on every path (a decoy on the miss)
    so there is no enumeration or timing oracle.
  - **`Contracts\OtpChannel` + `Contracts\OtpChannels` + `ChannelRegistry` (new
    contracts).** A deny-by-default sender registry: a channel key with no registered
    sender is refused (`UnknownOtpChannel`), never a silent no-op. Ships
    `EmailOtpChannel` (framework mailer, plain honest text), plus `LogOtpChannel` and
    `NullOtpChannel` for local dev / tests. **SMS is a CONTRACT ONLY** — a host
    registers its own `OtpChannel` wrapping its provider's SDK; this package ships no
    SMS SDK.
  - **`Contracts\OtpHasher` + `KeyedOtpHasher` (new contract).** A short numeric code
    has little entropy, so the at-rest value is a **keyed HMAC** under a key derived
    (HKDF) from the crypto master key — which lives outside the database — rather than
    a plain hash (offline-brute-forceable) or a slow password hash (a CPU-amplification
    lever on the verify path). All vetted PHP core primitives; nothing hand-rolled.
  - **Environment-owned model (`Models\OtpChallenge`).** `BelongsToEnvironment`, so a
    challenge issued in one environment is structurally invisible to any other. A
    migration adds the `otp_challenges` table (purpose, channel, recipient, code_hash,
    expires_at, attempts, max_attempts, consumed_at).
  - **Abuse resistance (layered).** Issuance is throttled both per recipient+purpose+IP
    **and** per recipient across all purposes/IPs — the second cap is what bounds
    bombing / SMS-cost abuse when an attacker rotates the purpose or source IP.
    Verification is throttled globally per IP **and**, on the `verifyLatest()` recipient
    path, per recipient+purpose across IPs. `verifyLatest()` targets only a LIVE,
    unlocked challenge (skipping expired/attempt-capped rows), so a locked fresher
    challenge can neither shadow an older valid one nor leak an expired/locked status as
    an enumeration signal. Underneath, the at-rest per-challenge attempt cap (default 5,
    then the challenge locks) is the last-resort bound independent of the cache-backed
    limiter. Issue / verify-fail / lockout / verify are audited — with the challenge id,
    purpose, channel and recipient, and never the code.
  - **Minimum code length.** Configuring `code_length` below 6 is floored to 6: a 10^4
    space is brute-forceable within the attempt cap once sprayed across recipients/IPs,
    so it is refused rather than silently accepted.
  - **Config.** New `cbox-id.otp.*` keys: `code_length` (floored to 6), `ttl_seconds`,
    `max_attempts`, `issue.max_per_window` + `issue.per_recipient_max`,
    `verify.max_per_window` + `verify.per_recipient_max`, the deny-by-default `channels`
    map, and `email.*` (subject / from).
  - **Testing.** `Testing\InteractsWithOtp` + an in-memory `Testing\FakeOtpChannel`
    that captures delivered codes — dogfooded by the suite, which proves the
    issue→verify lifecycle, single-use, TTL, attempt-cap + lockout, both rate limits,
    deny-by-default (unregistered channel, no-ambient-environment, cross-environment
    isolation), code-hashed-at-rest, code-absent-from-audit, and the uniform
    constant-time miss path.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- OTP is treated as an auth factor: codes are CSPRNG-generated, stored only as a
  keyed HMAC (never plaintext), single-use, TTL-bounded, attempt-capped and
  rate-limited on both issue and verify; verification is constant-time on every path
  and returns a uniform result (no enumeration / timing oracle); the plaintext code
  never appears in a return value, an audit row, a log (outside the dev-only
  `LogOtpChannel`), or an exception. Honest scope is documented: a short code's safety
  rests on the caps, not its entropy, and SMS is only as secure as SIM-swap
  resistance. New docs: `core-concepts/otp-channels.md`, `security/otp.md`,
  `cookbook/add-an-sms-otp-channel.md`, `extension-points/custom-otp-channel.md`.

## [0.10.0] - 2026-07-15

### Added

- **Outbound SCIM 2.0 provisioning (`src/Provisioning/`).** The mirror of the
  inbound Directory module: the platform acting as a SCIM **client**, pushing user
  and membership changes OUT to an organization's downstream apps over THEIR SCIM
  2.0 endpoints (create/update/deactivate the remote user). No new runtime
  dependency — it reuses the existing HTTP client, `cboxdk/laravel-ssrf`, the Crypto
  kernel and the domain event bus.
  - **Shared SCIM schema (`Cbox\Id\Scim\ScimSchema`).** The RFC 7643/7644 URNs and
    pure body builders (`User` resource, `PatchOp`, `ListResponse`, error, equality
    filter) were extracted into one transport-agnostic source of truth, now consumed
    by BOTH the inbound `Api\Support\ScimMapper` (which was refactored to reference
    it, no behaviour change) and the new outbound client — the URNs are declared
    once, not duplicated per direction.
  - **`Contracts\ScimClient` + `HttpScimClient` (new contract).** The outbound SCIM
    2.0 HTTP client: `POST /Users` (create → capture the remote id), `PATCH
    /Users/{id}` with a `PatchOp` body (update / `replace active`), `DELETE
    /Users/{id}`, and `GET /Users?filter=externalId eq "…"` for reconcile. Every
    request is SSRF-guarded and IP-pinned immediately before connect (redirects
    refused), TLS-verified, and carries `application/scim+json`. Bearer or OAuth 2.0
    client-credentials auth is opened from the sealed secret; the token is never
    placed in a returned result or a stored error.
  - **`Contracts\ProvisioningConnections` + `DatabaseProvisioningConnections` (new
    contract).** The registry of downstream targets. Registration SSRF-checks the
    base URL and seals the secret (reveal-once); `inScopeFor()` resolves the
    connections in the current environment that a given change belongs to.
  - **`Contracts\ProvisioningService` + `OutboxProvisioningService` (new contract).**
    Translates a domain event to a SCIM operation and enqueues a durable outbox row
    per in-scope connection, then drains it statefully — POST vs. PATCH is decided by
    the captured remote id, a 409-on-create reconciles by `externalId`, a 404-on-update
    recreates. Bounded exponential backoff + jitter, a dead-letter cap, and a
    per-connection circuit breaker.
  - **Environment-owned models (`Models\ProvisioningConnection`,
    `Models\ProvisionedResource`, `Models\ProvisioningOperation`).** All
    `BelongsToEnvironment`, so cross-environment provisioning is structurally
    impossible. `ProvisionedResource` (unique per environment+connection+user) is the
    SCIM statefulness — the platform user ↔ remote resource id mapping. A migration
    adds the three tables.
  - **Event-driven, async delivery.** `Listeners\ProvisionOnDomainEvent` enqueues on
    every `EventDelivered` (request thread, never delivers). `Jobs\DrainProvisioningConnection`
    (`ShouldBeUnique` per connection) drains in a worker, reconstructing the
    connection's environment (`EnvironmentContext::withoutScope()` single-id read →
    `runAs()`) exactly as the audit-streaming pump does. `Console\DrainProvisioningCommand`
    (scheduled per-minute, mirroring the Webhooks retry schedule) fans a drain out to
    every active connection across all environments; `Console\SyncProvisioningCommand`
    (`cbox-id:provisioning:sync {--connection=}`) reconciles in-scope subjects.
  - **Attribute mapping (`Support\AttributeMapping`).** Maps platform attributes onto
    SCIM `User` paths, defaulting to userName/email/displayName and supporting the
    Enterprise User extension; rebind per connection or via the contract.
  - **Config.** New `cbox-id.provisioning.*` keys: `verify_url` (SSRF, operator-only),
    `max_attempts`, `batch_limit`, `schedule`, and `circuit_breaker.*`.
  - **Testing.** `Testing\InteractsWithProvisioning` + an in-memory `Testing\FakeScimClient`
    (a conformant fake downstream SCIM server) — dogfooded by the suite, which proves
    the lifecycle against real RFC 7643/7644 payload shapes, the 409/404 reconcile
    paths, cross-environment isolation at both dispatch and drain, retry/dead-letter,
    the circuit breaker, deny-by-default, SSRF refusal and secret-at-rest.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- Outbound provisioning egress is SSRF-guarded and DNS-pinned on every request
  (SCIM base URL and OAuth token URL), TLS-verify on, with connection secrets sealed
  at rest (reveal-once) and scrubbed from errors/dead-letter rows. Environment-owned
  models keep provisioning deny-by-default and single-environment. Delivery is
  documented as at-least-once (not exactly-once); no unverified SCIM-conformance
  claim is made beyond what the tests exercise.
- **Adversarial review — three defects found and fixed before release:**
  - **No longer deprovisions a still-entitled user.** `organization.member_removed`
    now deprovisions ONLY connections the user has genuinely LEFT
    (`ProvisioningConnections::leftScopeFor()`): an org-scoped connection only when no
    remaining membership keeps the user in its scope, and an environment-wide
    connection never on an org removal. Removing a user from one org they share with
    another org on the same connection previously deactivated — or with the `Delete`
    policy, **DELETED** — a user still entitled through the other org.
  - **409 reconcile no longer trusts a filter-ignoring peer.** `findByExternalId`
    adopts a remote record only when the response is unambiguous AND the matched
    resource actually carries the requested `externalId`
    (`ScimResult::resourceIdForExternalId()`). A downstream SCIM server that ignores
    the `externalId eq` filter and returns its whole list can no longer bind an
    arbitrary remote user as this subject's mirror (then wrongly PATCH/DELETE it).
  - **OAuth token cache now expires.** The client-credentials token is cached with
    its `expires_in` lifetime (minus a skew margin) and refreshed on expiry, so the
    singleton client in a long-running worker no longer serves a dead token and
    dead-letters every operation after the first expiry.

## [0.9.0] - 2026-07-15

### Added

- **SIEM audit streaming (`src/AuditStreaming/`).** A thin, isolation-critical
  binding that mirrors the hash-chained, environment-scoped audit trail OUT to a
  customer's SIEM (Splunk HEC, Elastic ECS, Graylog GELF, ArcSight/CEF, generic
  JSON). It composes two new runtime dependencies rather than reimplementing
  delivery: `cboxdk/siem` (the `SiemEvent` value object + formatters) and
  `cboxdk/laravel-siem` (the transactional-outbox delivery engine: batching, retry /
  dead-letter / circuit-breaker, SSRF-guarded HTTP egress, encrypted secrets,
  redaction).
  - **Environment-owned models (`Models\AuditStream`, `Models\AuditStreamDelivery`).**
    Subclasses of the engine's `LogStream` / `StreamDelivery` with
    `BelongsToEnvironment`. Pointed at by `config('siem.models.*')`, so the engine's
    registry, dispatcher and pump inherit the hard environment scope for free —
    deny-by-default, no bespoke tenancy checks. A migration adds an indexed
    `environment_id` to the engine's `log_streams` and `stream_deliveries` tables
    (runs after the engine's own create migration).
  - **`StreamingAuditLog` decorator (behavior addition).** Bound via
    `app->extend(AuditLog::class, …)`, so it composes with a host decorator (e.g.
    impersonation attribution — stamped `context.impersonated_by` flows to the SIEM
    automatically). On `record()` it maps the `AuditEntry` to a `SiemEvent` and writes
    the outbox row **in the same database transaction as the entry** (transactional
    outbox → at-least-once; a rolled-back caller leaves neither the entry nor an
    orphan delivery). Deny-by-default: with no stream configured in the environment it
    is a no-op beyond the inner `record()`. `verifyChain()` / `checkpoint()` delegate
    unchanged.
  - **`Contracts\SiemEventMapper` + `DefaultSiemEventMapper` (new contract).** Maps
    `AuditEntry` → `SiemEvent`; rebind to refine category/outcome/severity. Two
    invariants are fixed by contract: the event **id is the entry hash** (dedup /
    idempotency key), and the context carries `sequence`, `hash`, `prev_hash` and
    `organization_id` so the receiving SIEM can verify chain continuity and detect
    gaps/reorder/replay.
  - **Async pump with environment reconstruction.** `Jobs\PumpAuditStream`
    (`ShouldBeUnique` per stream) resolves the stream's `environment_id` via a
    provisioning-only `EnvironmentContext::withoutScope()` read, then runs the engine's
    delivery inside `EnvironmentContext::runAs($env, …)` so the hard scope matches and
    only that environment's rows are ever loaded. `Console\PumpAuditStreamsCommand`
    (scheduled every minute, mirroring the Webhooks module) is the single
    cross-environment step: under `withoutScope` it enumerates enabled streams across
    all environments and dispatches one pump each — it dispatches, it never delivers.
  - **Config.** New `cbox-id.audit_streaming.schedule` toggle. The provider forces
    three engine keys: `siem.models.log_stream`, `siem.models.stream_delivery`, and
    `siem.schedule.enabled = false` (laravel-id owns scheduling so the pump can
    reconstruct each stream's environment).
  - **Testing.** `Testing\InteractsWithAuditStreaming` (env-aware stream registration,
    an in-memory fake sink, synchronous pump) — dogfooded by the suite.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Environment isolation for streaming is structural, proven at both stages.** An
  env-A audit entry only ever matches/writes env-A streams (dispatch), and the pump
  for an env-A stream can only load/deliver env-A rows (pump) — enforced by the
  env-owned models and the hard scope, not a filter. Covered by cross-environment
  tests at both stages.
- **`siem.http.verify_url` (SSRF guard) and `siem.http.tls_verify` are operator-only.**
  Documented (config + `docs/security/audit-streaming.md`) as deployment-level toggles
  that must NEVER be exposed to a tenant/org admin — a tenant able to disable the SSRF
  guard could turn a stream into an SSRF primitive against internal infrastructure.

### Dependencies

- Added runtime deps `cboxdk/laravel-siem` (`^0.1`) and `cboxdk/siem` (`^0.1`), both
  MIT, resolved from Packagist. SBOM regenerated (78 → 80 components).

## [0.8.0] - 2026-07-15

### Added

- **Bulk user import + lazy password-hash migration (`src/Identity/`).** The
  enterprise migration wedge: import users from another provider
  (Auth0/Cognito/Firebase/a CSV) INCLUDING their existing password hashes, so they
  sign in on day one, with each foreign hash transparently upgraded to the platform
  hasher (argon2id) on first successful login — no forced reset, no dual-run window.
  - **Multi-algorithm hash verification (`Identity\Hashing`).** New contract
    `Identity\Contracts\HashVerifier` (`supports`/`verify`/`needsRehash`) with
    `NativePasswordVerifier` (bcrypt `$2y$/$2a$/$2b$` + argon2 `$argon2i$/$argon2id$`
    via PHP's vetted `password_verify`/`password_needs_rehash` — nothing hand-rolled)
    and a **deny-by-default** `HashVerifierRegistry` bound to the contract: a hash no
    registered verifier `supports()` fails `verify()` — never a silent pass. The
    registry is the seam a host uses to add a foreign format (Firebase scrypt,
    PBKDF2, `{SSHA}`) by wrapping a vetted library, via
    `config('cbox-id.hashing.verifiers')`.
  - **Lazy migration in `DatabaseSubjects::verifyPassword()`.** Verification now
    routes through the registry; on a correct password against a foreign/legacy hash
    (or the platform algorithm with weaker-than-current parameters) the plaintext is
    re-hashed with the platform hasher and persisted in place. The constant-time
    dummy-verify (no enumeration/timing oracle) and active-status gating are
    preserved.
  - **Import service.** New contracts `Identity\Contracts\UserImport` +
    `DatabaseUserImport`, value objects `ImportedUser` / `ImportOptions` /
    `ImportResult` / `ImportError`. Idempotent per email (skip or `upsert`), batched
    in a transaction per chunk with atomic rows, per-row errors collected instead of
    aborting the run, and **deny-by-default** on credentials — with
    `ImportOptions::$rejectUnverifiableHashes` (default) a `passwordHash` no verifier
    supports is a per-row error, so you can't import a user who could never log in.
    Attaches each user to an organization via `Organization\Contracts\Memberships`
    and honors the per-row verified-email flag.
  - **Artisan `cbox-id:users:import {file} {--org=} {--format=csv|json} {--upsert}
    {--role=}`** — streams a CSV/JSON export into the importer and exits non-zero if
    any row errored.
  - **Contract change:** `Identity\Contracts\Subjects` gains `storeCredential()`
    (store an already-hashed credential verbatim, for import/migration — NOT
    re-hashed, upgraded lazily on next login). Hosts with a custom `Subjects`
    resolver must implement it.
  - `Testing\InteractsWithImport` helper. Docs: cookbook recipe *Migrate users from
    another provider* and extension-points *Custom hash verifiers*.
  - **Environment integrity on the import command.** `cbox-id:users:import` always
    provisions into the TARGET ORG's own environment: when an environment is already
    ambient it must be the org's (a mismatch is refused, never a silent import into
    the wrong plane), and a bare console invocation pins it from the org. The
    `--upsert` match is by environment-wide email (a user is unique per
    `(environment, email)` and may belong to several orgs) — the recipe documents
    why this stays an operator-run console command with no per-org authorization.

## [0.7.0] - 2026-07-15

### Added

- **SAML 2.0 Identity Provider (`src/SamlIdp/`).** Cbox ID can now act as the SAML
  IdP that downstream service providers (Salesforce, Workday, AWS, any SP) federate
  to — the mirror of the existing relying-party side. New contracts
  `SamlIdp\Contracts\{SamlIdentityProvider, ServiceProviders, IdpKeyMaterial}`:
  - **Registered SPs** (`saml_service_providers`, environment-owned `ServiceProvider`
    model): `entity_id` (unique per environment), an exact-match `acs_url` (the only
    place an assertion is ever sent), `name_id_format`/`name_id_attribute`,
    `attribute_mappings`, the SP `certificate`, and `want_authn_requests_signed`.
  - **`parseAuthnRequest()`** decodes the request (base64 + DEFLATE for redirect,
    base64 for POST) through an XXE-safe loader and validates deny-by-default: the
    issuer must be a registered, active SP; a request-supplied
    `AssertionConsumerServiceURL` must equal the registered ACS exactly
    (open-redirect defense); when signing is required the signature must verify
    against the SP certificate with the algorithm **pinned to RSA-SHA256** (SHA-1 and
    unknown algorithms refused).
  - **`issueResponse()`** mints a signed SAML Response containing a signed Assertion:
    bearer `SubjectConfirmation` (Recipient = registered ACS, `InResponseTo`, short
    `NotOnOrAfter`), `Conditions` with a ~5-minute window and an `AudienceRestriction`
    pinned to the SP EntityID, an `AuthnStatement`, and an `AttributeStatement` from
    the SP's mappings. The Assertion is signed with `robrichards/xmlseclibs`
    (enveloped signature, **exclusive C14N**, **RSA-SHA256**, SHA-256 digest) and the
    Response with `onelogin/php-saml`'s `addSign`. XML is built with DOM so every
    value is escaped. SHA-1 is never emitted.
  - **One identity:** the IdP signs with the platform's active RSA signing key
    (`KeyManager::activeSigningKey`), the same key behind JWKS/OIDC — no second key
    store. The public half is published as a self-signed X.509 certificate, persisted
    per `kid` (`saml_idp_certificates`).
  - **Endpoints** (behind `ResolveEnvironment` + throttle): `GET /sso/saml/idp/metadata`,
    `GET|POST /sso/saml/idp/sso` (parse + validate + host hand-off + auto-POST form),
    `GET|POST /sso/saml/idp/slo` (local session termination). Thin controllers — the
    authenticate-the-subject step is the host's, as with OAuth `/authorize`.
  - **Testing:** `Testing\InteractsWithSamlIdp` trait (now with `samlSigningKeypair()`
    and `makeSignedPostAuthnRequest()` helpers) + `FakeServiceProviders`. The suite
    proves issued assertions against `onelogin/php-saml` acting as the SP (signature,
    audience, recipient, `InResponseTo`, conditions), asserts a tampered assertion is
    rejected by that verifier, and covers the ACS-mismatch, unregistered-SP, XXE, and
    algorithm-pin refusals — plus the POST-binding signed-request path (accepted valid;
    refused when unsigned, tampered, SHA-1, or XML-Signature-Wrapped).
  - **Integrating (host apps):** the HTTP-POST binding is a cross-site form POST with
    no Laravel CSRF token, so hosts must add `sso/saml/idp/sso` to
    `VerifyCsrfToken::$except` (fail-closed — a missing exemption breaks the POST
    binding, it does not weaken security). See `docs/core-concepts/saml-idp.md`.
  - **Not yet implemented (honest scope):** assertion **encryption**
    (`EncryptedAssertion`), full Single Logout fan-out / signed `LogoutResponse`, and
    IdP-initiated (unsolicited) SSO. See `docs/core-concepts/saml-idp.md`.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **SAML IdP — XML Signature Wrapping (XSW) hardening on the POST-binding
  signed-`AuthnRequest` path (defense-in-depth).** `onelogin/php-saml`'s
  `Utils::validateSign()` confirms *a* signature verifies against the SP certificate
  but does not bind the signed element to the request root the parser reads. The
  embedded-signature verification now, before trusting the result, requires the
  message `ds:Signature` to be a single enveloped signature that is a **direct child
  of the `AuthnRequest` root**, requires its `Reference` to **cover that root** (empty
  URI = whole document, or `#<root ID>` — never a wrapped or duplicated element), and
  **pins verification to that exact signature** (via `validateSign`'s `$xpath`) so the
  verified crypto is the one enveloped in the root rather than whichever `ds:Signature`
  appears first in document order. The embedded `SignatureMethod`/`DigestMethod` are
  also pinned to **RSA-SHA256 / SHA-256** (onelogin would otherwise accept SHA-1),
  matching the redirect binding. Impact of the prior gap was bounded — a forged
  request still only produced an assertion delivered to the genuine registered ACS —
  so this is hardening, not a fix for a known exploit. Covered by a new XSW regression
  test.

## [0.6.0] - 2026-07-14

### Added

- **DNS domain verification + home-realm discovery.** New `Federation\Contracts\DomainVerification`
  (`DatabaseDomainVerification`): an organization registers an email domain, proves
  control by publishing a DNS TXT challenge at `_cbox-id-challenge.<domain>`, and
  once verified, `connectionForEmail($email)` routes matching users to the org's
  active SSO connection. Resolution is deny-by-default — an unverified domain never
  routes and never captures — and environment-scoped, so a domain verified in one
  environment never routes a login in another. New `verified_domains` table +
  `VerifiedDomain` model.
- **Optional capture gate.** A verified domain carries a `capture` flag: off by
  default (verification enables routing only); when the host turns it on, matching
  users are meant to be forced into the org's auth policy. The package exposes the
  flag; enforcement is the host's.
- **`DnsResolver` contract** (`SystemDnsResolver` default over `dns_get_record`) so
  the DNS lookup is swappable — a host can bind a direct-authoritative resolver to
  avoid recursive-cache staleness at verification time — and testable
  (`Testing\FakeDnsResolver`, plus `InteractsWithFederation::fakeDns()` /
  `makeVerifiedDomain()`). The library ships only the dependency-light default.

## [0.5.0] - 2026-07-14

A follow-up hardening + DX pass from a deep review, plus operator MFA and
contract-level suspension.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Outbound OIDC token exchange is now SSRF-guarded.** `OidcClient::exchangeCode()`
  POSTed to an org-admin-configured `token_endpoint` without the SSRF guard the
  webhook path already used, so a malicious endpoint (e.g. cloud metadata at
  `169.254.169.254`) was reachable server-side. It now runs through
  `SafeFederationUrl` — the same `cboxdk/laravel-ssrf` `UrlGuard` as webhooks,
  with DNS-pinned options (no TOCTOU) and a `cbox-id.federation.verify_url`
  toggle for on-prem internal IdPs.
- **Social identity linking race closed.** `DatabaseSubjects::link()` was
  check-then-insert with no lock, and the `identities` uniqueness index didn't
  bite for connection-less (social) links because SQL treats NULL `connection_id`
  as distinct. `link()` now serializes under `lockForUpdate` in a transaction, so
  a concurrent double-link yields one row.

### Added

- **`client_secret_basic` at the token endpoint** (RFC 6749 §2.3.1). `/oauth/token`
  accepted client credentials only in the body while discovery advertised Basic,
  so Basic-defaulting clients got `invalid_client`. A shared `ClientAuthenticator`
  now reads Basic-first then body, rejects combining both, and is used by the
  token, introspection, revocation, and PAR endpoints (previously four divergent
  copies).
- **Database-backed default environment.** New `environments.is_default` column,
  `Environment::makeDefault()`, and `EnvironmentResolver::defaultEnvironment()`.
  The single-tenant / host-less fallback plane is now the row flagged in the
  database rather than an env var written to `.env`, so a horizontally-scaled,
  stateless deployment (k8s, no writable `.env`) resolves the same default across
  every replica. `cbox-id.environments.default` config remains an explicit
  override that wins when set.
- **`cbox-id:install` bootstraps the first environment.** It now creates (or
  reuses) an environment, marks it the default, and mints the first signing key
  *inside that environment's scope* — fixing the fresh-install failure where the
  deny-by-default scope left the signing-key step (and every first query) hitting
  an empty scope.
- **Optional `base64:` prefix on `CBOX_ID_CRYPTO_KEY`.** `CryptoServiceProvider`
  strips a leading `base64:` (Laravel's conventional prefix) before decoding, so
  a key copied with the prefix no longer throws at boot.
- **`cbox-id.oauth.authorization_endpoint` config** (env `CBOX_ID_AUTHORIZATION_ENDPOINT`).
- **Operator MFA.** New `Platform\Contracts\OperatorMfa` + `DatabaseOperatorMfa`:
  TOTP enrolment/verification and single-use recovery codes for platform
  operators, so the control-plane root account can require a second factor. It is
  a SEPARATE subsystem keyed by operator id on non-environment-owned tables
  (`operator_mfa_factors`, `operator_mfa_recovery_codes`) — an operator's factor
  is never a tenant user's. It shares the vetted RFC 6238 `TotpAuthenticator`,
  the `SecretBox` at-rest sealing, and recovery-code formatting with subject MFA.
- **Suspension through contracts, with audit.** `Organizations::suspend()` /
  `reactivate()` and `PlatformOperators::suspend()` / `reactivate()` transition
  status *and* record an audit event (`ActorType::Operator`), so a suspension is
  attributable instead of a silent `->update()`. The operator variant refuses to
  suspend the last active operator (`CannotSuspendLastOperator`) — no lock-out.

### Changed

- **`organizations.slug` uniqueness is environment-scoped** (`unique(['environment_id','slug'])`).
  It was globally unique, contradicting the hard-boundary model — two environments
  could not both have an `acme` org, and the collision surfaced as a raw
  `QueryException` instead of `SlugAlreadyTaken`.
- **SCIM controllers are thin again.** `Scim\UserController` / `Scim\GroupController`
  no longer query models or implement PATCH/filter/membership logic inline; that
  moved behind new `DirectoryUsers` / `DirectoryGroups` contracts. SCIM wire
  behaviour is unchanged.
- **Discovery no longer advertises an unserved `authorization_endpoint`.**
  `ServerMetadata` omits the key unless `cbox-id.oauth.authorization_endpoint` is
  set (interactive authorize is the host app's responsibility).
- **`TotpAuthenticator` and `TotpEnrollment` moved to `Kernel\Crypto`** (from
  `Identity\Mfa` / `Identity\ValueObjects`). TOTP is a shared crypto primitive;
  the move lets Platform's operator MFA reuse it without a Platform→Identity
  dependency. Recovery-code formatting extracted to a shared
  `Kernel\Crypto\Concerns\FormatsRecoveryCodes` trait. `ActorType` gains
  `Operator`.

### Breaking

- `EnvironmentResolver` gains `defaultEnvironment(): ?Environment` — custom
  implementations of the contract must add it.
- `Organizations` gains `suspend()` / `reactivate()`, and `PlatformOperators`
  gains `suspend()` / `reactivate()` — custom implementations must add them.
- `TotpAuthenticator` / `TotpEnrollment` moved namespace (`Identity\Mfa` /
  `Identity\ValueObjects` → `Kernel\Crypto` / `Kernel\Crypto\ValueObjects`);
  update imports.
- The `organizations` unique index changed (fresh-install migration edit, in
  keeping with the 0.x dogfooding cadence — no `alter` shipped).

## [0.4.0] - 2026-07-13

A security-hardening pass from a full review. Isolation is now enforced by the
deny-by-default global scope across every tenant table rather than by per-query
discipline. Breaking: adds `environment_id` to several tables (schema change).

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- **Environment isolation is now defense-in-depth.** `WebhookEndpoint` +
  `WebhookDelivery` were not environment-owned — a platform-wide (null-org)
  endpoint received *every* environment's events (cross-environment payload
  leak). Both are now environment-owned, and 13 more tenant-relevant tables
  gained the global scope (`DirectoryUser/Group`, `WebAuthnCredential`,
  `MfaFactor`, `MfaRecoveryCode`, `MagicLinkToken`, `PasswordResetToken`,
  `EmailVerificationToken`, `AccessToken`, `ServiceAccount`,
  `PushedAuthorizationRequest`, `Role`, `RoleAssignment`, `SamlAuthRequest`), so
  a query that forgets its filter can no longer cross environments. Replay tables
  (`DpopProof`, consumed SAML assertions) and the shared permission catalog stay
  global by design.
- **Device-grant redemption** flips `approved → redeemed` under `lockForUpdate`
  in a transaction, closing a single-use TOCTOU for a shared/logged `device_code`.
- **SAML Single Logout** scopes its identity lookup by `connection_id` (as login
  does), so a signed `LogoutRequest` from one connection can't force-logout a user
  belonging to another.
- **Magic-link redemption** locks the token row.
- **Credential checks** run a constant-cost dummy verify on the miss path
  (`Subjects`, `PlatformOperators`) — no username-enumeration timing oracle.
- **Host-based environment resolution** only trusts a leading subdomain label
  under a configured `cbox-id.environments.base_domains`; a spoofed `Host` can no
  longer select a plane.
- **Tenancy context managers** are `scoped`, not `singleton`, so a killed
  Octane worker can't leak a suspension counter across requests and collapse
  scoping.
- The configured `cbox-id.models.user` **must extend the package `User`** (which
  carries `BelongsToEnvironment`), so a host override can't silently unscope the
  users table.

### DX

- Docs: the flagship examples referenced a non-existent `UserDirectory` contract
  — renamed to `Subjects`/`DatabaseSubjects` across the README and docs so they
  run as written.
- Added `Platform/Testing/InteractsWithPlatform` (`makeOperator()`), dogfooded in
  the Platform tests, and a `Kernel/Crypto/Testing/FakeSecretBox` so hosts can
  test secret-sealing without libsodium.
- `@throws` tags on `Subjects` and `DeviceAuthorization`.

## [0.3.2] - 2026-07-13

### Fixed

- **`OrganizationHierarchy::move()` now syncs the `parent_id` column.** 0.3.1
  rewrote only the closure table, leaving the denormalized direct-parent column
  stale — so tree views built from `parent_id` didn't reflect a move. `move()`
  now updates both representations atomically.

## [0.3.1] - 2026-07-13

### Added

- **`OrganizationHierarchy::move()`** — reparent an existing organization, with
  its whole subtree, under a new parent (or promote to root). Rewrites the
  closure table correctly at any depth and throws `CannotReparent` if the target
  is the node itself or one of its descendants (cycle guard). Fills the gap that
  `attach()` — create-time only — left for tenant hierarchy management (moving a
  customer between resellers, restructuring OUs).

## [0.3.0] - 2026-07-13

Adds **platform operators** — the identity above every environment (the WorkOS
"team member" / developer account). Operators authenticate once at the platform
level and can then assume any environment's console, without needing an account
inside each plane.

### Added

- **Platform operators.** A new `platform_operators` table and
  `Cbox\Id\Platform\Contracts\PlatformOperators` repository. Operators are *not*
  environment-owned — no `environment_id`, globally unique email — so they resolve
  identically from any environment (asserted in the `@group isolation` suite).
  Password verification is gated on active status. `PlatformServiceProvider` binds
  the repository; a new migration ships the table.
- **Docs.** `core-concepts/platform-operators.md` — the model, the WorkOS/Auth0/
  Okta mapping, provisioning, and the isolation guarantee.

### Fixed

- **`User` now hashes assigned passwords.** The model gained a `password => hashed`
  cast, so a raw `User::create(['password' => ...])` (seeders, factories) hashes
  with the configured driver instead of storing plaintext — which previously threw
  `This password does not use the Argon2id algorithm` at sign-in. The `Subjects`
  API, which hashes up front, is unaffected (the cast skips already-hashed values).

## [0.2.0] - 2026-07-13

Adds **environments** — the hard identity boundary above organizations
(staging/prod, per-product and white-label isolation), WorkOS-style. This is a
breaking change: the schema and query scoping change platform-wide.

### Added

- **Environments.** A first-class isolation layer above the organization tenant:
  its own user pool, signing keys, issuer and organization tree. Resolved per
  request from the host (`ResolveEnvironment` middleware + `EnvironmentResolver`;
  custom-domain or leading-subdomain-as-slug). See
  [Environments & the isolation model](docs/core-concepts/environments.md).
- `Environment` model + `environments` table; `EnvironmentContext`,
  `EnvironmentScope`, `BelongsToEnvironment`, `EnvironmentOwned`,
  `GenericEnvironment`; `actingAsEnvironment*` test helpers.
- A dedicated cross-layer isolation suite (`--group=isolation`) proving the
  boundary across tenancy, crypto, identity and the OAuth surface.

### Changed (breaking)

- Every environment-owned model now carries `environment_id` and is scoped by a
  **deny-by-default** environment scope, independent of (and harder than) the
  organization scope: `withoutScope`/roll-up on the org dimension never crosses an
  environment.
- **User email uniqueness is now per environment** (`(environment_id, email)`),
  and federated-link uniqueness includes the environment — the same email is a
  distinct user across environments.
- **Signing keys, JWKS and the issuer are per environment** — a token signed in
  one environment never verifies in another.
- API requests must resolve an environment from the host. Set
  `cbox-id.environments.default` for single-tenant/on-prem; a multi-tenant
  deployment refuses an unknown host.

## [0.1.2] - 2026-07-13

### Fixed

- Accept the canonical single-slash private-use redirect URI form
  (`com.example.app:/cb`) at registration, so native mobile apps (RFC 8252 /
  AppAuth) register cleanly.

## [0.1.1] - 2026-07-13

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- Hardening pass: SAML `InResponseTo` enforcement, DPoP enforced at the resource
  surface and bound to refresh tokens, account-status gating across all login
  paths, step-up on MFA enrollment / provider unlink, webhook DNS pinning +
  dead-lettering, admin-only console reads, and per-client token ownership on
  introspection/revocation.

### Changed

- Documentation restructured into the topic-folder layout.

## [0.1.0] - 2026-07-13

First tagged release. Pre-1.0: the public API may still change between `0.x`
releases, and only the latest `0.x` tag is supported.

### Added

- **OAuth 2.0 / OIDC authorization server** — `authorization_code` with mandatory
  PKCE (S256), `client_credentials`, refresh tokens with rotation + reuse
  detection (family revocation), and the Device Authorization Grant (RFC 8628).
- **Sender-constrained tokens (DPoP, RFC 9449)** — proof validation at the token
  endpoint, enforcement at the resource surface (`cnf.jkt` + `ath`), and DPoP-key
  binding of refresh tokens.
- **Pushed Authorization Requests** (RFC 9126) and a **FAPI 2.0 baseline** profile.
- **Token endpoint hardening** — `at+jwt` access tokens (RFC 9068), RFC 8707
  resource indicators with `invalid_target` rejection of malformed values, and
  the RFC 9207 `iss` authorization-response parameter.
- **Introspection (RFC 7662) and revocation (RFC 7009)** with per-client token
  ownership enforcement.
- **Discovery** — Authorization Server Metadata (RFC 8414), Protected Resource
  Metadata (RFC 9728), Dynamic Client Registration (RFC 7591/7592), and JWKS.
- **Token signing** — RS256, ES256 and EdDSA (Ed25519, RFC 8037) with `kid`-overlap
  key rotation.
- **UserInfo** endpoint and `id_token` claims (`at_hash`, `auth_time`, `acr`, `amr`,
  `nonce`).
- **Federation** — SAML 2.0 SP (metadata, SP-initiated login, SLO, InResponseTo
  enforcement) and OIDC as a relying party (with `nonce`).
- **Directory sync (SCIM 2.0)** — Users, Groups + membership, the Enterprise User
  extension, and PATCH (including `remove`); deprovisioning deactivates the
  account and revokes sessions.
- **Identity** — sessions with idle + absolute timeout and step-up, password auth,
  MFA (TOTP, recovery codes, WebAuthn/passkeys with user-verification), magic
  links, password reset, email verification, and account-status gating.
- **Organizations & tenancy** — deny-by-default tenant isolation, memberships with
  last-owner protection, and a closure-tree hierarchy.
- **Authorization** — a policy decision point, ReBAC relationship store, and
  entitlements as capability gates (hybrid token-claim / decision-endpoint model).
- **Webhooks** — HMAC-signed delivery with SSRF-guarded, DNS-pinned requests,
  bounded retries with dead-lettering, and a scheduled retry sweep.
- **Audit** — an append-only, hash-chained trail with signed checkpoints.

### Security

- **An ID Token is minted only for a grant that asked for `openid`.** Every user-present
  branch of the token endpoint issued one regardless of scope, so a client requesting
  `api.read` and nothing else got back a signed assertion carrying `sub` and `org` — a
  subject identifier and a tenant, to an OAuth-only client that never asked for identity.
  UserInfo has always refused that same client for the same reason, so the endpoint was
  contradicting itself about who is entitled to an identity claim.

- **A client or directory can no longer be registered against an organization from another
  environment.** `EnvironmentScope` stamps a new row with the ambient environment and never
  looks at the `organization_id` written beside it, so a caller in E1 naming a tenant of E2
  produced a row stamped E1 claiming to belong to E2 — and `client_credentials` would then
  mint E1's `iss` carrying E2's `org`. `MembershipService::add()` had refused this from the
  start; the check is now shared (`OwnerEnvironment`) and applied by the other writers.

- Fixed a cross-tenant account-takeover vector in federated identity linking:
  SSO connection identities are now namespaced to their connection.
- Enforced SAML `InResponseTo` against a request store, DPoP at the resource
  surface and on refresh tokens, account-status gating across all login paths,
  step-up on MFA enrollment and provider unlink, and admin-only reads on the
  console. See the security advisories for detail.
