<?php

declare(strict_types=1);
use Cbox\Id\Identity\Models\User;
use Cbox\Id\Otp\Channels\EmailOtpChannel;

return [

    /*
     * The token issuer / base URL, published in OIDC discovery and used to build
     * endpoint URLs. Falls back to the app URL when unset.
     */
    'issuer' => env('CBOX_ID_ISSUER'),

    /*
     * Override a package model with your own subclass to add relations, casts or
     * behaviour. Your class must extend the package model; the platform still owns
     * the schema. Extend the pattern to other models as you need them.
     */
    'models' => [
        'user' => User::class,
    ],

    /*
     * How the platform resolves "the user". By default it uses a self-contained
     * store over its own users table (`models.user`). To integrate with an app
     * that already has users — including several authenticatable models (users,
     * admins, resellers) or a single model with role flags — set `resolver` to
     * your own class implementing Cbox\Id\Identity\Contracts\Subjects. The
     * platform only ever references a subject by its opaque id.
     */
    'subject' => [
        'resolver' => null,
    ],

    /*
     * Table names the platform reads/writes. Point `users` at your existing user
     * table to integrate with an app that already has one; the platform does not
     * create this table automatically (see the optional cbox-id-users-migration).
     */
    'tables' => [
        'users' => 'users',
    ],

    /*
     * WebAuthn / passkey ceremony parameters. `rp_id` is the Relying Party ID
     * (usually your registrable domain, e.g. "example.com"); `origin` is the
     * exact origin the browser reports (scheme + host + port). Both are asserted
     * during verification — a mismatch is rejected.
     */
    /*
     * Session lifetimes. `ttl_minutes` is the absolute cap; `idle_minutes` (0 to
     * disable) expires a session after inactivity, with a sliding window that is
     * refreshed on use. Secure defaults for an admin console lean short.
     *
     * These are the DEPLOYMENT's ceiling. An environment may shorten either for its own
     * people (AuthPolicy::$sessionIdleMinutes / $sessionAbsoluteMinutes), never lengthen
     * them — see Contracts\SignInMethods.
     */
    'sessions' => [
        'ttl_minutes' => env('CBOX_ID_SESSION_TTL_MINUTES', 60 * 8),
        'idle_minutes' => env('CBOX_ID_SESSION_IDLE_MINUTES', 30),
    ],

    /*
     * Sign-in methods the DEPLOYMENT offers at all. On by default; switching one off here
     * removes it from every environment, whatever an environment's own policy says. An
     * environment can switch off what the deployment offers, never switch on what it does
     * not — see Contracts\SignInMethods.
     */
    'sign_in' => [
        'passkeys' => env('CBOX_ID_PASSKEYS_ENABLED', true),
        'magic_link' => env('CBOX_ID_MAGIC_LINK_ENABLED', true),
    ],

    /*
     * GDPR Art. 17 erasure (SubjectEraser). `pseudonym_key` keys the hash an erased
     * subject's email and name are replaced with. Unset, it is derived from the crypto
     * master key; set it if you rotate that key and need an erasure retried after the
     * rotation to write byte-identical placeholders.
     */
    'erasure' => [
        'pseudonym_key' => env('CBOX_ID_ERASURE_PSEUDONYM_KEY'),
    ],

    /*
     * Login lockout — the deployment default for how many failed sign-ins on ONE
     * subject lock it, inside what window, and for how long.
     *
     * ON BY DEFAULT since 1.22: ten failures inside fifteen minutes lock the account
     * for fifteen minutes. Before that the threshold came only from an `AuthPolicy`
     * and was null unless an operator set one, so a fresh install would accept an
     * unbounded online guessing run against any single account.
     *
     * `threshold` is the floor that applies when no environment or organization
     * policy names one; a policy's `lockoutThreshold` still wins whenever it is set,
     * and an organization may still only TIGHTEN it. Set the threshold to `0` (or
     * `null`) to return to the old behaviour of "off unless a policy says so".
     *
     * The window and the duration are deliberately deployment settings, not tenant
     * policy: a tenant that set either wrong would turn the control into a
     * denial-of-service tool (anyone who knows an email address could lock its
     * owner out indefinitely). The lock always expires on its own.
     */
    'lockout' => [
        'threshold' => env('CBOX_ID_LOCKOUT_THRESHOLD', 10),
        'window_minutes' => env('CBOX_ID_LOCKOUT_WINDOW_MINUTES', 15),
        'duration_minutes' => env('CBOX_ID_LOCKOUT_DURATION_MINUTES', 15),
    ],

    /*
     * User API tokens (`cbid_pat_…`). A token issued without an explicit
     * expiry gets this TTL — no token is ever open-ended.
     */
    'user_api_tokens' => [
        'default_ttl_days' => env('CBOX_ID_USER_API_TOKEN_TTL_DAYS', 90),
    ],

    /*
     * Customer API keys — keys an app's end-customers mint for THAT app's API, verified
     * by the app at `POST /oauth/api-keys/verify` with its own client credentials.
     *
     * `verify_per_minute` throttles that endpoint per caller IP. Verification is on the
     * app's request path, so this is deliberately generous; an app that needs more should
     * cache a verification for a few seconds rather than raise it without limit — the
     * cache length is then how long a revoked key keeps working.
     */
    'customer_api_keys' => [
        'verify_per_minute' => env('CBOX_ID_API_KEY_VERIFY_PER_MINUTE', 600),
    ],

    /*
     * Passkeys / WebAuthn.
     *
     * `rp_id` + `origin` are an OPTIONAL PIN, not a requirement. Left unset (the default)
     * each request derives them from the environment's own issuer, which is the only
     * answer that works on a deployment serving more than one host — one pair pinned to
     * the account root rejects every tenant's passkey, and vice versa.
     *
     * Set them only when this deployment has exactly one passkey origin and it is not the
     * issuer. They are honoured on the host they name and ignored on every other, because
     * a pin the browser will contradict cannot enforce an intent — it can only guarantee
     * a rejected ceremony. `cbox-id:doctor` reports which answer is in force.
     */
    'webauthn' => [
        'rp_id' => env('CBOX_ID_WEBAUTHN_RP_ID'),
        'origin' => env('CBOX_ID_WEBAUTHN_ORIGIN'),
        // Require the user-verification flag on passkey ceremonies (PIN/biometric).
        // Keep true for passwordless (primary-factor) passkeys.
        'user_verification' => env('CBOX_ID_WEBAUTHN_USER_VERIFICATION', true),
    ],

    /*
     * The domain-event outbox (src/Kernel/Events/). Emitting writes a row; nothing is
     * delivered until the relay runs, so `schedule_relay` is what makes webhooks,
     * usage metering, outbound provisioning and every host listener actually fire.
     * Turn it off only if you drive EventBus::flushPending() yourself.
     *
     * `reclaim_after_seconds` is how long a claimed-but-undelivered event waits before
     * another relay may take it — i.e. how long we assume a relay that died mid-pass
     * might still be running.
     *
     * `relay_limit` and `relay_cadence` tune the scheduled pass without turning the
     * schedule off: a busy environment wants a larger batch, a quiet one a slower
     * tick. `relay_cadence` is a closed set (see RelayCadence) — every_minute,
     * every_two_minutes, every_five_minutes, every_ten_minutes,
     * every_fifteen_minutes, every_thirty_minutes, hourly — because a typo'd cron
     * string here would silently stop the entire fan-out.
     *
     * `max_attempts` bounds how many times a THROWING event is retried before it is
     * dead-lettered (`dead_lettered_at` stamped, never claimed again, logged at
     * critical). Unbounded retries are only right for a transient fault: a listener that
     * throws on data which will never change would otherwise be re-delivered on every
     * pass forever — never prunable, permanently counted as backlog, and skipping every
     * listener registered after it, for that event, on every pass.
     *
     * `backlog_warning_threshold` is the waiting depth at which each pass logs a
     * WARNING instead of a debug line. Relay lag is otherwise invisible: a stalled
     * relay looks exactly like an idle one. A host with metrics wiring can resolve
     * the RelayBacklog contract directly, or run `cbox-id:events:backlog` (the
     * package deliberately depends on no telemetry runtime).
     */
    'events' => [
        'schedule_relay' => env('CBOX_ID_EVENTS_SCHEDULE_RELAY', true),
        'relay_limit' => env('CBOX_ID_EVENTS_RELAY_LIMIT', 100),
        'relay_cadence' => env('CBOX_ID_EVENTS_RELAY_CADENCE', 'every_minute'),
        'reclaim_after_seconds' => env('CBOX_ID_EVENTS_RECLAIM_AFTER_SECONDS', 300),
        'max_attempts' => env('CBOX_ID_EVENTS_MAX_ATTEMPTS', 12),
        'backlog_warning_threshold' => env('CBOX_ID_EVENTS_BACKLOG_WARNING_THRESHOLD', 1000),
    ],

    /*
     * Webhook delivery. `verify_url` (SSRF guard) rejects endpoints that resolve
     * to loopback/private/link-local/reserved addresses and pins the connection
     * to the validated IPs (closing DNS-rebinding); keep it true in any
     * multi-tenant deployment. A single-tenant/on-prem install that legitimately
     * delivers to internal hosts may disable it. `max_attempts` bounds retries
     * before a delivery is dead-lettered (status `exhausted`). `schedule_retries`
     * registers a per-minute sweep that re-enqueues due failures; disable it if you
     * drive `retryPending()` yourself.
     *
     * Delivery is ASYNCHRONOUS: the relay records a delivery row per matching
     * endpoint and queues a DeliverWebhook job; the blocking HTTP send happens on a
     * worker. `queue_connection` / `queue` (both optional) put that egress on its
     * own connection/queue so a slow receiver cannot crowd out the rest of the
     * application's jobs. `retry_limit` caps how many due failures one sweep
     * re-enqueues, and `stranded_after_seconds` is how long a still-`pending`
     * delivery may sit before the sweep assumes its job was lost and re-enqueues
     * it — the row is durable BEFORE the job exists, and this is what makes that
     * guarantee real.
     *
     * `circuit_breaker` opens an endpoint after `failure_threshold` consecutive
     * failures and skips it for `cooldown_seconds`, so a blackholing receiver costs
     * one timeout per cooldown window instead of one per event. The trip is
     * recorded on the endpoint's health columns, NOT on `status` — `paused` stays
     * the operator's own intent.
     */
    /*
     * SCIM 2.0 service-provider discovery.
     *
     * `documentation_uri` is the OPTIONAL `documentationUri` of RFC 7643 §5 — an
     * HTTP-addressable page describing this deployment's SCIM support, which some
     * connectors surface to the operator during setup. It is UNSET by default and the
     * field is then omitted entirely: it used to be hard-coded to `<app>/docs`, a route
     * this package does not register and most hosts do not either, so the link that
     * appeared in a connector's setup screen led to a 404. An absent optional field is
     * correct; a present broken one is a promise the deployment cannot keep.
     *
     * `bulk` bounds `POST /scim/v2/Bulk` (RFC 7644 §3.7.4): at most `max_operations`
     * operations and `max_payload_size` bytes per request, each exceeded with a 413
     * that names the limit, and both advertised in ServiceProviderConfig. One bulk
     * request counts once against the SCIM rate limit however many operations it
     * carries, so these are what bound its cost.
     */
    'scim' => [
        'documentation_uri' => env('CBOX_ID_SCIM_DOCUMENTATION_URI'),
        'bulk' => [
            'max_operations' => env('CBOX_ID_SCIM_BULK_MAX_OPERATIONS', 1000),
            'max_payload_size' => env('CBOX_ID_SCIM_BULK_MAX_PAYLOAD_SIZE', 1048576),
        ],
    ],

    'webhooks' => [
        'verify_url' => env('CBOX_ID_WEBHOOKS_VERIFY_URL', true),
        'max_attempts' => env('CBOX_ID_WEBHOOKS_MAX_ATTEMPTS', 12),
        'schedule_retries' => env('CBOX_ID_WEBHOOKS_SCHEDULE_RETRIES', true),
        'retry_limit' => env('CBOX_ID_WEBHOOKS_RETRY_LIMIT', 50),
        'stranded_after_seconds' => env('CBOX_ID_WEBHOOKS_STRANDED_AFTER_SECONDS', 900),
        'queue_connection' => env('CBOX_ID_WEBHOOKS_QUEUE_CONNECTION'),
        'queue' => env('CBOX_ID_WEBHOOKS_QUEUE'),
        'circuit_breaker' => [
            'failure_threshold' => env('CBOX_ID_WEBHOOKS_CB_FAILURE_THRESHOLD', 5),
            'cooldown_seconds' => env('CBOX_ID_WEBHOOKS_CB_COOLDOWN_SECONDS', 300),
        ],
    ],

    /*
     * SIEM audit streaming (src/AuditStreaming/). Mirrors the hash-chained,
     * environment-scoped audit trail out to a customer's SIEM by composing
     * cboxdk/laravel-siem's delivery engine over ENVIRONMENT-OWNED stream/outbox
     * models — so isolation is inherited from the hard environment scope, never
     * re-implemented. The engine itself is configured under the `siem.*` namespace
     * (published from cboxdk/laravel-siem: batching, retry/dead-letter, circuit
     * breaker, backpressure, HTTP egress). This package forces three of those keys
     * and owns none of the rest:
     *   - siem.models.log_stream      → AuditStream (env-owned)
     *   - siem.models.stream_delivery → AuditStreamDelivery (env-owned)
     *   - siem.schedule.enabled       → false (laravel-id schedules the pump, so it
     *                                   can reconstruct each stream's environment)
     *
     * SECURITY: `siem.http.verify_url` (the SSRF guard) and `siem.http.tls_verify`
     * are operator-only. NEVER expose either to a tenant/org admin — a tenant that
     * could disable the SSRF guard could point a stream at an internal address.
     *
     * `schedule` registers the per-minute pump that fans a delivery job out to every
     * enabled stream across all environments; disable it to run
     * `cbox-id:audit-streams:pump` yourself.
     */
    'audit_streaming' => [
        'schedule' => env('CBOX_ID_AUDIT_STREAMING_SCHEDULE', true),
    ],

    /*
     * The hash-chained audit trail itself (src/Kernel/Audit/).
     *
     * `checkpoint.schedule` registers a daily pass (`cbox-id:audit:checkpoint`) that
     * signs a checkpoint over every chain that has advanced since its last one. A
     * checkpoint is the ONLY thing that detects TAIL DELETION: the chain catches
     * modification and sequence gaps by itself, but delete the newest N entries and
     * what is left is a shorter, perfectly valid chain. Signing costs one row per
     * chain per day and nothing at all for a chain that has not been appended to.
     *
     * IT DEFAULTS TO FALSE, AND THAT IS NOT AN OVERSIGHT.
     *
     * The first signature is a one-way door. A checkpoint is permanent, exportable
     * evidence about the chain's hashes as they are TODAY, and the GDPR-erasure work
     * still to come needs exactly one re-chain of the existing rows — hashing the
     * CIPHERTEXT of `ip` and `context` rather than the plaintext, so that destroying
     * a per-subject key leaves every hashed byte unchanged and verifyChain() keeps
     * passing bit-for-bit. Any checkpoint signed BEFORE that re-chain would report
     * tampering that never happened, forever. No checkpoint has ever been signed
     * (`audit_checkpoints` is empty), so the window is still open.
     *
     * The order to enable it in, spelled out in UPGRADING.md and
     * docs/operations/background-work.md:
     *
     *   1. sign and retain each chain's head hash and row count OUT OF BAND;
     *   2. introduce `chain_version` + ciphertext hashing;
     *   3. run the one-time re-chain;
     *   4. THEN set this to true.
     *
     * A deployment with no such migration ahead of it can set it to true today, and
     * should: until then nothing detects a truncated trail. `--dry-run` reports what
     * would be signed without signing anything.
     */
    'audit' => [
        'checkpoint' => [
            'schedule' => env('CBOX_ID_AUDIT_CHECKPOINT_SCHEDULE', false),
            'time' => env('CBOX_ID_AUDIT_CHECKPOINT_TIME', '02:40'),
        ],
    ],

    /*
     * Outbound SCIM 2.0 provisioning (src/Provisioning/). The mirror of the
     * inbound Directory (SCIM server): when a user or membership changes, the
     * platform pushes the change OUT to each org's downstream SaaS apps via THEIR
     * SCIM endpoints (create/update/deactivate the remote user).
     *
     * `verify_url` (SSRF guard) rejects a downstream SCIM base URL or OAuth token
     * URL that resolves to loopback/private/link-local/reserved addresses and pins
     * the connection to the validated IPs (closing DNS-rebinding) — the same guard
     * webhooks and federation use. Keep it true in any multi-tenant deployment; a
     * single-tenant/on-prem install delivering to an internal SCIM endpoint may
     * disable it. `max_attempts` bounds retries before an operation is dead-lettered
     * (status `exhausted`); `batch_limit` caps how many operations one drain pass
     * ships per connection. `circuit_breaker` opens a connection after
     * `failure_threshold` consecutive transient failures and pauses it for
     * `cooldown_seconds`, so a failing downstream app never blocks the others.
     * `schedule` registers the per-minute drain that fans a job out to every active
     * connection across all environments; disable it to run
     * `cbox-id:provisioning:drain` yourself.
     */
    'provisioning' => [
        'verify_url' => env('CBOX_ID_PROVISIONING_VERIFY_URL', true),
        'max_attempts' => env('CBOX_ID_PROVISIONING_MAX_ATTEMPTS', 12),
        'batch_limit' => env('CBOX_ID_PROVISIONING_BATCH_LIMIT', 50),
        'schedule' => env('CBOX_ID_PROVISIONING_SCHEDULE', true),
        'circuit_breaker' => [
            'failure_threshold' => env('CBOX_ID_PROVISIONING_CB_FAILURE_THRESHOLD', 5),
            'cooldown_seconds' => env('CBOX_ID_PROVISIONING_CB_COOLDOWN_SECONDS', 300),
        ],
    ],

    /*
     * Directory sync (inbound, API-pull: Google Workspace, Microsoft Entra, and the HR
     * systems Workday, BambooHR, Rippling, HiBob and Personio).
     *
     * `schedule` is the whole feature working or not working. A pull connector reconciles
     * on a timer by definition — nobody pushes to it — and the ONE caller of
     * `cbox-id:directory:sync` was the console screen that creates a directory. So a
     * customer connected Entra, saw one successful sync, and never got another: joiners
     * never arrived, and — the half that matters — LEAVERS were never deprovisioned, while
     * the guide told them syncing is what "closes the gap where a leaver still has a
     * working account".
     *
     * Hourly by default rather than every minute: this is a pull of a customer's directory
     * over somebody else's rate-limited API, and the thing it is racing is a person's notice
     * period. Each directory may set its own interval (15 minutes to a day); the scheduler
     * ticks every fifteen minutes and pulls what is due. Turn this off to schedule
     * `cbox-id:directory:sync` yourself.
     */
    'directory' => [
        'schedule' => env('CBOX_ID_DIRECTORY_SCHEDULE', true),

        /*
         * How often a pull directory with no interval of its own is pulled, in minutes. The
         * scheduler ticks every fifteen and pulls whatever is due; a directory's own
         * `sync_interval_minutes` (15..1440) overrides this.
         */
        'default_interval_minutes' => env('CBOX_ID_DIRECTORY_INTERVAL_MINUTES', 60),

        /* The longest one directory's sync lock is held, in seconds. */
        'lock_seconds' => env('CBOX_ID_DIRECTORY_LOCK_SECONDS', 3600),

        /*
         * HR systems (Workday, BambooHR, Rippling, HiBob, Personio).
         *
         * - `pre_hire_days`: how many days before their start date a new hire gets an
         *   account. 0 is on the day.
         * - `full_sync_hours`: an HR system that can answer "changed since" is asked that
         *   between full pulls at most this far apart. Only a full pull deprovisions people
         *   it did not see, so this bounds how long a deleted record lingers.
         * - `deprovision_guard`: a full pull that would deprovision more than this share of
         *   the active people (with at least ten active) deprovisions nobody and reports
         *   why — an API key that lost its reach looks exactly like a mass layoff. 1 turns
         *   the guard off.
         * - `max_attempts` / `max_backoff_seconds`: retries on 429 and 502–504, honouring
         *   Retry-After, and the longest single wait.
         * - `max_reported_failures`: how many per-record failures one run keeps.
         * - `workday_hosts`: the host suffixes a Workday report address may name. The address
         *   is the customer's, so it is pinned to Workday's own domains — the credentials go
         *   wherever it points.
         */
        'hris' => [
            'pre_hire_days' => env('CBOX_ID_HRIS_PRE_HIRE_DAYS', 0),
            'full_sync_hours' => env('CBOX_ID_HRIS_FULL_SYNC_HOURS', 24),
            'deprovision_guard' => env('CBOX_ID_HRIS_DEPROVISION_GUARD', 0.5),
            'max_attempts' => env('CBOX_ID_HRIS_MAX_ATTEMPTS', 5),
            'max_backoff_seconds' => env('CBOX_ID_HRIS_MAX_BACKOFF_SECONDS', 60),
            'max_reported_failures' => 50,
            'workday_hosts' => ['.workday.com', '.myworkday.com'],
        ],
    ],

    /*
     * Federation (inbound SSO). `verify_url` (SSRF guard) applies the same
     * loopback/private/link-local/reserved blocking and DNS-pinning as webhook
     * delivery to org-admin-configured outbound IdP endpoints (e.g. an OIDC
     * `token_endpoint`) that the platform fetches server-side. Keep it true in any
     * multi-tenant deployment; a single-tenant/on-prem install that must reach an
     * internal IdP may disable it.
     */
    'federation' => [
        'verify_url' => env('CBOX_ID_FEDERATION_VERIFY_URL', true),
    ],

    /*
     * Access control — app authorization manifests. When an app publishes its
     * roles/permissions at a well-known URL, the platform PULLS it server-side, so
     * `verify_manifest_url` (SSRF guard) applies the same private/reserved/metadata
     * blocking + DNS-pinning as federation/webhooks. `fetch_timeout` bounds the
     * pull. Keep the guard true in any multi-tenant deployment.
     */
    'access_control' => [
        /*
         * RBAC driver — which authorization backend the platform (and its token
         * claims) reads from.
         *   'builtin'  — the package's own hierarchy-aware RBAC. Loads the
         *                roles/permissions/… schema and binds the built-in services.
         *   'external' — bring-your-own. The built-in tables and their migrations
         *                are NOT loaded, and AccessChecker/Roles fall back to a
         *                refusing default (deny-by-default) until you bind an adapter
         *                (e.g. one backed by an existing Spatie permission install).
         *                See docs/extension-points/custom-rbac.md.
         */
        'driver' => env('CBOX_ID_ACCESS_CONTROL_DRIVER', 'builtin'),

        'verify_manifest_url' => env('CBOX_ID_MANIFEST_VERIFY_URL', true),
        'fetch_timeout' => (int) env('CBOX_ID_MANIFEST_FETCH_TIMEOUT', 10),
    ],

    /*
     * Environments — the hard identity boundary resolved per request from the host
     * (own users, signing keys, issuer). When the host maps to none, the fallback
     * plane is used: the environment flagged `is_default` in the database (the
     * primary mechanism — set once by `cbox-id:install`, held across every replica
     * with no writable .env). This `default` config key is an OPTIONAL override
     * that wins when set — an explicit environment key via env var / ConfigMap.
     * Leave both unset in a multi-tenant deployment (an unknown host is refused).
     */
    'environments' => [
        'default' => env('CBOX_ID_ENVIRONMENT_DEFAULT'),

        /*
         * Base domains under which a subdomain resolves to an environment by its
         * leading label (e.g. `staging.auth.example.com` → the `staging` plane).
         * A host is only trusted for slug resolution when it sits under one of
         * these — so a spoofed Host like `staging.attacker.com` can never select a
         * plane. Leave empty to require an exact custom-domain match. Comma list
         * via env, or an array here.
         */
        'base_domains' => array_filter(array_map(
            'trim',
            explode(',', (string) env('CBOX_ID_ENVIRONMENT_BASE_DOMAINS', '')),
        )),

        /*
         * How long (seconds) a host → environment resolution is cached.
         *
         * Every request resolves its environment before any endpoint logic runs, and
         * uncached that is 2–3 queries (custom domain, then slug, then the owning
         * account's liveness) against a table that changes approximately never.
         *
         * Invalidation is explicit, not TTL-driven, for everything that matters:
         * creating, renaming, re-domaining or suspending an environment, and
         * suspending or reactivating its account, all drop the entry immediately —
         * so the platform's off-switch still cuts traffic on the next request. The
         * TTL only bounds the one case that cannot be enumerated from the row: a
         * SLUG rename, where the old subdomain keeps resolving until it lapses.
         *
         * Set to 0 to disable caching entirely.
         */
        'resolution_cache_ttl' => env('CBOX_ID_ENVIRONMENT_RESOLUTION_CACHE_TTL', 60),
    ],

    /*
     * Management keys — the bearer credentials a host's management APIs authenticate.
     *
     * `organization_prefix` is what an organization (management-plane) key starts with,
     * `cbid_org_` by default. A host whose product calls that plane something else may
     * name it so a leaked key reads as what it is (`cbid_ws_` for a "workspace"). The
     * prefix is part of the stored hash, so CHANGING it invalidates every key already
     * issued under the old one: choose it before the first key, or re-mint after. It must
     * be lowercase letters and digits ending in `_`; anything else falls back to the
     * default.
     */
    'management_keys' => [
        'organization_prefix' => env('CBOX_ID_ORGANIZATION_KEY_PREFIX', 'cbid_org_'),
    ],

    /*
     * The IdP PROTOCOL surface this package registers — OIDC discovery, JWKS, the
     * RFC 8414 / RFC 9728 metadata, every `/oauth/*` endpoint, the SAML endpoints and
     * SCIM — and the extra middleware a HOST may wrap around all of it.
     *
     * EMPTY BY DEFAULT, deliberately: a single-tenant / self-hosted deployment is one
     * host that IS the identity provider, and it must keep serving the whole surface
     * with no configuration at all.
     *
     * A host application may serve more than identity providers. If one of its hosts is
     * a signup / account-management surface rather than an issuer, serving discovery
     * there publishes an `issuer` whose `authorization_endpoint` that host does not
     * answer — and a conformant client follows the document straight into a 404. Naming
     * middleware here lets the host 404 the entire surface on such a host using ITS OWN
     * answer to "is this host an identity provider", instead of this package growing a
     * second copy of that question that could disagree with the host's.
     *
     * Values are middleware aliases (e.g. `'plane:subject'`) or class names. They are
     * applied AFTER {@see \Cbox\Id\Api\Http\Middleware\ResolveEnvironment}, so a gate
     * can read the environment the request resolved to. `GET /up` is deliberately NOT
     * covered — a liveness probe must answer on every host.
     */
    'api' => [
        'middleware' => [],
    ],

    /*
     * OAuth 2.0 Dynamic Client Registration (RFC 7591) and client management
     * (RFC 7592). MCP clients rely on DCR to self-register.
     *
     * mode:
     *   'disabled'  — /oauth/register returns 403 and is not advertised (default,
     *                 secure-by-default: open registration is an abuse surface).
     *   'protected' — registration requires an initial access token (bearer)
     *                 matching `initial_access_token`.
     *   'open'      — anyone may register (rate-limited). Suitable for public MCP
     *                 deployments that expect unknown clients.
     *   'mcp'       — anyone may register, held to the MCP profile: public clients
     *                 only (PKCE), the authorization_code/refresh_token grants, https or
     *                 loopback redirect URIs, and only the scopes of protected resources
     *                 declared with `dynamic_clients` (plus the protocol scopes listed in
     *                 allowed_scopes). Reserved scopes are never granted.
     *
     * allowed_scopes limits what a dynamically registered client may request; a
     * requested scope outside this list is dropped. It governs scopes no API owns:
     * a scope a registered API owns is accepted when the API is environment-owned
     * and the scope tenant-requestable, and refused otherwise — listing it here
     * cannot widen that. grant_types listed here are the only ones a dynamic client
     * may be granted.
     */
    /*
    |---------------------------------------------------------------------------
    | Frontend API
    |---------------------------------------------------------------------------
    |
    | The browser-facing channel: a page holding a PUBLISHABLE key reads its
    | sign-in configuration, and the signed-in user, directly — with no server of
    | its own in the middle. It is what lets an SDK component render a themed
    | sign-in box instead of sending the person away to a hosted page.
    |
    | OFF BY DEFAULT, deliberately. The safety of a public key rests entirely on
    | the origin allow-list attached to it, so an install that has named no
    | origins should not be answering browsers at all — and a browser-facing
    | surface that appears silently on upgrade is one nobody reviewed.
    |
    | Turning it on serves `/frontend/v1/*`. Nothing there grants authority: the
    | config document is public by nature, and the session document is authorized
    | by the bearer token the page already holds, never by the key.
    |
    */
    /*
    |---------------------------------------------------------------------------
    | Migrating off another system
    |---------------------------------------------------------------------------
    |
    | Bulk import (`UserImport`) is the first answer and the better one: it moves
    | users WITH their existing hashes, each upgraded on first login, and the old
    | system can be switched off the same day. It needs you to be able to EXPORT
    | those hashes.
    |
    | When you cannot — the hashes sit behind an API, or in a format nothing
    | recognises — the verification moves instead of the data. An email nobody
    | here knows is offered to the old system, and on a yes the person is created
    | here as a result of the login that just succeeded.
    |
    | Two rules hold regardless of which source you bind, and both are security
    | properties: a user who already exists HERE is never offered to the old
    | system (or a password they changed here could be bypassed by the one still
    | sitting there), and a source that cannot answer refuses the sign-in rather
    | than allowing it (or an outage in the system you are leaving becomes an
    | authentication bypass).
    |
    | `verify_url` pins outbound DNS and refuses private ranges for the HTTP
    | source. A legacy system is very often on a private network — that is what
    | makes it legacy — so this is the switch for saying so deliberately.
    |
    */
    'migration' => [
        'verify_url' => env('CBOX_ID_MIGRATION_VERIFY_URL', true),
    ],

    'frontend_api' => [
        'enabled' => env('CBOX_ID_FRONTEND_API', false),
    ],

    'oauth' => [
        /*
         * Scopes no client may grant ITSELF. A dynamically registered client is refused
         * these at registration and on every later save, even if `allowed_scopes` below
         * names one: each is authority over the environment (its stored secrets, its
         * apps' role catalogues, every person's permissions), which an operator hands out
         * deliberately and a self-registering client must never be able to ask for.
         */
        'reserved_scopes' => ['vault.manage', 'vault.lease', 'apps.manifest', 'decisions:read'],

        'dynamic_registration' => [
            'mode' => env('CBOX_ID_DCR_MODE', 'disabled'),
            'initial_access_token' => env('CBOX_ID_DCR_INITIAL_ACCESS_TOKEN'),
            // `organizations` is advertised in discovery (scopes_supported) and the
            // token/UserInfo layer emits the claim, but it was missing here — so a
            // dynamically-registered client could never actually obtain it. Advertised
            // and unreachable is the same bug the grant list below fixed.
            // `groups` is here for the same reason `organizations` is: both are advertised
            // in `scopes_supported` and both emit a real claim, so a self-registering
            // client that read discovery and asked for one got `invalid_scope`. The
            // Kubernetes case is the one that bites — `kubectl oidc-login` reads the
            // document, requests `openid groups`, and is refused at /authorize by the very
            // server that told it the scope exists.
            // `feature_flags` (1.24) likewise: advertised, and it emits a claim. It
            // discloses only the keys of the flags on for the person who consented.
            'allowed_scopes' => ['openid', 'profile', 'email', 'offline_access', 'organizations', 'groups', 'feature_flags'],
            /*
             * Grants a DYNAMICALLY registered client may ask for. device_code, CIBA and
             * token-exchange were advertised in discovery but absent here, so no
             * DCR-registered client could ever use them — advertised and unreachable.
             */
            'allowed_grant_types' => [
                'authorization_code',
                'refresh_token',
                'client_credentials',
                'urn:ietf:params:oauth:grant-type:device_code',
                'urn:openid:params:grant-type:ciba',
                'urn:ietf:params:oauth:grant-type:token-exchange',
            ],

            /*
             * Registrations per client IP address per hour, in the modes that need no
             * credential (`open`, `mcp`). On top of the per-minute throttle every
             * protocol endpoint has. 0 or null switches the hourly ceiling off.
             */
            'max_per_ip_per_hour' => env('CBOX_ID_DCR_MAX_PER_IP_PER_HOUR', 20),
        ],

        /*
         * Resource servers the HOST application serves itself — beside the registered
         * APIs operators manage as data. Each is an RFC 8707 audience a client may ask
         * for with `resource`, and is described by RFC 9728 metadata at
         * `/.well-known/oauth-protected-resource/{path}`.
         *
         *   [
         *       'path' => '/mcp',                // joined to the environment's issuer…
         *       // 'identifier' => 'https://…',  // …or an absolute identifier
         *       'name' => 'MCP',                 // RFC 9728 resource_name (optional)
         *       'scopes' => ['mcp:read', 'mcp:write'],
         *       'dynamic_clients' => true,       // self-registered clients may use it
         *       // 'client_id' => '…',           // whose app roles its tokens carry
         *       // 'documentation' => 'https://…',
         *   ],
         *
         * Rebind Cbox\Id\OAuthServer\Contracts\ProtectedResources to compute the list.
         */
        'protected_resources' => [],

        /*
         * RFC 8707 `resource` values that are none of: a registered API, a declared
         * protected resource, the issuer. `accept` (the default, and the behaviour
         * before 1.22) binds the token to the value verbatim for an operator-registered
         * client; `refuse` answers `invalid_target`. A self-registered client (RFC 7591,
         * or a client ID metadata document) is ALWAYS refused an unknown resource.
         */
        'resource_indicators' => [
            'unknown_resources' => env('CBOX_ID_UNKNOWN_RESOURCES', 'accept'),
        ],

        /*
         * Client ID Metadata Documents (draft-ietf-oauth-client-id-metadata-document):
         * an https URL accepted as `client_id`, its JSON document read as the client's
         * registration. Off by default. When on, discovery advertises
         * `client_id_metadata_document_supported`.
         *
         * The document is fetched server-side from a URL the CLIENT chose, so: through
         * the SSRF guard (`verify_url` — keep it on; switch it off only to reach a
         * development host you own), no redirects, at most `max_bytes`, within
         * `timeout` / `connect_timeout` seconds. It is cached for its Cache-Control
         * max-age, held between `min_ttl` and `max_ttl`, or `default_ttl` when it
         * declares none.
         *
         * A document client is a public client (or `private_key_jwt` via `jwks_uri`),
         * consent is always required, and its scopes are those of declared protected
         * resources with `dynamic_clients` plus the protocol scopes in
         * `dynamic_registration.allowed_scopes` — never a reserved scope.
         */
        'client_id_metadata_documents' => [
            'enabled' => env('CBOX_ID_CIMD_ENABLED', false),
            'verify_url' => env('CBOX_ID_CIMD_VERIFY_URL', true),
            'max_bytes' => env('CBOX_ID_CIMD_MAX_BYTES', 5120),
            'timeout' => env('CBOX_ID_CIMD_TIMEOUT', 5),
            'connect_timeout' => env('CBOX_ID_CIMD_CONNECT_TIMEOUT', 3),
            'min_ttl' => env('CBOX_ID_CIMD_MIN_TTL', 60),
            'default_ttl' => env('CBOX_ID_CIMD_DEFAULT_TTL', 3600),
            'max_ttl' => env('CBOX_ID_CIMD_MAX_TTL', 86400),
        ],

        /*
         * The interactive authorization endpoint (OIDC/OAuth `/authorize`) is the
         * HOST app's responsibility — this package serves the back-channel token,
         * introspection, revocation and PAR endpoints, not the user-facing consent
         * screen. Set this to the absolute URL where the host mounts `/authorize`
         * and it is advertised in discovery metadata; leave it null (default) and
         * the `authorization_endpoint` key is omitted rather than pointing at a
         * route the package does not serve (RFC 8414 allows omitting it).
         */
        'authorization_endpoint' => env('CBOX_ID_AUTHORIZATION_ENDPOINT'),

        /*
         * Preferred over the absolute form above: a PATH, joined to the per-environment
         * issuer, so every tenant advertises its own authorize endpoint on its own host.
         * An absolute URL pins all environments to one host — wrong under multi-tenancy,
         * and it breaks mix-up-hardened clients because RFC 9207 is advertised with it.
         */
        'authorization_endpoint_path' => env('CBOX_ID_AUTHORIZATION_ENDPOINT_PATH'),

        /*
         * FAPI baseline: require every authorization request to be pushed
         * (RFC 9126) so parameters never ride the browser URL. Turning this on is
         * one of the switches in the FAPI hardening profile — see docs/fapi.md.
         */
        'require_par' => env('CBOX_ID_REQUIRE_PAR', false),

        /*
         * OpenID Connect CIBA (Client-Initiated Backchannel Authentication), poll
         * mode — the human-in-the-loop approval grant for autonomous / AI agents.
         * `ttl_seconds` is the approval window (and the ceiling on a client's
         * requested_expiry); `poll_interval` is the minimum seconds between token
         * polls (enforced with `slow_down`). The user notification + approval UI is
         * the host's; the package emits `oauth.backchannel_authentication_requested`.
         */
        'ciba' => [
            'ttl_seconds' => env('CBOX_ID_CIBA_TTL_SECONDS', 300),
            'poll_interval' => env('CBOX_ID_CIBA_POLL_INTERVAL', 5),
        ],

        /*
         * OpenID Connect Back-Channel Logout 1.0: when a session ends, POST a signed
         * logout token to every application it signed the person in to that registered a
         * `backchannel_logout_uri`. Delivery is a queued job — run a queue worker.
         *
         * `verify_url` is the SSRF guard on the delivery: private, loopback, link-local
         * and cloud-metadata addresses are refused and the connection is pinned to the
         * addresses checked. Keep it on anywhere a tenant can register a client; switch it
         * off only to reach an internal host you own (or `http://localhost` in development).
         * `timeout` / `connect_timeout` are per attempt, in seconds; `max_attempts` is how
         * many tries before the failure is recorded in the audit trail and dropped
         * (backoff: 10s, 1m, 5m, 15m, 15m…).
         */
        'backchannel_logout' => [
            'verify_url' => env('CBOX_ID_BACKCHANNEL_LOGOUT_VERIFY_URL', true),
            'timeout' => env('CBOX_ID_BACKCHANNEL_LOGOUT_TIMEOUT', 5),
            'connect_timeout' => env('CBOX_ID_BACKCHANNEL_LOGOUT_CONNECT_TIMEOUT', 3),
            'max_attempts' => env('CBOX_ID_BACKCHANNEL_LOGOUT_MAX_ATTEMPTS', 5),
        ],

        /*
         * Hybrid entitlements: embed the coarse, Claims-mode entitlements in the
         * access token (`ent` claim) so resource servers can gate statelessly.
         * Instant-critical entitlements stay DecisionApi (live via /oauth/decisions)
         * regardless. Turn off to keep tokens free of entitlement claims entirely.
         */
        'embed_entitlements' => env('CBOX_ID_EMBED_ENTITLEMENTS', true),

        /*
         * Access-token lifetime, in seconds. Access tokens carry roles + permissions
         * claims, so a SHORT lifetime is how authorization stays fresh: a revoked or
         * downgraded grant self-heals within one TTL, with no per-request revocation
         * check. Pair a short TTL with refresh tokens (which ARE revocable — see
         * RefreshTokens::revokeForUser) for instant effect on the next refresh.
         * Default 900s (15 min).
         */
        'access_token_ttl' => env('CBOX_ID_ACCESS_TOKEN_TTL', 900),

        /*
         * The longest access-token lifetime a single CLIENT may ask for, in seconds
         * (its `access_token_ttl`). A value above this is refused when a client is
         * registered or updated, and a client already above it is clamped to it at
         * minting — so lowering the ceiling takes effect on the next token. The
         * deployment default above is not clamped. Default 86400 (one day).
         */
        'max_access_token_ttl' => env('CBOX_ID_MAX_ACCESS_TOKEN_TTL', 86400),

        /*
         * Client secret rotation. `max_rotation_grace` is the longest a replaced
         * secret may keep working after a rotation, in seconds — the overlap in
         * which deployments move to the new secret. Bounded so a rotation cannot
         * leave the old credential alive indefinitely. Default 2592000 (30 days).
         */
        'client_secrets' => [
            'max_rotation_grace' => env('CBOX_ID_CLIENT_SECRET_MAX_ROTATION_GRACE', 2592000),
        ],

        /*
         * Support sessions (RFC 8693 `act`): staff acting as a customer's user in one
         * app. `max_ttl` is the longest a session — and every token minted for it — may
         * live, in seconds. It can only LOWER the one-hour ceiling, which is fixed in
         * code; a larger value is treated as 3600, and nothing goes below 60.
         */
        'support_sessions' => [
            'max_ttl' => env('CBOX_ID_SUPPORT_SESSION_MAX_TTL', 3600),
        ],

        /*
         * `POST /oauth/decisions` — the authorization decision endpoint.
         *
         * `max_batch` caps how many permission checks (and how many entitlement
         * keys) one request may ask for; past it the endpoint answers 422. Each
         * permission check walks the relationship graph with two queries per node up
         * to a depth of 12, so an uncapped array lets any holder of a valid token
         * turn one HTTP request into an unbounded number of database round trips.
         * Raise it if your clients legitimately batch more than a screen's worth,
         * but do not remove the bound.
         */
        'decisions' => [
            'max_batch' => env('CBOX_ID_DECISIONS_MAX_BATCH', 50),

            /*
             * Require the `decisions:read` scope on the presented token.
             *
             * Off by default, and deliberately: this endpoint has always accepted any
             * active access token, so switching it on unannounced refuses every
             * integration that has not been updated to ask for the scope. Turn it on
             * once your resource servers request it.
             *
             * The AUDIENCE check is not optional and is always enforced. A token minted
             * for a different RFC 8707 resource was never meant to work here, and
             * accepting one hands a resource server the subject's entire permission and
             * entitlement set in the organization — strictly more than UserInfo would
             * give it, which has refused the same token all along.
             */
            'require_scope' => (bool) env('CBOX_ID_OAUTH_DECISIONS_REQUIRE_SCOPE', false),
        ],
    ],

    /*
     * SAML 2.0 Identity Provider (this platform acting AS the IdP that downstream
     * service providers — Salesforce, Workday, AWS, … — federate to).
     *
     * `entity_id` is the IdP EntityID published in metadata and set as the
     * assertion Issuer. It is an opaque URI and MUST stay stable once SPs have
     * imported it; leave null to derive `{issuer}/sso/saml/idp` — the derived
     * value is then FROZEN per environment on first publication, so verifying a
     * custom domain later moves the endpoint URLs but never the EntityID.
     *
     * `want_authn_requests_signed` pins the metadata attribute of the same name.
     * Leave null and it is derived from the registered SPs (true as soon as any
     * active SP requires signed AuthnRequests), which is what an SP that treats
     * metadata as authoritative — Shibboleth, Entra — needs to see.
     *
     * `login_url` is where the SingleSignOnService endpoint sends a browser that
     * has no authenticated subject yet — the host's own login screen. The endpoint
     * appends `return_to` so the host can re-dispatch the SSO request after the
     * user signs in. Leave null and an unauthenticated SSO request is answered
     * with 401 (the host is expected to drive the flow itself).
     */
    'saml_idp' => [
        'entity_id' => env('CBOX_ID_SAML_IDP_ENTITY_ID'),
        'login_url' => env('CBOX_ID_SAML_IDP_LOGIN_URL'),
        'want_authn_requests_signed' => env('CBOX_ID_SAML_IDP_WANT_AUTHN_REQUESTS_SIGNED'),
    ],

    /*
     * Password-hash verification for bulk import + lazy migration. The platform
     * verifies stored password hashes through a DENY-BY-DEFAULT registry: a hash
     * whose format no registered verifier understands is REFUSED, never a silent
     * pass. The package ships only the native verifier (bcrypt + argon2, via PHP's
     * vetted password_verify). To accept a foreign format when migrating off
     * another provider — Firebase scrypt, PBKDF2, an LDAP {SSHA} digest — add your
     * own class implementing Cbox\Id\Identity\Contracts\HashVerifier (wrapping a
     * vetted library; never hand-roll the primitive). Once a user with such a hash
     * signs in successfully, their password is transparently re-hashed with the
     * platform hasher (see Subjects::verifyPassword()), so the foreign format is
     * needed only during the migration window.
     */
    'hashing' => [
        'verifiers' => [
            // App\Auth\FirebaseScryptVerifier::class,
        ],
    ],

    /*
     * Delivered one-time passcodes (src/Otp/) — email/SMS codes as a verification
     * or MFA factor. Security note: a short numeric code lives in a ~10^length
     * space, so its safety rests on these CAPS, not on the code's entropy —
     * `ttl_seconds`, `max_attempts`, and the two rate limits are the real controls.
     *
     * `channels` is the DENY-BY-DEFAULT sender registry (`key => OtpChannel class`).
     * A key with no registered sender is refused, never a silent no-op. The package
     * ships `email` (framework mailer) and `log` (DEV-ONLY: writes the code to the
     * log). SMS ships as `Cbox\Id\Otp\Channels\SmsOtpChannel` over the `sms` block
     * below — map it here to issue codes by text (see
     * docs/cookbook/add-an-sms-otp-channel.md). No provider SDK is a dependency.
     *
     * `issue` throttles issuance: `max_per_window` per recipient+purpose+IP, and
     * `per_recipient_max` per recipient ACROSS all purposes and IPs — the latter is
     * what bounds SMS-bombing when an attacker rotates IPs or purposes. `verify`
     * throttles verification: `max_per_window` globally per IP, and
     * `per_recipient_max` per recipient+purpose across IPs (anti-brute-force). A
     * short numeric code is only safe because of these caps, not its entropy.
     */
    'otp' => [
        // Minimum enforced length is 6 digits (see OtpServiceProvider::clampedLength).
        'code_length' => env('CBOX_ID_OTP_CODE_LENGTH', 6),
        'ttl_seconds' => env('CBOX_ID_OTP_TTL_SECONDS', 300),
        'max_attempts' => env('CBOX_ID_OTP_MAX_ATTEMPTS', 5),

        'issue' => [
            'max_per_window' => env('CBOX_ID_OTP_ISSUE_MAX', 5),
            'per_recipient_max' => env('CBOX_ID_OTP_ISSUE_RECIPIENT_MAX', 10),
            'window_seconds' => env('CBOX_ID_OTP_ISSUE_WINDOW', 3600),
        ],

        'verify' => [
            'max_per_window' => env('CBOX_ID_OTP_VERIFY_MAX', 20),
            'per_recipient_max' => env('CBOX_ID_OTP_VERIFY_RECIPIENT_MAX', 15),
            'window_seconds' => env('CBOX_ID_OTP_VERIFY_WINDOW', 900),
        ],

        'channels' => [
            'email' => EmailOtpChannel::class,
            // Local development only — logs the plaintext code. Never enable in prod.
            // 'log' => Cbox\Id\Otp\Channels\LogOtpChannel::class,
            // Text messages through the `sms` block below (provider, toll-fraud caps):
            // 'sms' => Cbox\Id\Otp\Channels\SmsOtpChannel::class,
        ],

        'email' => [
            'subject' => env('CBOX_ID_OTP_EMAIL_SUBJECT', 'Your verification code'),
            'from' => [
                'address' => env('CBOX_ID_OTP_EMAIL_FROM_ADDRESS'),
                'name' => env('CBOX_ID_OTP_EMAIL_FROM_NAME'),
            ],
        ],
    ],

    /*
     * Text messages (src/Otp/Sms/) — one-time codes by SMS, for `SmsOtpChannel` and the
     * SMS second factor. SMS costs money per message, which makes every "text me a code"
     * form a target for SMS PUMPING (toll fraud): an attacker drives it at premium-rate
     * ranges and shares the revenue. Every send passes the guard below first.
     *
     * `driver`: `twilio`, `messagebird` (legacy REST API), `bird` (Channels API),
     * `46elks`, `log` (DEV-ONLY: writes the message, code included, to the log — refused
     * when APP_ENV is production) or `array` (tests). A class implementing
     * `Otp\Sms\Contracts\SmsSender` is accepted as a driver name for your own gateway.
     *
     * `allowed_countries`: ISO 3166-1 alpha-2 codes the DEPLOYMENT will text, comma
     * separated in the env. Empty means no deployment-level restriction — then only an
     * environment's own SMS policy narrows it. Set it. Non-geographic ranges (+881, +882,
     * +979, …) are refused regardless: they have no country to allow.
     *
     * `limits`: `cooldown_seconds` between texts to one number; `per_number_per_day` and
     * `per_ip_per_hour` per environment; `per_environment_per_day` so one tenant cannot
     * spend the deployment's budget; `daily_cap` for the whole deployment — the circuit
     * breaker that bounds the worst day's bill. 0 disables a limit. The counters live in
     * the cache store, which must be shared between replicas.
     *
     * `messages`: per-locale overrides of the built-in templates (en, da, de, fr, nb, sv)
     * with `:code`, `:app`, `:minutes`. Keep them GSM-7 and under 160 characters, or each
     * text is billed as two or more.
     */
    'sms' => [
        'driver' => env('CBOX_ID_SMS_DRIVER', 'log'),
        'app_name' => env('CBOX_ID_SMS_APP_NAME', env('APP_NAME', 'Cbox ID')),
        'timeout_seconds' => env('CBOX_ID_SMS_TIMEOUT', 10),

        'allowed_countries' => array_values(array_filter(array_map(
            static fn (string $country): string => strtoupper(trim($country)),
            explode(',', (string) env('CBOX_ID_SMS_ALLOWED_COUNTRIES', '')),
        ))),

        'limits' => [
            'cooldown_seconds' => env('CBOX_ID_SMS_COOLDOWN_SECONDS', 30),
            'per_number_per_day' => env('CBOX_ID_SMS_PER_NUMBER_PER_DAY', 10),
            'per_ip_per_hour' => env('CBOX_ID_SMS_PER_IP_PER_HOUR', 10),
            'per_environment_per_day' => env('CBOX_ID_SMS_PER_ENVIRONMENT_PER_DAY', 1000),
            'daily_cap' => env('CBOX_ID_SMS_DAILY_CAP', 5000),
        ],

        'messages' => [
            // 'en' => ':code is your :app code. Valid for :minutes min.',
        ],

        'drivers' => [
            'twilio' => [
                'account_sid' => env('TWILIO_ACCOUNT_SID'),
                'auth_token' => env('TWILIO_AUTH_TOKEN'),
                // Optional: authenticate with an API key instead of the auth token.
                'api_key' => env('TWILIO_API_KEY'),
                'api_secret' => env('TWILIO_API_SECRET'),
                // One of the two. A Messaging Service is preferred.
                'messaging_service_sid' => env('TWILIO_MESSAGING_SERVICE_SID'),
                'from' => env('TWILIO_FROM'),
                'base_url' => env('TWILIO_BASE_URL'),
            ],
            'messagebird' => [
                'access_key' => env('MESSAGEBIRD_ACCESS_KEY'),
                'originator' => env('MESSAGEBIRD_ORIGINATOR'),
                'base_url' => env('MESSAGEBIRD_BASE_URL'),
            ],
            'bird' => [
                'access_key' => env('BIRD_ACCESS_KEY'),
                'workspace_id' => env('BIRD_WORKSPACE_ID'),
                'channel_id' => env('BIRD_CHANNEL_ID'),
                'base_url' => env('BIRD_BASE_URL'),
            ],
            '46elks' => [
                'username' => env('ELKS_API_USERNAME'),
                'password' => env('ELKS_API_PASSWORD'),
                'from' => env('ELKS_FROM'),
                'dry_run' => env('ELKS_DRY_RUN', false),
                'base_url' => env('ELKS_BASE_URL'),
            ],
        ],
    ],

    /*
     * External actions / inline hooks (src/ExternalActions/) — synchronous extension
     * points where the platform consults registered logic that can ENRICH or VETO an
     * operation (distinct from webhooks, which only notify, async). The hook points:
     *
     *   token_minting         just before an access token is signed (every grant)
     *   post_login            after authentication, before the session is written
     *   pre_registration      before a subject is created (the signup gate)
     *   post_registration     just after, with the new subject id — notify only
     *   pre_password_change   before a credential is written
     *   post_password_change  just after — notify only
     *
     * `hooks` maps a hook point to a deny-by-default list of in-process Action
     * classes. External HTTP endpoints are registered at runtime via the
     * ExternalActions contract (SSRF-guarded, signed, sealed secret).
     *
     * `verify_url` toggles the SSRF guard on registered endpoints; `timeout` /
     * `connect_timeout` bound the synchronous call.
     *
     * FAIL POLICY — what happens when a hook cannot be CONSULTED (timeout, refused,
     * non-2xx). A hook that IS consulted and denies always denies; nothing here
     * changes that. Each point ships a default it can justify: the gates
     * (token_minting, pre_registration, pre_password_change) fail CLOSED, because a
     * security control that fails open is not a control; post_login fails OPEN,
     * because failing closed there means one customer's endpoint outage locks every
     * one of their users out of everything; the notify-only points fail open because
     * they have no decision to fail closed to.
     *
     * `fail_policy.<hook>` ('open' | 'closed') overrides one point. `fail_open`
     * (a bool) overrides ALL of them — leave it unset to keep the per-point defaults;
     * set it false to force every point closed, true to force every point open.
     *
     * `timeout` + `connect_timeout` is the WHOLE pipeline's budget, not each hook's:
     * a fan-out of several endpoints is issued concurrently, so registering a second
     * or third hook no longer adds its own timeout to every token mint. (A host that
     * has substituted a transport without concurrent support keeps the old
     * one-after-another behaviour, and with it the old additive cost.)
     *
     * `cache_ttl` (seconds) caches which endpoints are active per environment and
     * hook point. The token issuer consults the hook on EVERY mint, so without this
     * an environment that has registered no hooks at all still paid a query per
     * token. Registering, pausing, activating or removing an endpoint invalidates the
     * entry immediately, so the TTL is a backstop rather than the mechanism. Set to 0
     * to always read the database.
     */
    'external_actions' => [
        'verify_url' => env('CBOX_ID_ACTIONS_VERIFY_URL', true),
        'timeout' => env('CBOX_ID_ACTIONS_TIMEOUT', 3),
        'connect_timeout' => env('CBOX_ID_ACTIONS_CONNECT_TIMEOUT', 2),
        'cache_ttl' => env('CBOX_ID_ACTIONS_CACHE_TTL', 60),
        // Unset by default (null) so each hook point's own default applies; see above.
        'fail_open' => env('CBOX_ID_ACTIONS_FAIL_OPEN'),
        'fail_policy' => [
            // 'post_login' => 'closed',
        ],
        'hooks' => [
            // 'token_minting' => [ App\Actions\AddTenantTierClaim::class ],
            // 'pre_registration' => [ App\Actions\AllowlistedDomainsOnly::class ],
        ],
    ],

    /*
     * Access governance (src/Governance/) — Identity Governance & Administration.
     * Access-certification campaigns (periodic review of who holds which role /
     * membership, with reviewer certify/revoke decisions applied on close) and
     * Segregation-of-Duties policies (a pre-grant gate + a detector for toxic role
     * combinations). All environment-owned, deny-by-default, and audited.
     *
     * `schedule` runs `cbox-id:governance:close-overdue` every minute to auto-close
     * campaigns past their due date. Turn it off to drive the command by hand.
     */
    'governance' => [
        'schedule' => env('CBOX_ID_GOVERNANCE_SCHEDULE', true),
    ],

    /*
     * Usage metering (src/Kernel/Usage/) — records meaningful events as environment-
     * and organization-scoped per-day counters, the MEASUREMENT layer a usage
     * dashboard renders and future plan gates read. When enabled, domain events are
     * auto-metered off the outbox (exactly-once). Disable to skip all metering — no
     * counter or marker writes are made.
     */
    'usage' => [
        'enabled' => env('CBOX_ID_USAGE_ENABLED', true),
    ],

    /*
     * Data lifecycle (src/Maintenance/) — `cbox-id:prune`, scheduled daily.
     *
     * Every table below accumulates rows that stop being useful once they are past
     * their own expiry (replay guards, expired tokens, dispatched outbox rows) or
     * terminal (delivered/exhausted deliveries). Without a sweep they grow forever;
     * `dpop_proofs` in particular takes one INSERT per DPoP-protected request.
     *
     * `retention_days` is how long a row is kept AFTER it is already dead — not how
     * long a token lives. Set a table to null to keep its rows forever; omit a table
     * to use the default in Cbox\Id\Maintenance\Enums\PrunableTable.
     *
     * `audit_logs` is deliberately absent and is never pruned: it is a hash-chained,
     * checkpoint-anchored trail, and deleting rows would make its own tamper
     * verification report tampering. See Cbox\Id\Maintenance\Pruner.
     */
    'prune' => [
        'schedule' => env('CBOX_ID_PRUNE_SCHEDULE', true),
        'time' => env('CBOX_ID_PRUNE_TIME', '03:10'),
        'chunk' => env('CBOX_ID_PRUNE_CHUNK', 1000),

        'retention_days' => [
            'dpop_proofs' => env('CBOX_ID_PRUNE_DPOP_PROOFS', 1),
            'consumed_assertions' => env('CBOX_ID_PRUNE_CONSUMED_ASSERTIONS', 1),
            'oauth_authorization_codes' => env('CBOX_ID_PRUNE_AUTHORIZATION_CODES', 1),
            'oauth_access_tokens' => env('CBOX_ID_PRUNE_ACCESS_TOKENS', 7),
            'oauth_refresh_tokens' => env('CBOX_ID_PRUNE_REFRESH_TOKENS', 30),
            'events' => env('CBOX_ID_PRUNE_EVENTS', 30),
            'auth_sessions' => env('CBOX_ID_PRUNE_AUTH_SESSIONS', 30),
            'usage_metered_events' => env('CBOX_ID_PRUNE_USAGE_MARKERS', 30),
            'webhook_deliveries' => env('CBOX_ID_PRUNE_WEBHOOK_DELIVERIES', 30),
            'provisioning_operations' => env('CBOX_ID_PRUNE_PROVISIONING_OPERATIONS', 30),
            'oauth_session_participants' => env('CBOX_ID_PRUNE_SESSION_PARTICIPANTS', 30),
            // Self-registered (RFC 7591) clients unused for this many days, with no live
            // refresh token. Null = never (the default) — an MCP deployment with open
            // registration should set it, e.g. 30. Operator-registered clients are never
            // swept.
            'oauth_clients' => env('CBOX_ID_PRUNE_UNUSED_DYNAMIC_CLIENTS'),
        ],
    ],

    /*
     * Fine-grained authorization (src/Kernel/Authorization/) — an environment's own
     * relationship model: a schema of resource types and relations, tuples written
     * against it, and checks evaluated over both (Zanzibar-style).
     *
     * `max_depth` bounds how many relations deep one check may follow (nested groups,
     * folder trees); past it the check is refused, never guessed. `max_expansion` bounds
     * how many objects a list query may visit. `max_batch` caps a tuple batch and a
     * batch check.
     *
     * Answers are cached under the environment's current revision: every write advances
     * it, so the cache is never stale and never flushed. `cache.store` picks a store
     * (null = the default); `cache.ttl` only bounds how long an unused answer occupies it.
     */
    'fga' => [
        'max_depth' => env('CBOX_ID_FGA_MAX_DEPTH', 25),
        'max_expansion' => env('CBOX_ID_FGA_MAX_EXPANSION', 50000),
        'max_batch' => env('CBOX_ID_FGA_MAX_BATCH', 100),
        'cache' => [
            'enabled' => env('CBOX_ID_FGA_CACHE', true),
            'store' => env('CBOX_ID_FGA_CACHE_STORE'),
            'ttl' => env('CBOX_ID_FGA_CACHE_TTL', 3600),
        ],
    ],

    /*
     * AI token vault (src/TokenVault/) — holds downstream third-party credentials
     * (API keys, OAuth tokens for services an AI agent calls) SEALED at rest via
     * the Crypto SecretBox, and brokers short-lived, deny-by-default leased access
     * to agent clients. A lease returns the plaintext to an AUTHORIZED client for
     * immediate use and audits every access — never the value. Access needs an
     * explicit, revocable grant (client_id → secret); no grant means refused.
     *
     * `default_lease_ttl_seconds` is the vault-wide ceiling on how long a leased
     * secret may be held; a per-grant `max_ttl_seconds` can only shorten it.
     */
    'token_vault' => [
        'default_lease_ttl_seconds' => env('CBOX_ID_VAULT_LEASE_TTL', 300),
    ],

    /*
     * Feature flags: per-environment switches evaluated per user and organization, and
     * delivered in the `feature_flags` claim to a client granted the `feature_flags`
     * scope.
     *
     * `cache_ttl` (seconds) caches each environment's compiled flag set, which every
     * evaluation reads instead of the database. Any change to a flag or one of its rules
     * forgets the entry at once, so the TTL is a backstop for a cache the application
     * does not share (a per-pod array or file store), not the mechanism. 0 always reads
     * the database.
     *
     * `max_rules` caps the user and organization rules on one flag. Rules are evaluated
     * in memory from the cached set, so a flag listing every user is a cache entry the
     * size of the user table; target an organization or use a rollout instead.
     */
    'feature_flags' => [
        'cache_ttl' => env('CBOX_ID_FEATURE_FLAGS_CACHE_TTL', 300),
        'max_rules' => env('CBOX_ID_FEATURE_FLAGS_MAX_RULES', 1000),
    ],

    /*
     * Pipes (src/Pipes/) — people connect their own third-party accounts (GitHub,
     * Google, Microsoft 365, Slack, Salesforce, HubSpot, Linear, Notion) over OAuth 2.0
     * authorization code + PKCE, and the environment's authorised apps lease fresh
     * access tokens for them. The tokens are user-owned token-vault secrets.
     *
     * `schedule` registers `cbox-id:pipes:refresh` every five minutes. It refreshes
     * connections whose access token expires within `refresh_ahead_seconds`, at most
     * `refresh_batch` per run. A lease also refreshes on its own when the token expires
     * within `lease_refresh_skew_seconds`, so the sweep is latency, not correctness.
     *
     * A refresh is single-flight: it claims the connection for `refresh_claim_seconds`
     * (a claim held by a process that died lapses after that), and a lease that finds
     * another process refreshing waits up to `refresh_wait_milliseconds` for it.
     *
     * `verify_url` (SSRF guard) pins every call to the provider's resolved addresses
     * and refuses private ranges. The endpoints come from the catalogue, but Microsoft's
     * tenant and Salesforce's domain are an administrator's input. Keep it on.
     */
    'pipes' => [
        'schedule' => env('CBOX_ID_PIPES_SCHEDULE', true),
        'refresh_ahead_seconds' => env('CBOX_ID_PIPES_REFRESH_AHEAD', 600),
        'refresh_batch' => env('CBOX_ID_PIPES_REFRESH_BATCH', 200),
        'lease_refresh_skew_seconds' => env('CBOX_ID_PIPES_LEASE_SKEW', 60),
        'refresh_claim_seconds' => env('CBOX_ID_PIPES_REFRESH_CLAIM', 30),
        'refresh_wait_milliseconds' => env('CBOX_ID_PIPES_REFRESH_WAIT_MS', 5000),
        'http_timeout' => env('CBOX_ID_PIPES_HTTP_TIMEOUT', 10),
        'verify_url' => env('CBOX_ID_PIPES_VERIFY_URL', true),
    ],

    'crypto' => [

        /*
         * Master key for envelope encryption (SecretBox). A base64-encoded,
         * 32-byte key. Generate one with:
         *
         *     php -r "echo base64_encode(random_bytes(32)).PHP_EOL;"
         *
         * Losing this key makes all sealed secrets (including private signing
         * keys) unrecoverable. Back it up separately from the database.
         */
        'key' => env('CBOX_ID_CRYPTO_KEY'),

        /*
         * Previous master keys, kept ONLY to open secrets sealed before a rotation.
         * Comma-separated in the env var, each in the same base64 form as the key
         * above. Nothing is ever sealed under these.
         *
         * To rotate: generate a new key, make it CBOX_ID_CRYPTO_KEY, move the old one
         * here, deploy, then run `php artisan cbox-id:crypto:rewrap`. Remove the old
         * key only once `php artisan cbox-id:doctor` reports nothing left under it.
         */
        'previous_keys' => env('CBOX_ID_CRYPTO_PREVIOUS_KEYS'),

    ],

];
