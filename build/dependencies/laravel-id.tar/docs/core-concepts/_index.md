---
title: Core concepts
description: The architecture, the authorization decision plane, and entitlements
weight: 5
---

# Core concepts

How the platform is put together and the ideas you build against:

- **[Architecture & patterns](architecture.md)** — kernels vs. domain modules,
  contracts-first DI, and dogfooding.
- **[Platform operators](platform-operators.md)** — the identity above every
  environment: who provisions planes and can step into any one of them.
- **[Customers, projects & the platform plane](customers-and-projects.md)** — the
  self-serve hierarchy above environments: one login, many independently-billed IdP
  products, with billing anchored on the project.
- **[Environments & the isolation model](environments.md)** — the hard boundary
  above organizations (staging/prod, white-label).
- **[Authorization & the decision plane](authorization.md)** — live permission and
  entitlement decisions, the hot path, and the token hybrid.
- **[Fine-grained authorization](fine-grained-authorization.md)** — an environment's own
  relationship model: a schema, tuples, and cached checks and list queries with
  consistency tokens.
- **[APIs and scopes](apis-and-scopes.md)** — register the resource servers your
  tokens are for: who owns each scope, which organizations may request it, and how
  every token's audience, scope and roles are decided.
- **[Access token reference](access-tokens.md)** — every claim on an access token and
  when it is present.
- **[Organization access](organization-access.md)** — ordered membership roles,
  groups, resource grants with effective-role resolution, and user API tokens
  capped at the issuer's role.
- **[Membership lifecycle](membership-lifecycle.md)** — joining, leaving,
  transferring ownership and archiving an organization; the single-owner rule and the
  events each step emits.
- **[Customer API keys](customer-api-keys.md)** — keys your app's end-customers mint
  for YOUR API: bound to one app, capped at the holder's current permissions, and
  verified by the app with its own client credentials.
- **[Entitlements & billing](entitlements-and-billing.md)** — capability gates fed by
  your billing engine, never billing state.
- **[Usage metering](usage-metering.md)** — environment- and org-scoped usage counters
  for analytics and future soft gates; local measurement, distinct from billing.
- **[SIEM audit streaming](audit-streaming.md)** — mirror the hash-chained,
  environment-scoped audit trail out to a customer's SIEM, isolation intact.
- **[Inbound SCIM provisioning server](scim.md)** — the SCIM 2.0 endpoint a
  customer's IdP pushes users and groups INTO: directory-scoped bearer auth, the
  full User and Group lifecycle, type-checked filters and RFC 7644 error semantics.
- **[Sign-in provider catalogue](sign-in-provider-catalogue.md)** — the social and
  workforce providers people can sign in with (Google, Microsoft, GitHub, Apple,
  LinkedIn, Bitbucket, Xero, Intuit and more): issuers, endpoints, scopes and how each
  maps to a verified identity.
- **[Outbound SCIM provisioning](outbound-provisioning.md)** — push user and
  membership changes OUT to downstream apps over their SCIM 2.0 endpoints; the
  stateful mirror of the inbound directory.
- **[OTP delivery channels](otp-channels.md)** — delivered one-time passcodes
  (email/SMS) as a verification and MFA factor, and the caps that make a short
  code safe.
- **[Feature flags](feature-flags.md)** — switches per environment, on for named users,
  named organizations or a stable percentage, delivered in the `feature_flags` claim.
- **[AI token vault](token-vault.md)** — seal downstream third-party credentials
  and broker short-lived, deny-by-default leased access to autonomous / AI agents.
- **[Pipes (connected accounts)](pipes.md)** — people connect their own GitHub,
  Google, Slack or Salesforce account; tokens are vaulted, refreshed and leased to the
  apps you authorise.
- **[OAuth clients (apps)](oauth-clients.md)** — registering apps, overlapping secret
  rotation, per-app access-token lifetimes, grants, blueprints, and the lifecycle the
  registry audits for you.
- **[CIBA backchannel approval](ciba.md)** — OpenID Connect Client-Initiated
  Backchannel Authentication: human-in-the-loop approval for agent actions.
- **[Access governance](access-governance.md)** — IGA: access-certification
  campaigns and Segregation-of-Duties policies over roles and memberships.
- **[Staff roles & support access](staff-and-support-access.md)** — roles tenants can
  never grant, environment-wide grants of one app's role, and support sessions that act
  as a customer's user with the RFC 8693 `act` claim.
- **[External actions & inline hooks](external-actions.md)** — synchronous
  extension points that enrich or veto an operation (in-process or external HTTP),
  at token minting, login, registration and password change.
- **[Frontend API & publishable keys](frontend-api.md)** — the browser-facing
  channel: a public key bound to an origin allow-list, so a page can read its own
  sign-in configuration and the signed-in user with no server in the middle.
- **[Migrating users off another system](migrating-users.md)** — bulk import with
  existing hashes, and delegated authentication that imports each person at the
  moment they sign in when those hashes cannot be exported.
