---
title: Upgrading
description: Breaking changes and the migration each one needs, newest first
weight: 3
---

# Upgrading

Breaking changes only, newest first. Everything else is in [`CHANGELOG.md`](CHANGELOG.md).

The entries here are the ones that change behaviour for a deployment that is already
running. Read the whole section for the version you are crossing before you deploy —
several of the changes below fail **silently** (nothing is logged, nothing 500s), some
fire on clients you do not control, and the 0.87.3 entry describes damage that has already
been done by the time you upgrade.

A version with no section below needed no action. Where a run of versions is genuinely
uneventful it is named as such rather than left out, so a gap in the headings is never
ambiguous between "nothing to do" and "nobody wrote it down".

## 1.27.2 — federation browser binding

OIDC and SP-initiated SAML callbacks now require a `__Host-` flow cookie with
`Secure`, `HttpOnly`, `SameSite=None`, `Path=/`, and no Domain attribute. Serve both
legs on the same HTTPS host, including local federation testing. Host overrides
of the SAML ACS must call `SamlBrowserBinding::assertMatches()` before validation
and `forget()` after successful validation, as the package and Cbox ID controllers do.
Keep cookie encryption and queued-cookie response middleware on both legs.

In-progress logins started before this upgrade must be restarted. Old OIDC stash
cookies and session-only state are not accepted. Existing authenticated sessions
are not invalidated. Explicitly enabled IdP-initiated SAML remains unsolicited and
retains its existing login-CSRF tradeoff; leave it disabled unless required.

OIDC flow state now uses the application's cache for a ten-minute lifetime and
atomic single-use claims. All web workers must share a cache store supporting
atomic `add`; process-local array storage is only suitable for tests. Clearing the
cache cancels pending logins. No schema migration is needed.

`/sso/saml/idp/slo` now rejects requests without a SAML message. Local sign-out must
use the host's CSRF-protected logout route. The SAML ACS also refuses non-SAML
connections. Deploy the package and custom callback updates together; update the
host's Composer lock to the fixed package release before deployment.



## 1.26.5 — active subjects and verified local MFA

User-token issuance and authorization-code/refresh redemption now require
`Subjects::isActive()` to return true. Hosts using external identities must bind a
`Subjects` implementation that resolves their real subjects and current status;
unknown IDs are no longer accepted as user-token subjects. Tests must create users.
Client-credentials tokens do not require a user.

`MfaVerification::requiresVerification()` is distinct from
`MfaMandate::requiresEnrolment()`: an enrolled passkey does not prove that a password
login used it. Hosts must challenge weak local sessions before granting account or
OAuth access, and pass the actual authentication methods to
`AuthenticationAwareTokenIssuer`. Cbox ID includes those host-side changes. Federated
logins retain their upstream assurance policy.

Deactivation consumes pending authorization codes and revokes existing grants in one
transaction. The default database subject resolver locks the subject during issuance;
custom resolvers must provide equivalent coordination with their own status changes.
No schema migration is required. Publish the fixed package, update the host's Composer
lock to that release, and deploy both changes together. Old weak local sessions will
need second-factor verification; already issued offline JWTs still follow the resource
server's expiry/revocation policy.

## 1.23.0 — SCIM completeness, Standard Webhooks, step-up, more providers

**Run `php artisan migrate`.** Two additive migrations: `webhook_endpoints.signature_scheme`
(NOT NULL, default `cbox`) and an integer `version` (default 1) on `directory_users` and
`directory_groups`. Existing rows keep their current behaviour.

**No public contract changed.** New capabilities arrive as new contracts
(`WebhookSigningSchemes`, `AuthenticationAwareTokenIssuer`, `DirectoryUserSearch`,
`DirectoryGroupSearch`, `ScimUserResources`, `ScimGroupResources`, `ScimBulkProcessor`,
`OidcTokenExchange`, `OidcUserInfo`) and trailing optional parameters.

**Behaviour you may notice:**

- **SCIM `POST /Users` with an existing `externalId` is now `409 uniqueness`**, where it
  used to update the existing user and answer `201`. Microsoft Entra ID and Okta both
  expect the 409 and then match the user with a filter; a custom client that relied on
  POST being an upsert must `GET ?filter=externalId eq "…"` and `PUT`/`PATCH` instead. A
  duplicate group `displayName` is `409` instead of a `500`.
- A SCIM PATCH that changes a provisioned user's `externalId` is `400 mutability`.
- SCIM filters that were refused (`and` mixed with `or`, `members[...]`, `pr`, date
  comparisons) are now answered.
- **Access tokens carry `acr` and `auth_time`** for authorization-code grants and their
  refreshes (`auth_time` only for CIBA), and introspection returns them. A token-minting
  hook that set either claim itself now has it dropped — both are reserved.
- `POST /oauth/par` refuses a malformed `max_age` with `invalid_request`.
- An OIDC connection saved from a discovery document that rules out `client_secret_post`
  authenticates with HTTP Basic. Connections saved before 1.23 are unchanged.

**If you bind your own** `OidcRelyingParty`, implement `OidcTokenExchange` as well, or
Intuit sign-ins arrive without an email. If you bind your own `TokenIssuer`, implement
`AuthenticationAwareTokenIssuer` to stamp `acr`/`auth_time`; without it your tokens carry
neither and a step-up-guarded resource refuses them.

## 1.22.0 — MCP authorization: protected resources, metadata documents, `mcp` registration

**Run `php artisan migrate`.** One additive migration: a nullable, indexed
`oauth_clients.last_used_at`. Nothing reads it until you enable the new prune target.

**Only if you implement these contracts yourself** (the bundled implementations are
updated):

- `RefreshTokens::rotate()` gains a trailing `?string $resource = null`. Refuse a value
  that differs from the grant's audience with `InvalidAudience::boundToAnotherResource()`,
  before consuming the token.
- If you construct `RegisteredApiAudienceResolver`, `DynamicClientRegistrar`,
  `PushedAuthorizationController` or `ProtectedResourceMetadataController` by hand, they
  take new constructor arguments (see the changelog). Resolved from the container, nothing
  changes.

**Behaviour you may notice:**

- **A repeated `resource` is refused** with `invalid_target` at `/oauth/token` and
  `/oauth/par`. It used to be collapsed to its last value by PHP's parser. Ask for one token
  per resource.
- **A self-registered client may no longer name an arbitrary `resource`.** A client
  registered through RFC 7591 (any mode) is refused (`invalid_target`) a resource that is
  not a registered API, a declared protected resource with `dynamic_clients`, or the issuer.
  If such clients rely on a resource server you run, register it as an API or declare it in
  `oauth.protected_resources`. Operator-registered clients keep the pass-through unless you
  set `oauth.resource_indicators.unknown_resources` to `refuse`.
- **A refresh request naming a different `resource` is refused** (`invalid_target`); the
  refresh token stays valid. Naming the same resource, or none, works as before.
- **The device grant now honours `resource`** at the token endpoint; it was ignored.
- **`open` registration is held to 20 registrations per address per hour.** Set
  `oauth.dynamic_registration.max_per_ip_per_hour` (0 switches the ceiling off).
- UserInfo and the decision endpoint's `WWW-Authenticate` gain `resource_metadata`.
- `AuthorizationCodes::issue()` throws `InvalidGrant` for a malformed `resource`.

Nothing else changes until you opt in: declare `oauth.protected_resources`, set
`oauth.dynamic_registration.mode` to `mcp`, enable
`oauth.client_id_metadata_documents.enabled`, or set `prune.retention_days.oauth_clients`.
See [Protect an MCP server with Cbox ID](docs/cookbook/protect-an-mcp-server.md).
## 1.22.0 — security hardening

**Run `php artisan migrate`.** One additive migration: a nullable, indexed
`organization_id` on `saml_service_providers`. Every existing SP keeps `null` and its
current behaviour.

**Behaviour you will notice:**

- **Login lockout is now on by default.** With no environment or organization policy
  naming a `lockoutThreshold`, 10 failed sign-ins on one subject inside 15 minutes lock
  it for 15 minutes. Tune with `CBOX_ID_LOCKOUT_THRESHOLD`,
  `CBOX_ID_LOCKOUT_WINDOW_MINUTES` and `CBOX_ID_LOCKOUT_DURATION_MINUTES`; set
  `CBOX_ID_LOCKOUT_THRESHOLD=0` to restore the previous "off unless a policy sets it". A
  policy that names a threshold is unaffected. If your test suite drives more than nine
  failed sign-ins at one account, it will now see a lock.
- **Refresh tokens only for clients that may redeem them.** A client whose
  `grant_types` registration does not allow `refresh_token` (directly, or implied by
  `authorization_code`) no longer receives a refresh token for `offline_access` on the
  device-code or CIBA grants. Add `refresh_token` to such a client's grant types if it
  needs one. Authorization-code clients are unaffected.
- **SSO callback JSON changed.** The package's `POST /sso/saml/{connection}/acs` and
  `/sso/oidc/{connection}/callback` now return `sid` (the opaque OIDC session id) instead
  of `session_id` (the `auth_sessions` row key). A host that read `session_id` from these
  responses should call `FederationFlow::completeLogin()` from its own controller and
  keep the returned `Session`, as the reference app does.
- **Ciphertext format.** Secrets sealed from now on are `v1.<key-id>.<payload>`. Every
  secret already stored keeps opening, unchanged. Do not downgrade below 1.22 after new
  secrets have been sealed: earlier releases cannot read the new format.
- **SAML IdP SSO endpoint**: an issuance-time refusal is now answered with a SAML error
  Response to the SP rather than a 500.

**To scope an existing SAML app to its organization**, set
`saml_service_providers.organization_id` (or re-register it with
`NewServiceProvider(organizationId: …)`). From then on only active members of that
organization are asserted to it.

**Optional, recommended:** run `php artisan cbox-id:crypto:rewrap` once to tag every
existing secret with the current key's id; `cbox-id:doctor` reports how many predate key
versioning. To **rotate** the master key, follow
[master key management](docs/security/key-management.md).

**Only if you implement these yourself** (bundled implementations are updated):

- `SamlIdentityProviderService`'s constructor gains `Memberships`, `AuditLog` and
  `EventBus` (container-resolved; only matters if you construct it by hand).
- A host binding its own `Subjects` resolver should also bind a `SubjectPseudonymiser`
  before using `SubjectEraser`; the default only rewrites the package users table.
- A host sealing its own columns with the `SecretBox` should register them with
  `SealedColumns` so a rotation re-seals them.

## 1.21.0 — keys that mint keys, and approvals for one action

**Run `php artisan migrate`.** Two additive migrations: provenance columns on
`environment_api_keys` and `organization_api_keys` (plus `scopes` on organization keys),
and `purpose`, `action_digest` and `consumed_at` on `ciba_requests`. Every existing row
keeps its meaning.

**Only if you implement these contracts yourself** (the bundled implementations are
updated):

- `EnvironmentApiKeys::issue()` gains a trailing `?KeyProvenance $provenance = null`.
- `OrganizationApiKeys::issue()` gains trailing `?array $scopes = null` and
  `?KeyProvenance $provenance = null`.

**Behaviour you may notice:**

- `EnvironmentApiKeys::issue()` now throws `UnknownApiKeyScope` for a scope nothing
  recognises; it used to store it. If your host's endpoints guard scopes beyond
  `EnvironmentApiScope`, rebind `ManagementScopes` to name them.
- A dynamically registered client can no longer obtain `vault.manage`, `vault.lease`,
  `apps.manifest` or `decisions:read`, even if you listed one in
  `oauth.dynamic_registration.allowed_scopes`. Adjust `oauth.reserved_scopes` if you
  deliberately want otherwise.
- A CIBA request whose `binding_message` is longer than 255 characters is refused with
  `invalid_binding_message`.

## 1.20.0 — the audit chain moves into `cboxdk/laravel-audit-chain`

**No action is required, and nothing about the trail changes.** The hash-chained audit log
(`src/Kernel/Audit/`) now runs on the new framework package
[`cboxdk/laravel-audit-chain`](https://github.com/cboxdk/laravel-audit-chain), which
Composer installs as a dependency. The append path, verification and checkpointing are the
same code, moved; laravel-id keeps its tables, its columns, its canonical hash form and its
checkpoint signatures.

- **No migration, no re-chain.** `audit_logs` and `audit_checkpoints` keep every table and
  column name. Existing rows verify exactly as before and new entries extend them with the
  hashes the previous release would have computed; existing checkpoints keep verifying.
  This is pinned by `tests/Feature/Kernel/Audit/GoldenVectors/`, which holds the new code
  to rows (and signed checkpoints) written by the previous implementation.
- **No API change.** `AuditLog`, `DatabaseAuditLog` (including `SYSTEM_SCOPE` and
  `PLATFORM_ENVIRONMENT`), `Checkpointer`, `CheckpointCommand`, the models, value objects,
  enums, exceptions, `FakeAuditLog` and `InteractsWithAudit` keep their names and
  signatures. Additive only:
  - `AuditEntry` and `AuditCheckpoint` now extend the package's `ChainEntry` /
    `ChainCheckpoint` (still Eloquent models over the same tables).
  - `CannotAppendToAuditChain` and `CannotCheckpointEmptyScope` now extend the package's
    `CannotAppendToChain` / `CannotCheckpointEmptyChain`. Both are still
    `RuntimeException`s, with the same messages; they can now also be caught as the
    package's `AuditChainException`.
  - `DatabaseAuditLog`'s constructor gained an optional second parameter
    (`?CheckpointAnchor $anchor`). It is container-built; a host that constructs it by hand
    with only the signer keeps working.
  - `ChainCheckpoint::fromOutcome()`.
- **New commands, nothing scheduled.** The package registers `audit-chain:checkpoint`,
  `audit-chain:verify` and `audit-chain:keygen`. laravel-id points the package's contracts
  at the platform trail, so `audit-chain:verify` verifies every environment's chains
  (platform plane included) and `audit-chain:checkpoint` is equivalent to
  `cbox-id:audit:checkpoint`. Neither package schedule is on by default
  (`audit-chain.checkpoint.schedule`, `audit-chain.verify.schedule`). **Keep using
  `cbox-id.audit.checkpoint.schedule`** for the checkpoint pass, and do not turn on both:
  the pass is idempotent, so a double run is harmless but pointless. The one-way-door
  ordering for the first checkpoint (below, and in docs/operations) is unchanged.
- **Optional: anchor checkpoints externally.** Platform checkpoints now pass through the
  package's `CheckpointAnchor`. The default exports nothing (as before). Setting
  `AUDIT_CHAIN_ANCHOR=filesystem` and `AUDIT_CHAIN_ANCHOR_DISK=<disk>` writes each signed
  checkpoint to that disk (e.g. an R2 or S3 bucket with a retention lock) — see the
  package's `docs/cookbook/anchor-checkpoints-to-r2.md`. An anchor failure rolls the
  checkpoint row back and the pass reports it.
- **Three fixes to the platform trail's checkpoints** (behaviour changes only where the
  old behaviour was wrong):
  - `AuditLog::checkpoint()` with **no environment** in context (the platform plane) used
    to throw a `QueryException` (`signing_keys.environment_id` NOT NULL). It now signs the
    `__platform__` chain as the `__platform__` environment — the same key the checkpoint
    pass uses. The first such call generates that environment's signing key if the pass
    has never run.
  - `AuditLog::verifyChain()` with **no environment** used to report a platform chain that
    the checkpoint pass had signed as `checkpoint signature failed to verify`, although
    nothing was tampered with. It now verifies with the same `__platform__` keys. If you
    have alerting on that reason from the platform plane, it was a false positive.
  - Checkpoint verification now requires the token's `typ` to be
    `cbox-id.audit.checkpoint`. Every checkpoint laravel-id has signed carries it; a
    different token signed by the same environment key is now refused
    (`checkpoint payload does not match its signature`) instead of accepted.
- **The package's own config does not reach the platform trail.** Its models, tables,
  partition column, codec and Ed25519 signing key (`audit-chain.*`) are for a host's own
  use of the package; laravel-id states its tables, codec and JWT signer explicitly.

## 1.19.0

Six feature sets land together: tenancy context (`org_role`, RBAC decisions, the membership
lifecycle, one webhook catalogue), APIs that own their scopes, app secrets and settings,
customer API keys, OIDC Back-Channel Logout, and staff roles with support sessions. Read the
migrations first, then the section for each feature you use.

### Migrations

Ten, all additive; run `php artisan migrate` as part of the deploy. No existing row changes
meaning. In order:

| Migration (`2026_09_24_…`) | What it does |
| --- | --- |
| `000100_create_oauth_apis_and_their_scopes` | `oauth_apis`, `oauth_api_scopes` |
| `000200_create_oauth_client_secrets_table` | `oauth_client_secrets`, backfilled from `oauth_clients.secret_hash` |
| `000300_bind_user_api_tokens_to_an_app` | `user_api_tokens.client_id`, `permissions`; `scope`/`name` nullable, `prefix` 40 chars |
| `000400_add_api_key_prefix_to_clients` | `oauth_clients.api_key_prefix`, unique per environment |
| `000500_add_backchannel_logout_to_oauth_clients` | `oauth_clients.backchannel_logout_uri`, `backchannel_logout_session_required` |
| `000600_bind_codes_and_refresh_tokens_to_a_session` | nullable `session_id` on codes and refresh tokens |
| `000700_create_oauth_session_participants_table` | `oauth_session_participants` |
| `access-control/000800_add_tenant_assignable_to_roles` | `roles.tenant_assignable` (default `true`) |
| `000900_allow_environment_wide_access_reviews` | campaign/item `organization_id` nullable |
| `001000_create_support_sessions_table` | `support_sessions`; `actor_id`, `support_session_id` on codes, `support_session_id` on access tokens |

**Run a queue worker** if you do not already: back-channel logout tokens and webhooks are
delivered by queued jobs.

### Tenancy context and webhooks

**Contracts gained methods.** A host that implements `Memberships`, `Organizations` or
`Invitations` itself (rather than extending the shipped services) must add
`Memberships::leave()`, `transferOwnership()`, `owners()`, `activeRole()`,
`Organizations::update()`, `archiveAsOwner()`, and the optional `?string $revokedBy`
parameter on `Invitations::revoke()`. `JwtTokenIssuer`, `TokenController` and
`OrganizationService` take new constructor dependencies in this release (as do the classes
named in the sections below); a host that constructs them by hand rather than from the
container must pass them.

**Wildcard webhook subscribers receive more events.** Every membership and invitation
change is now announced twice — under the legacy `organization.member_*` /
`organization.invitation_*` name and under the new `membership.*` / `invitation.*` one —
and an archive as both `organization.archived` and `organization.deleted`. An endpoint
subscribed to `*` that counts or mirrors events should key on one family. Endpoints
subscribed by name see no change.

**Subscribers to domain, SSO-connection, token-vault and access-review events start
receiving them.** `domain.*`, `connection.activated`, `vault.grant.*`, `vault.secret.revoked`
and `governance.access.revoked` were catalogued but never emitted; they are now, and
`organization.settings_updated` beside `organization.updated`. A `*` subscriber sees them
for the first time. `ConnectionService`, `DatabaseDomainVerification` and
`DatabaseSecretVault` take an `EventBus` (and `ConnectionService` an `AuditLog`); construct
them from the container.

**Build subscription pickers and key-scope pickers from the new lists.**
`WebhookEventType::offered()` excludes legacy names;
`EnvironmentApiScope::offerable()` excludes the reserved `directories:*` scopes. Rendering
`cases()` keeps offering both.

**Relying parties may now see `org_role`.** It is additive; a consumer that rejects unknown
claims (rare) must allow it.

### APIs and scope ownership

**APIs (resource servers) own their scopes.**

*What breaks:* nothing until you register an API. An environment with no registered APIs
mints the same tokens as before. Once you register one:

- **Tokens that carried its scopes change `aud`.** A token whose scopes belong to one API is
  audienced to it even without `resource` (and to `[identifier, issuer]` with `openid`). A
  resource server that insisted on `aud == issuer` for those scopes must accept its own
  identifier instead — which is what RFC 9068 asks of it anyway.
- **Mixed requests narrow.** Free-text scopes requested alongside an API's scopes are
  dropped from that token; request them separately. Scopes of two APIs with no `resource`
  are refused with `invalid_target`.
- **Clients may be refused on save.** `Client` throws `ScopeNotGrantable` when saved with a
  newly added registered scope its owner may not hold. A console that edits `scopes` on the
  model should catch it and show `$e->getMessage()`. Existing clients that already hold such
  a scope stay editable; the token endpoint drops the scope for them.
- **Roles follow the API.** When the API names a `client_id`, tokens for it carry that app's
  roles/permissions, not the requesting client's.

Before registering an API whose scopes are already in use, check which organization-owned
and dynamically registered clients hold them: those scopes stop being granted to them unless
the API is environment-owned and the scope `tenant_requestable`.

Two smaller changes apply everywhere: refresh tokens record the access token's granted
scopes (only differs if a grant held scopes outside the client's registration), and token
exchange echoes the scopes the new token carries. If you construct `JwtTokenIssuer` or
`DynamicClientRegistrar` by hand rather than from the container, pass the new
`AudienceResolver` / `Apis` argument.

### App secrets and settings

**Client secrets move to their own table, and `oauth_clients.secret_hash` is deprecated.**

The `000200` migration creates `oauth_client_secrets` and moves every existing
`secret_hash` into it with no expiry, so every client keeps authenticating with the secret
it has today. Nothing else is needed for clients to keep working.

`oauth_clients.secret_hash` is **kept for 1.19 and dropped in the next minor**. For 1.19 it
is a mirror of the client's newest live secret. It is never read to authenticate.

*What breaks:* nothing in 1.19, by design. Code that **reads** the column keeps getting the
newest live secret's hash (or null). Code that **writes** it — assigning a hash and saving
the model, the only way to rotate before 1.19 — has the write adopted with the meaning it
had then: the written hash becomes the client's one secret, effective at once, and any
other live secret stops working. A bulk `Client::query()->update(['secret_hash' => …])`
bypasses the model and is **not** adopted.

*What to do before the next minor:*

```php
// Instead of writing secret_hash:
$rotated = app(ClientRegistry::class)->rotateSecret($client, graceSeconds: 3600, actor: $actor);
$rotated->secret; // show once

// Instead of `$client->secret_hash !== null`:
app(ClientRegistry::class)->hasSecret($client);
```

*Rolling back* the migration drops the table. Each client keeps its newest secret (the
mirror); an older secret still inside a rotation grace period stops working.

**Registration refuses settings the token endpoint would refuse later.**
`ClientRegistry::register()` — and so every console and command built on it — now throws
`InvalidClientMetadata` for a grant the token endpoint does not implement, token exchange on
a public client, an `access_token_ttl` below 60 seconds or above
`cbox-id.oauth.max_access_token_ttl`, and a `tokenEndpointAuthMethod` that contradicts the
client type or key set. RFC 7591 registration and RFC 7592 update refuse token exchange on a
public client too.

*What breaks:* a caller that registered such a client and never used the setting. Each one
was unusable — the token endpoint refused the grant on every call, and a TTL of 0 was
silently the deployment default.

**Per-client access-token lifetimes are capped.** A client whose `access_token_ttl` is
above `cbox-id.oauth.max_access_token_ttl` (default 86400, one day) is issued tokens at the
ceiling from the first token after the upgrade. Raise the ceiling if a client needs longer.
The deployment default (`cbox-id.oauth.access_token_ttl`) is not capped.

**`ClientRegistry` gained methods.** If you implement the contract yourself rather than
extending `ClientRegistryService`, add `update()`, `delete()`, `hasSecret()`, `secrets()`,
`rotateSecret()`, `revokeSecret()`, `blueprint()` and `import()`, and the optional
`?AuditActor $actor` parameter on `register()`. Callers are unaffected.

**The registry now writes the app audit trail.** `app.created`, `app.updated`,
`app.secret_rotated`, `app.secret_revoked` and `app.deleted` are recorded by the
framework. A host that recorded its own entries for these will see each twice; drop yours,
and pass an `AuditActor` so the framework's entry names who asked.

**Blueprints carry the logout endpoint and the API-key prefix, and `update()` replaces
them.** `ClientRegistry::update()` takes the app's whole settings as a `ClientBlueprint`, now
including `backchannel_logout_uri`, `backchannel_logout_session_required` and
`api_key_prefix`. Build the blueprint from `blueprint($client)` and change what you mean to;
a hand-built `new ClientBlueprint(...)` clears those three. `import()` refuses a prefix
another app in the target environment already declared.

### Customer API keys

**Customer API keys share `user_api_tokens`.** It gains `client_id` and `permissions`;
`scope` and `name` become nullable, and `prefix` widens to 40 characters. `oauth_clients`
gains `api_key_prefix`. Every existing row keeps its meaning: a token with no `client_id` is
a personal `cbid_pat_` token, exactly as before.

One thing to check if your host reads the table directly: rows with a `client_id` are
customer API keys, and they have no `scope`. `UserApiToken` excludes them with a global
scope, so Eloquent code is unaffected. A raw `DB::table('user_api_tokens')` query, or a
`withoutGlobalScopes()` one, now sees both kinds.

### Back-channel logout

Existing clients have no logout URI and are never called, and grants issued before the
upgrade carry no `sid`.

Logout tokens are delivered by `DeliverBackchannelLogout`; without a queue worker nothing is
sent. On the `sync` connection they are sent inline, once, without retries.

**Pass the session to `AuthorizationCodes::issue()`** — the new `sessionId` argument — or no ID Token carries `sid` and ending one session cannot name it. See the
[recipe](docs/cookbook/receive-back-channel-logout.md).

*What breaks for implementers of the contracts* (the bundled implementations are updated):

- `ClientRegistry` gains `configureBackchannelLogout(Client, ?string, bool, ?AuditActor): Client`.
- `AuthorizationCodes::issue()` gains `?string $sessionId = null` (before the support
  session's `?ActingParty $actor`; pass both by name);
  `RefreshTokens::issue()` gains `?string $sessionId = null`.
- `AuthorizationCodeService` and `RefreshTokenService` now take a `BackchannelLogout` in
  their constructors — resolve them from the container rather than with `new`.
- `EndSessionController` takes a `SignedInSession`.

*Behaviour that changes on its own:*

- `RefreshTokens` gains `withdrawAccess(string $userId, ?string $organizationId = null): int`
  (implementers must add it): revoke the refresh tokens and tell the applications that held
  them to end their sessions. `revokeForUserAndClient()` now notifies the one application.
  `revokeForUser()` does NOT notify anyone — keep calling it on role changes to refresh
  claims; call `withdrawAccess()` where the person's access is actually over.
- Removing an organization membership revokes that organization's refresh tokens for the
  person (the new `organization.member_removed` listener).

### Staff roles and support sessions

*What changes for a running deployment:*

- **`Roles::assignEverywhere()` accepts app-declared roles.** It used to refuse any role with
  a `client_id`. A console that relied on that refusal to keep app roles out of the
  environment-wide picker now has to filter them itself if it still wants to.
- **Directory group mappings refuse staff roles** (`RoleNotTenantAssignable`, an
  `UnknownRole`). Nothing is staff-only until an app or an administrator marks it so.
- **A manifest role whose `tenant_assignable` is not a JSON boolean fails the sync**
  (`InvalidManifest`), including an explicit `null`.
- **Token exchange refuses a subject token carrying `act`** (`invalid_grant`). Nothing
  minted `act` before this release, so only support-session tokens are affected.
- **A permission's `tenant_assignable: true` now counts toward the manifest checksum.** A
  manifest that opts a permission in re-syncs once after the upgrade (harmless). An SDK
  that computes the checksum itself reports a different version for such a manifest until
  it adds the same marker; manifests that opt no permission in are unaffected.

*Contracts that gained methods or parameters* — only matters if you implement them yourself
rather than using the shipped classes:

- `Roles`: `define()` and `updateRole()` take a trailing `tenantAssignable`;
  new `tenantAssignableRoles()`, `assertTenantAssignable()`, `assignAsTenant()`,
  `assignmentsEverywhere()`.
- `AccessReviews`: `open()`, `certify()`, `revoke()` and `close()` take `?string` for the
  organization (null = the environment's review).
- `AuthorizationCodes::issue()` takes a trailing `?ActingParty $actor` (after
  `sessionId`); `AuthorizedGrant` and `IdTokenGrant` carry an optional actor.
- `TokenIssuer`: new `issueActing()`.
- New contracts `StaffAccess` and `SupportSessions`, bound by default.

A tenant-facing console should switch its role picker to `Roles::tenantAssignableRoles()`
and its grant action to `Roles::assignAsTenant()`. Until it does, it keeps offering and
granting staff roles once any exist.

## 1.9.0

**Manual permissions can now have an owning organization, and existing rows keep their old
meaning.**

`permissions` gains a nullable `organization_id`. Null means what every row means today:
shared with every organization in the environment. A value means one tenant owns the row —
only they see it, compose it into roles, edit it, or delete it.

This exists because the catalog had no tenant tier at all. A console that offers permission
authoring to an organization administrator — which ours does, because roles are made of
permissions and offering one while hiding the other is not a usable console — wrote every
row into the environment-wide tier. One tenant could rename a key a peer's roles were built
from, and deleting one cascades the `role_permission` rows for **every** role in the
environment.

*What breaks:* nothing on its own. The migration is additive and **does not backfill** —
every existing row stays shared, because each was authored when shared was the only
available outcome and roles across the environment may already bind it. Stamping a guessed
owner would silently revoke permissions from live roles.

*What to do* if you render your own permission console: the fence is not a global scope,
because it cannot be — nothing populates `TenantContext` on a console plane, and a
deny-by-default scope reading an empty context would hide the shared tier from everybody.
Apply it explicitly, and note that the two predicates are deliberately not the same one:

```php
// What a tenant may SEE — their own rows plus the environment's shared tier.
Permission::query()->visibleToOrganization($organizationId)->get();

// What a tenant may WRITE — their own rows and nothing else. Resolve every edit and
// delete target through this, never through the visibility predicate.
Permission::query()->ownedByOrganization($organizationId)->whereKey($id)->first();
```

Passing `null` to either is the environment plane asking for the shared tier: `visible`
returns the shared rows only, and `owned` matches the shared rows only — so an
environment-plane form cannot resolve a tenant's private key either.

## 1.8.0

**Three behaviour changes that are silent by design. Read all three before deploying.**

**Global sign-out now needs a verified `id_token_hint`.** `/oauth/logout` is
unauthenticated — a relying party reaches it by redirecting the browser — and it answers
GET. It previously revoked every session the browser's owner held, which made "revoke all
of this person's sessions" something any page on the internet could cause by sending them
through a link: no credential, nothing minted, a denial of service against every user of a
deployment. The teardown now fires only when a hint this server verified names the person
actually holding the browser.

*What breaks:* an integration that sends the browser to `/oauth/logout` with no
`id_token_hint` still signs that browser out — and no longer ends the person's sessions on
their other devices. Nothing errors. If you rely on RP-initiated logout as global
sign-out, send `id_token_hint` (the `id_token` you were issued for that user). Every Cbox
ID SDK accepts one; in most it is an optional trailing argument you are probably not
passing.

**An ID Token is issued only when `openid` was granted.** Every user-present grant used to
return one regardless of scope, so a client that asked for `api.read` and nothing else got
back a signed assertion carrying `sub` and `org`. UserInfo has always refused that same
client, so the endpoint contradicted itself about who is entitled to an identity claim.

*What breaks:* a client that reads the `id_token` without having requested `openid` now
finds it absent. Add `openid` to the scopes it requests. Watch for integrations that
authorize with a per-call scope override — the override is what decides, not your
configured default.

**PKCE is refused at issue time unless it is well-formed S256.** `plain` was accepted and
then unredeemable, because redemption always computed S256 — failing closed at the wrong
moment, so the host got a working code and the user got a broken sign-in with nothing
saying which end was wrong. `code_challenge_method` must now be `S256`, the challenge must
be a 43-character base64url digest, and the verifier 43–128 characters of
`[A-Za-z0-9-._~]` (RFC 7636 §4.1).

*What breaks:* a host generating a verifier shorter than 43 characters, or passing a
placeholder challenge, now fails at `/authorize` with `invalid_request` instead of at
redemption. That is the intended direction, but it moves when you find out.

## 0.87.3

**Two security fixes. Cross this version.**

**A deactivated subject authenticated with ANY password.**
`DatabaseAccountMembers::verifyPassword()` refused a deactivated subject with
`! $this->hasher->check($password, $this->dummyHash())`. The dummy verify exists to burn
time and have its result thrown away; the negation made it the answer, and since a dummy
hash matches nothing, `check()` returned false and `!false` authenticated. "Deactivated
subject holding an active membership" is not exotic — it is an unaccepted invitation, and
it is a removed member. The caller mints a session on that answer and clears the failure
counters, so the session goes live the moment the subject is reactivated.

- **Who is affected:** every deployment that has ever had an unaccepted invitation or a
  removed account member. No configuration avoids it.
- **What to look for afterwards:** sign-ins by members you removed, and by invitees who
  never accepted. The failure counters were cleared on those attempts, so a lockout that
  should have fired did not.

**SCIM: `PATCH` on a group with a bare `members[…]` value filter detached every member.**
`members[value eq "x"].display` was refused; `members[value eq "x"]` was not — it contains
no `].` and does not begin with `members.`, so it cleared both guards, reached
`sync(valueIds(…))` with a non-list value, and emptied the group. It returned 200,
membership-changed fired, **every role mapped from that group was revoked for every
member**, and the connector recorded a success, so it never retried or re-synced. Silent
on both sides.

- **Who is affected:** any deployment with inbound SCIM group provisioning.
- **What to do:** after upgrading, force a full re-sync from your identity provider and
  reconcile group-derived role grants. The revocations are real and nothing replays them.
- `add` and `replace` now refuse any filtered `members` path; `remove` with that exact
  path still works, because that is how an IdP detaches one member.

## 0.87.1

**Adds a migration that gives every existing operator a subject.** No action, but do not
skip it on the way to 0.87.x — see the entry below for why an operator without one is
locked out of the platform they run.

## 0.87.0

**A platform operator is a subject now, not a second credential store.**
`platform_operators` held an email and a hash and nothing else, so none of what protects a
sign-in here — password policy, breached-password refusal, lockout, TOTP, passkeys,
step-up, session revocation — applied to the identity with the widest reach in the
product. `platform_operators.subject_id` points at an ordinary subject in the platform
root, and `verifyPassword()` asks that subject.

Adds **two migrations**: one for the nullable `subject_id`, and one (in 0.87.1) that
attaches a subject to every operator that lacks one, reusing the subject an operator who
is also an account member already has. The hash moves across untouched — both tables hash
with the configured driver and both models pass an already-hashed value through — so
existing passwords keep working. The address is deliberately **not** marked verified: the
operator table never asked, and claiming otherwise would hand a confirmed address to
step-up gates that rely on it meaning something.

- **If you are retiring a separate operator sign-in form**, apply 0.87.1's migration in the
  same deploy. 0.87.0 alone attaches the subject lazily, on the operator's next successful
  sign-in through the door that verifies the local hash — and if you have just deleted that
  door, there is no such moment. Every pre-existing operator would then have no subject, no
  account to sign in as, and no door that consults their hash: locked out of the platform
  they run, by an upgrade that reports success.
- **Do not drop the hash column yet.** It is the credential for any operator that still has
  no subject.
- **`PlatformOperators::findBySubject()`** is the new lookup: it answers "is this session
  staff" from the session a host already has, so staff pages can be a permission on the one
  session rather than a second sign-in. It excludes suspended operators itself.
- **A deactivated subject now refuses the operator at the credential**, rather than at the
  next session boundary.

## 0.85.0

**`RefreshTokens::issue()` takes two more arguments.** `auth_time` and `amr` are recorded
on the refresh token so a refreshed ID Token can describe the ORIGINAL authentication, as
OIDC Core §12.2 requires. Without it a session's asserted assurance level falls at its
first refresh, which reads to a relying party gating on `acr` as the user losing their
second factor.

**If your host implements the `RefreshTokens` contract itself, widen the signature** —
both are trailing and optional, so a host using the shipped implementation does nothing.

Adds one migration (nullable `auth_time` and `amr` on `oauth_refresh_tokens`). Families
issued before this keep working and carry no authentication context; the claims are
optional, and a missing one is honest where a fabricated one is not.

The refresh grant also returns a renewed `id_token` now. That is invisible to a relying
party that authenticates the access token, and the difference between working and not for
one that authenticates the ID Token.

## 0.83.1

**Requires `cboxdk/laravel-ssrf` ^1.1.1** — the floor is the fixed version rather than
`^1.1`, because an existing lock file resolving 1.1.0 gets a guard whose DNS pinning
silently discards addresses. Below 1.1.1 only the LAST of a host's validated addresses was
pinned (curl treats a repeated `CURLOPT_RESOLVE` entry for the same `host:port` as a
replacement, not an addition), so a dual-stack target whose AAAA sorted last —
`accounts.google.com` is one — was reached over IPv6 alone and failed outright on a host
with no IPv6 route.

Every outbound path in this package goes through that guard: OIDC discovery, token
exchange, JWKS retrieval, SAML metadata import, SCIM, webhooks, external actions. Whether
it *failed* depended on the host's own IPv6 connectivity, so it presented as "works on my
machine". **Run `composer update cboxdk/laravel-ssrf`** and confirm the resolved version.

## 0.83.0

**`Connections::create()` refuses a catalogue key the catalogue does not have**, rather
than storing a connection that renders a sign-in button nobody can complete. And
**`oauth2Config()` refuses a config naming an OIDC provider** — driving one down the
OAuth 2.0 path would mean no `id_token` was ever verified.

Adds one migration: a nullable `provider` column on connections. Existing rows become
NULL, which is what they are — a hand-configured enterprise connection has no catalogue
entry. The column is what keeps "the organization's enterprise SSO connection" and "a
consumer provider this tenant enabled" apart; without it the first active row won
whichever it happened to be, so enabling Google could silently become an organization's
SSO.

## 0.81.0, 0.82.0, 0.82.1, 0.84.0, 0.86.0 — no action

Additive or corrective, with nothing to do on an upgrade. Worth knowing about:

- **0.82.1** — a client's configured token lifetime now reaches the `id_token`, which was
  hardcoded at 900s. If you registered a client with a short TTL expecting it to bind the
  credential Kubernetes actually presents, it does now. The default is unchanged.
- **0.86.0** — `ProviderTemplate` gains one trailing optional constructor argument;
  `DirectoryProvider` is unchanged and existing `directories.provider` rows are untouched.
- **0.84.0** — `cbox-id:doctor` will run a host's own `HealthCheck` implementations if you
  register any. It runs nothing new until you do.

## 0.80.0

**The RFC 8707 `resource` a client asks for at `/authorize` is now binding.**
`AuthorizationCodes::issue()` takes an optional eleventh argument — the resource indicator
the authorization was granted for — and the token endpoint refuses a redemption that names
a different one with `invalid_target`.

- **If your host serves its own `/authorize`**, pass the captured `resource` through to
  `issue()`. Until you do, codes carry no resource and behave exactly as before: the
  client's request at redemption is honoured, which is the old (unbound) behaviour.
- **If a client legitimately needs several audiences**, it must obtain a code per resource.
  RFC 8707 §2 is explicit that the authorization and the token request describe the same
  target.

Adds one migration (`oauth_authorization_codes.resource`, nullable).

## 0.79.0

**Persistent and transient SAML NameIDs change value.** Until now the format was never
consulted: a service provider registered with `nameid-format:persistent` received
whatever `name_id_attribute` pointed at, which defaults to `email`. It now receives a
128-bit opaque identifier, per service provider, and a transient one gets a fresh value
per assertion.

At the service provider, that is **a different subject**. An SP that auto-provisions will
create a second account for the same person; one that does not will refuse the sign-in.

- **Who is affected:** only service providers deliberately registered as `persistent` or
  `transient`. The column default is `emailAddress`, so a registration that was never
  changed is unaffected.
- **What to do:** decide per SP. Either tell the SP to re-link its accounts (the usual
  answer — the new identifier is what the spec always meant by "persistent"), or set that
  SP's `name_id_format` back to `emailAddress`, which restores the old value exactly.
- **Reverting after the fact:** the identifiers are rows in `saml_idp_name_ids`, keyed
  `(environment_id, sp_entity_id, subject_id)`. Deleting a row reissues that one person's
  pseudonym at that one SP; nothing else is touched.

Adds one migration.

## 0.78.0

**The SAML HTTP-POST binding now carries its own Content-Security-Policy, and your host
has to let it.** A self-submitting cross-origin form is exactly what `form-action` and
the inline-script ban exist to refuse, so a host with a hardened policy was breaking its
own federation — the assertion was built, signed, and never delivered, with no
PHP-level symptom.

`SamlResponse::toPostBinding()` returns the payload together with a policy naming only
the registered ACS. **If your application sets a Content-Security-Policy in middleware,
it must not overwrite one the response already set** — otherwise this release changes
nothing for you and the blank-page failure continues.

The one-line shape, in whatever middleware stamps your headers:

```php
if ($name === 'Content-Security-Policy' && $response->headers->has($name)) {
    continue;
}
```

Defer only the CSP. Leaving the rest unconditional means a response cannot quietly drop
`frame-ancestors` or `nosniff` by setting one header.

`toPostForm()` is unchanged and still returns the same HTML, so a host with no policy at
all needs to do nothing.

## 0.77.0

### `saml_idp_sessions` (migration), and SLO stops working for pre-existing sessions

Additive table recording each issued assertion. Run migrations as usual.

**Behaviour change worth planning for:** Single Logout now resolves a NameID through the
service provider that presented it, and the record only exists for assertions issued from
0.77.0 onward. So an SP logging out a user who signed in BEFORE the upgrade finds no
record and the logout is a silent no-op — the user stays signed in at the IdP until their
session expires normally.

That window closes on its own as people sign in again. It is the safe direction of the
trade: before this, the same endpoint let any registered SP end any user's session by
naming their email address.

Records are kept 30 days.

## 0.73.0

### `Subjects` gained `update()`

Only affects a host that implements `Cbox\Id\Identity\Contracts\Subjects` itself —
a fatal error at boot, which is the failure mode you want.

Implement it as "apply the given name and/or email, leave a null alone, audit the change
and emit `user.updated`". A changed email MUST clear `email_verified_at`: an administrator
asserting an address is not its owner proving one.

**Worth doing anyway:** if your console changes a profile by writing to the model
directly, switch it to this. That path writes no audit entry for the account's primary
identifier and its recovery channel, and emits nothing — so outbound SCIM never learns
about it.

## 0.68.0

### `AuthPolicies` gained `overridesFor()`

Only affects a host that implements `Cbox\Id\Identity\Contracts\AuthPolicies` itself.
Adding a method to an interface is a fatal error at boot for any class implementing it,
which is the failure mode you want.

Implement it as "return the overrides for these organization ids, keyed by id, omitting
the ones with no override". The shipped `DatabaseAuthPolicies` is the reference. A
correct-but-slow implementation is three lines:

```php
public function overridesFor(array $organizationIds): array
{
    return array_filter(array_combine(
        $organizationIds,
        array_map(fn (string $id): ?AuthPolicy => $this->overrideFor($id), $organizationIds),
    ));
}
```

That works, but it is the shape the method exists to replace — it is called once per
authenticated request, so a single `whereIn` is worth writing.

Hosts using the shipped binding need to do nothing.

## 0.67.0

### `memberships` gains an index (migration)

Additive: `(user_id, created_at, id)`. No behaviour change, no backfill. On a large
`memberships` table the index build takes a lock proportional to its size — on Postgres,
consider `CREATE INDEX CONCURRENTLY` by hand and marking the migration as run, if that
table is big enough for the lock to matter.

## 0.66.0

### `Mfa` gained a `disable()` method

Only affects a host that implements `Cbox\Id\Identity\Contracts\Mfa` itself. Adding a
method to an interface is a fatal error for any class implementing it, so this one breaks
at boot rather than silently — which is the failure mode you want.

Implement it as "remove every factor and every recovery code for this user, and record
it". The shipped `MfaService` is the reference. If your implementation delegates to the
package's, forward the call.

Hosts using the shipped binding need to do nothing.

**Worth doing anyway:** if your console resets a user's MFA by deleting `MfaFactor` and
`MfaRecoveryCode` rows directly — which was the only way to do it before this release —
switch it to `Mfa::disable()`. The direct-delete path writes no audit entry, so the most
privileged MFA action in your deployment is currently the only one leaving no trace.

### `setCapture()` now refuses an unverified domain

`DomainVerification::setCapture($id, true)` throws
`Cbox\Id\Federation\Exceptions\DomainNotVerified` when the domain's DNS challenge has
not been answered. Previously it succeeded, and whether that was allowed depended on
which caller you went through.

Catch it wherever you expose domain settings and show the challenge record rather than a
generic failure. Disabling capture is unchanged and still always permitted.

Check for rows already in that state before deploying — capture on an unverified domain
means someone else's email domain may currently be routing to one of your organizations:

```sql
SELECT id, organization_id, domain FROM verified_domains
WHERE capture = 1 AND verified_at IS NULL;
```

Existing rows keep working; this release stops NEW ones being created, and does not
retroactively switch capture off — that call is yours, since it changes where those users
land at sign-in.

### The SAML replay ledger is re-keyed (migration)

`consumed_assertions` drops `unique(assertion_id)` and gains `environment_id` +
`connection_id`, keyed together. Run migrations as usual.

No backfill and no downtime concern: every row in this table expires inside the
assertion's own validity window, ten minutes at the outside, so by the time a deploy
finishes they are all dead. Existing rows keep an empty `connection_id`, which pairs
with their already-unique assertion id.

If you query this table directly — an unusual thing to do — note that `assertion_id`
alone is no longer unique, and deliberately so: it is chosen by the issuing identity
provider and only unique within it.

## 0.65.0

### `EntitlementSource::License` is removed

Only affects a deployment that ran `cboxdk/laravel-id-licensing` **with a real key** —
without one the plugin was inert and wrote nothing, and the framework itself never
wrote this source at all.

Check before upgrading:

```sql
SELECT count(*) FROM entitlements WHERE source = 'license';
```

Any rows must be moved to a source that still exists, or reading them throws when the
enum can no longer resolve the value:

```sql
UPDATE entitlements SET source = 'manual' WHERE source = 'license';
```

`manual` is the honest replacement: the grant now stands on its own rather than on a
licence, which is exactly what retiring the licensing layer means.

### `Accounts::suspend()` and `Accounts::reactivate()` take an actor

**This is a signature change and it will not compile until you fix your call sites.**

```php
- $accounts->suspend($accountId);
- $accounts->reactivate($accountId);
+ $accounts->suspend($accountId, $operatorId);
+ $accounts->reactivate($accountId, $operatorId);
```

**Why.** Suspending an account is the widest access revocation the platform has — every
member, every API key, every environment the account owns, at once. It was the only
such verb in the package that took no actor and wrote no audit entry, while
`Organizations::suspend()` and `PlatformOperators::suspend()` both audit internally.
That asymmetry pushed the audit write out to the call site, where the second caller
silently forgets it. Both verbs now record `account.suspended` / `account.reactivated`
on the system chain themselves.

**Also**: both are now genuinely idempotent. Suspending an already-suspended account,
or an id that does not exist, writes nothing and audits nothing — previously the blind
`update()` was a no-op but there was no entry either way. If you were relying on
re-suspension to produce a fresh audit entry, you were not: there was none.

### `Organizations::archive()` — new, and the way `Deleted` should be reached

`OrganizationStatus::Deleted` had no verb behind it, so hosts wrote the status onto the
model and called `save()`. That skips the domain event and, worse, leaves no audit
entry for the most destructive state an organization can enter.

```php
- $organization->status = OrganizationStatus::Deleted;
- $organization->save();
+ app(Organizations::class)->archive($organization->id, $operatorId);
```

Emits `organization.archived`, audits it against the actor, and is idempotent. Not
breaking unless you implement the `Organizations` contract yourself — in which case
you need the new method.

### `OrganizationStatus::revokesAccess()` — use it instead of comparing cases

**If your gate tests `status !== OrganizationStatus::Suspended`, or matches on
`Suspended` alone, you have a live authentication bypass.** A `Deleted` organization
went on authenticating its members, consenting on their behalf and minting tokens,
because nothing in the package answered whether a status revokes access and every
consumer re-derived it.

```php
- if ($organization->status === OrganizationStatus::Suspended) { deny(); }
+ if ($organization->status->revokesAccess()) { deny(); }
```

The method is an exhaustive `match` with **no `default`**, deliberately: a status added
in a later release fails static analysis at your call site instead of silently
inheriting "access allowed", which is exactly how `Deleted` slipped through.

### Do this BEFORE you deploy

**Run `php artisan migrate`.** One new migration,
`2026_07_26_000100_convert_char_columns_to_varchar`, re-types 225 identifier columns
from `char` to `varchar`. On PostgreSQL and MySQL/MariaDB it **rewrites 81 tables**
under an exclusive lock, one `ALTER TABLE` each. On SQLite it does nothing. Sizing,
locking and rollout order are below — read them before you run it on a large
database.

There is no code change to coordinate with it: old code and new code both work
against either schema, in both directions.

**If you published the migrations** (`--tag=cbox-id-migrations`), also re-publish them
with `--force`. A published copy keeps the package's filename, so it *overrides* the
package's version — your copies still say `$table->ulid()`, and a database built fresh
from them would come back padded. The new `ALTER` is not in your published set, so it
loads from the package and fixes your existing database either way; re-publishing is
what stops the next fresh install regressing.

**Decide, deliberately, whether to enable audit checkpointing.** It ships **off**, and
turning it on is a **one-way door**. Read the next section before you touch the flag.

---

### Audit checkpointing exists now — and the order you enable it in is permanent

**What was broken.** `AuditLog::checkpoint()` had three callers: two pass-through
decorators and a test. **Nothing scheduled it**, so `audit_checkpoints` was empty on
every deployment, `verifyCheckpointAnchor()` returned `null` on every call, and the
tail-deletion detection the whole design rests on never ran. The chain detects
modification and sequence gaps by itself; it cannot detect **truncation** — delete the
newest N entries and what is left is a shorter, perfectly valid chain. A signed
checkpoint is the only thing that catches that, and there were none.

**What is new.** `php artisan cbox-id:audit:checkpoint` signs a checkpoint over every
`(environment, scope)` chain that has advanced since its last one — idempotent, safe to
run beside live appends, `--dry-run` to see what it would do. It can be scheduled daily
with `cbox-id.audit.checkpoint.schedule`.

**That flag defaults to `false`, and that is not an oversight.**

A checkpoint is a signature over the chain's hashes **as they are today**, meant to be
exported and anchored somewhere append-only. The GDPR-erasure design still to come needs
exactly one **re-chain** of the existing rows: encrypt `ip` and `context` and hash the
**ciphertext** instead of the plaintext, so that destroying a per-subject key leaves
every hashed byte unchanged and `verifyChain()` still passes bit-for-bit. Every
checkpoint signed *before* that re-chain would afterwards report tampering that never
happened — permanently, and on evidence you may already have handed to a third party.

Because nothing has ever signed one, that window is still open. **The first checkpoint
closes it.**

So enable it in this order, and only this order, if a re-chain is in your future:

1. **Sign and retain, out of band**, each chain's current head hash and row count —
   `cbox-id:audit:checkpoint --dry-run` prints the head sequence per chain, and
   `select environment_id, scope, count(*), max(sequence) from audit_logs group by 1, 2`
   gives the counts. Keep that attestation somewhere this package cannot rewrite. It is
   what covers the gap while no checkpoint exists.
2. **Introduce `chain_version` and ciphertext hashing** (not in this release).
3. **Run the one-time re-chain** (not in this release).
4. **Then** set `CBOX_ID_AUDIT_CHECKPOINT_SCHEDULE=true`.

**If no such migration is in your future — turn it on now.** A deployment that will
never re-chain gains nothing by waiting and is, until it does, running an audit trail
whose truncation nobody would notice. That is the trade this default makes: it protects
a migration that has not happened yet, at the cost of a control that is not yet on.

```dotenv
CBOX_ID_AUDIT_CHECKPOINT_SCHEDULE=true
CBOX_ID_AUDIT_CHECKPOINT_TIME=02:40
```

---

### The audit chain's first entry no longer deadlocks on MariaDB

No action, and no migration — but if you run **MariaDB** and have seen
`SQLSTATE[40001] … 1213 Deadlock` come out of an audit append, this is it.

Appending serialises on the chain's **anchor** (sequence 1). On an *empty* chain there
is no anchor yet, and the locking read that looked for it matched no row — which InnoDB
answers with a **gap lock**. Eight processes opening one brand-new chain each held that
gap lock and each then needed an insert-intention lock inside it; MariaDB 11.8 resolved
the pile-up as a deadlock rather than the duplicate key the append is written to absorb,
and `DB::transaction(…, attempts: 3)` ran out of attempts. Measured at **6 of 800**
appends lost on MariaDB 11.8.8, 800/800 on MySQL 8.4 and PostgreSQL 16.

The anchor is now *found* with a plain read and *locked* by **primary key** — an exact
primary-key match takes a record lock and can never take a gap lock — and the search
runs **outside** the transaction, because under `REPEATABLE READ` a search inside it
would fix the snapshot the head read is then answered from. Serialisation failures also
retry on the append's own ladder now, with a jittered backoff. Same test, same engine:
**800/800**, six runs.

Failures were loud, not silent, so nothing was lost quietly and there is nothing to
repair.

---

### Identifier columns are `varchar(26)`, not `char(26)`

**What was broken.** `$table->ulid($column)` is `$table->char($column, 26)`, and
PostgreSQL implements `CHAR` as the SQL-standard `bpchar` — *blank-padded* character.
A value shorter than the declared width is physically stored padded out to it, and
PDO hands those bytes to PHP verbatim:

```
INSERT 'env_test' INTO char(26)
  octet_length(id) = 26      -- padded on disk
  length(id)       = 8       -- Postgres' own length() strips trailing blanks
  id = 'env_test'            -- true; the = operator strips them too

read back through PDO:
  strlen($v)          = 26
  $v === 'env_test'   = FALSE
```

Every check at the SQL level passes, which is why this survived sixty-one releases:
it is invisible from a SQL client. PHP is where it breaks, and it breaks every strict
comparison. Two that matter:

- `BelongsToEnvironment` compares a row's `environment_id` against the active
  environment key and throws `CrossEnvironmentAccess` **on the row's own
  environment** — `row belongs to [env_test⎵⎵⎵…], acting as [env_test]`.
- `DatabaseAuditLog::canonicalPayload()` puts `organization_id` inside the chain hash.
  It hashes the unpadded value at write and the padded one at read, so `verifyChain()`
  reports `content hash mismatch (tampered)` on a chain nobody has touched.

**338 of 1358 tests failed this way on postgres:16.** MySQL and MariaDB pad on disk
too but strip on retrieval, and SQLite has no fixed-width type at all, so neither
engine ever showed it — and the suite ran on SQLite.

**Does it affect you?** Only if an id in your database is shorter than its column.
Real ULIDs are exactly 26 characters, so a deployment whose ids were all generated by
this package is *unaffected in practice* — nothing pads. It bites the moment one
short id gets in: a seeded fixture, an imported tenant, a synthetic id from an
integration, or a hand-written `environment_id`. Check for one before you decide this
is theoretical:

```sql
-- PostgreSQL. Any row returned is a live instance of the bug.
SELECT count(*) FROM environments WHERE octet_length(id) <> length(id);
SELECT count(*) FROM audit_logs   WHERE octet_length(organization_id) <> length(organization_id);
```

**What changed.** The create migrations now say `$table->string($column, 26)`, which
fixes a database created from here on. The new migration is what fixes one that
already exists — casting `bpchar` to `varchar` strips the trailing blanks, so padded
values already on disk come back clean without a backfill.

**What it costs to run.**

| | |
|---|---|
| Statements | 81 — one `ALTER TABLE` per table, every column of that table in it, so each table is rewritten once rather than once per column. Plus 10 drops and 10 re-creates on MySQL/MariaDB, for the foreign keys |
| Lock (PostgreSQL) | `ACCESS EXCLUSIVE` on the table being altered; `SHARE ROW EXCLUSIVE` on any table holding a foreign key into it |
| Lock (MySQL/MariaDB) | Exclusive metadata lock per `ALTER`; InnoDB copies the table |
| Table rewrite | **Yes**, on all three server engines — `char` and `varchar` have different physical representations, so this is not a catalog-only change |
| Indexes and unique constraints | Rebuilt in place under their **existing names** |
| Foreign keys (PostgreSQL) | Kept in place; Postgres re-validates them across the type change |
| Foreign keys (MySQL/MariaDB) | **Dropped and recreated** — see below |
| SQLite | Skipped entirely — its declared types carry affinity, not width |
| Re-runnable | Yes. The current type is read from the live schema, so an already-`varchar` column is skipped and the width is taken from the column rather than assumed |
| Verified | Upgraded v0.61.0 database vs fresh install, schema dumps diffed on **PostgreSQL 16, MySQL 8 and MariaDB 11**: zero lines of difference on all three, all 10 foreign keys present |

**The 10 foreign keys on MySQL and MariaDB are dropped and put back.** InnoDB refuses
to re-type a column a foreign key sits on when that would leave the two sides
mismatched (`error 1832`), and they always are mismatched for a moment: the two sides
live in different tables, so they cannot be altered in one statement. PostgreSQL has
no such objection and keeps its constraints in place throughout.

So on MySQL/MariaDB there is a window — the length of the whole conversion — in which
the account-plane foreign keys are **not enforcing**. The constraints are read back
from the live schema and restored with the same names, columns and referential
actions, so the end state is identical either way; but if you are running MySQL under
write traffic, that window is the reason to take a maintenance window rather than
rely on the constraints during the deploy.

If a conversion fails while the keys are down, the migration puts back every one that
will go back before it rethrows. A **hard kill** in that window — SIGKILL, a lost
node — leaves them dropped, and re-running will not bring them back, because nothing
outside the running process recorded what they were. Check for that before you assume
the deploy was clean, and recreate any that are missing from your schema:

```sql
-- MySQL/MariaDB. Expect 10 on a stock install.
SELECT COUNT(*) FROM information_schema.REFERENTIAL_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = DATABASE();
```

None of this applies on PostgreSQL, where the constraints are never dropped.

**Sizing it.** The cost is a full rewrite of every listed table, so it scales with
your row count — `audit_logs` first, since it is the highest-row-count table in the
system. On a **near-empty** database the whole migration measured 6–16s on PostgreSQL
16 and 22–84s on MySQL 8 and MariaDB 11 (the spread is host load, not data — these
were containers on a laptop; a real server is faster). That is the fixed overhead of
81 table rewrites with nothing in them, so treat it as the floor and add your own
data. Get a number before you schedule it:

```sql
SELECT relname, n_live_tup, pg_size_pretty(pg_total_relation_size(relid))
FROM pg_stat_user_tables ORDER BY n_live_tup DESC LIMIT 10;
```

**Do you need a maintenance window?** If those tables are small — tens of thousands
of rows — this is seconds and a normal deploy absorbs it. If `audit_logs` is large,
take a window: `ACCESS EXCLUSIVE` blocks reads *and* writes on that table for the
whole rewrite, and it needs disk headroom for a second copy of each table while it
runs. The migration is deliberately **not** wrapped in a transaction, so each table
commits as it completes and an interruption leaves the tables done so far converted
and the rest untouched — re-running finishes the job.

**On PostgreSQL, set a `lock_timeout` first — this matters more than the rewrite.**
`ACCESS EXCLUSIVE` has to *wait* for every transaction already touching the table,
and while it waits it queues **ahead of** every new reader. One long-running query on
`audit_logs` therefore turns a sub-second `ALTER` into a stall of everything reading
that table, for as long as that query runs. Bounding the wait turns that from an
outage into a retry:

```sql
SET lock_timeout = '3s';   -- in the session that runs the migration
```

The `ALTER` then fails fast with `55P03 lock_not_available` instead of blocking the
application, and the migration can simply be re-run — it is idempotent, and picks up
where it left off.

**Rollout order — migration first, then code, and nothing to coordinate.** The
schema change is invisible to PHP: a `varchar(26)` and a `char(26)` both come back as
strings, and the only difference is that the `varchar` is not padded. So

- old code against the new schema works — it just stops seeing padding, which is the
  bug being fixed;
- new code against the old schema works — it is the behaviour that shipped for
  sixty-one releases.

There is no window in which a half-rolled-out deploy is inconsistent, and `down()`
restores the original `char` types exactly (verified by the same `pg_dump` diff, in
reverse).

**One column set worth naming.** `log_streams` and `stream_deliveries` belong to
`cboxdk/laravel-siem`, whose own create migration still calls `$table->ulid()`. This
package cannot edit it, so those three columns are converted by this migration on
**every** install, fresh or upgraded. That is why the migration does real work even on
a brand-new database.

---

## 0.61.0

### Do this BEFORE you deploy

**Nothing, if you run PostgreSQL or SQLite.** No migration is added and none of the
existing ones is edited in a way that touches a database that has already run them.
Read the note below anyway if you care about schema drift, or if you are about to
stand up a MySQL/MariaDB deployment.

---

### The migrations now run on MySQL and MariaDB (they never did)

**What was broken.** `docs/requirements.md` promised "any database Laravel supports —
MySQL/MariaDB, PostgreSQL, SQLite, SQL Server". On MySQL, `php artisan migrate` died on
the fifth table: twenty `json` columns carried a literal `DEFAULT '{}'` / `DEFAULT '[]'`,
which MySQL has never permitted on a BLOB/TEXT/JSON column (error 1101). Behind that were
three more walls — two composite indexes over the InnoDB 3072-byte key limit, and two
generated index names over the 64-character identifier limit. The suite ran only on
sqlite, which has none of those limits, so nothing ever said so.

**What changed.** `json` defaults now go through
`Cbox\Id\Kernel\Database\JsonDefault`, which emits `DEFAULT (json_object())` /
`DEFAULT (json_array())` on MySQL and MariaDB and the **unchanged literal** everywhere
else. Some columns that sit inside composite indexes were given explicit lengths, and
three over-long index names were shortened.

**Effect on an existing PostgreSQL database: none.** The emitted DDL for `pgsql` is
byte-identical for every `json` default — verified by diffing the full pretend-migration
output before and after. Nothing re-runs on a database that has already migrated.

**One divergence worth knowing about.** A database created *before* this release and one
created *after* it are not structurally identical, because the length and name changes
live in the original `create` migrations rather than in a new `ALTER`:

| | Before | Now |
|---|---|---|
| `relationship_tuples.object_type`, `relation`, `subject_type`, `subject_relation` | `varchar(255)` | `varchar(64)` |
| `relationship_tuples.object_id`, `subject_id` | `varchar(255)` | `varchar(128)` |
| `vault_secrets.name`, `owner_type`, `owner_id` | `varchar(255)` | `varchar(128)` |
| `audit_logs.environment_id`, `audit_checkpoints.environment_id` | `varchar(255)` | `varchar(64)` |
| `audit_logs.target_type` | `varchar(255)` | `varchar(64)` |
| index `relationship_tuples_organization_id_object_type_object_id_relation_index` | (truncated to 63 chars by PostgreSQL) | `relationship_tuples_org_object_relation_index` |
| constraint `provisioned_resources_environment_id_connection_id_user_id_unique` | (truncated) | `provisioned_resources_env_connection_user_unique` |
| index `external_action_endpoints_environment_id_hook_point_status_index` | (truncated) | `external_action_endpoints_env_hook_status_index` |

This is deliberate. Converging the two would mean an `ALTER TABLE` that rewrites
`audit_logs` — the highest-row-count table in the system — on every existing PostgreSQL
deployment, to fix a limit PostgreSQL does not have. The new widths are strictly
narrower, so any value a new install accepts an old one already accepts; the risk runs
one way only. If you want the schemas identical, write the `ALTER` yourself against a
maintenance window, after checking `max(length(...))` on each column.

## 0.58.0

### Do this BEFORE you deploy

1. **Update every call to `Memberships::add()`, `Memberships::changeRole()` and
   `Invitations::invite()`.** The `$role` parameter is now a `MembershipRole` enum, not a
   string. This breaks at compile/type level, so it will not slip past you silently — but
   it does break every host call site.
2. **If you implement `Federation\Contracts\Connections` yourself, add two methods.**
   `samlConfig()` and `oidcConfig()`. Nothing else about the interface changed.
3. **If you call `SamlSettings` directly, pass a `SamlConnectionConfig`.** It no longer
   takes an array, and `SamlSettings::slsUrl()` moved onto the value object.

Each is expanded below.

---

### Membership roles are an enum on the contract, not a string

**What changed.**

```diff
-public function add(string $organizationId, string $userId, string $role, ?string $invitedBy = null): Membership;
+public function add(string $organizationId, string $userId, MembershipRole $role, ?string $invitedBy = null): Membership;

-public function changeRole(string $organizationId, string $userId, string $role): Membership;
+public function changeRole(string $organizationId, string $userId, MembershipRole $role): Membership;

-public function invite(string $organizationId, string $email, string $role, ?string $invitedBy = null): PendingInvitation;
+public function invite(string $organizationId, string $email, MembershipRole $role, ?string $invitedBy = null): PendingInvitation;
```

`ImportOptions::$defaultRole` changes with them: `string $defaultRole = 'member'` becomes
`MembershipRole $defaultRole = MembershipRole::Member`.

**Why.** The role is authorization data — the last-owner guard and the console's
isOwner/isAdmin checks turn on it. The service already parsed it with
`MembershipRole::from()` internally, so a typo'd role was an uncaught `ValueError` (a 500)
deep inside a transaction rather than a validation failure, and static analysis could not
see it at all. The enum's own docblock states the goal the string signature defeated: an
invalid role should be unrepresentable.

It also fixes a quieter divergence: the audit payload recorded the caller's RAW string
while the row persisted the parsed enum, so a case-variant input made the audit trail
disagree with the stored role. Both now record the same enum-backed value.

**What to do.** Pass the enum:

```diff
-app(Memberships::class)->add($org->id, $user->id, 'admin');
+app(Memberships::class)->add($org->id, $user->id, MembershipRole::Admin);
```

Parse untrusted input (an HTTP field, a CSV cell) at the edge, where a bad value is a
validation failure you can report:

```php
$role = MembershipRole::tryFrom($request->string('role')->toString());

abort_if($role === null, 422, 'Unknown role.');
```

`tryFrom()` is case-sensitive and returns `null` — it never guesses.

**Related, non-breaking:** `Invitation::$role` is now cast to `MembershipRole` (the column
is unchanged; no migration). `cbox-id:users:import` validates `--role` up front and fails
with the accepted list instead of erroring mid-run, and an unrecognized role in an import
row is now a per-row `ImportError` naming the accepted roles rather than a raw
`ValueError` message.

---

### Federation connection configs are parsed value objects

**What changed.** `Federation\Contracts\Connections` gains two methods:

```php
public function samlConfig(Connection $connection): SamlConnectionConfig;
public function oidcConfig(Connection $connection): OidcConnectionConfig;
```

`config(): array` is unchanged and still there — it is the unseal half of the JSON
persistence boundary — but it is no longer how the config should be READ. `create()` is
also unchanged: it still takes an array, because a DRAFT connection is deliberately
allowed to be incomplete.

`SamlSettings::for()` and `SamlSettings::toArray()` now take a `SamlConnectionConfig`
instead of an array, and `SamlSettings::slsUrl(array $config)` is gone — it is
`$config->slsUrl()` on the value object.

**Why.** The config is durable, admin-authored configuration that four subsystems read
(assertion validation, SP metadata, SP-initiated login, Single Logout). As an
`array<string, mixed>` each of them re-read the same string keys and re-validated the
same shape across roughly two dozen sites, so adding one field — `jwks_uri` was the
motivating case — meant finding every reader.

**Behaviour note.** Required fields are asserted once, when the config is read, and the
error names the missing key exactly as before. One case tightened: reading a connection
as the wrong protocol (`oidcConfig()` on a SAML connection) now raises a message that
says so, instead of a confusing "missing [idp_entity_id]".

**What to do.**

```diff
-$config = $connections->config($connection);
-$settings = SamlSettings::toArray($config);
-$slo = SamlSettings::slsUrl($config);
+$config = $connections->samlConfig($connection);
+$settings = SamlSettings::toArray($config);
+$slo = $config->slsUrl();
```

**Related, non-breaking:** two Federation collaborators the HTTP layer drives are now
published as contracts and bound as singletons, matching every other collaborator in
the module — `OidcRelyingParty` (implemented by `OidcClient`) and `SamlSpSingleLogout`
(implemented by `Saml\SamlLogout`). The concrete classes still exist and still work; the
contracts are simply what you should type-hint and what you can rebind. Note the
SP-role name: `SamlIdp\Contracts\SamlSingleLogout` is the separate IdP-role interface.

---

## 0.57.0

### Do this BEFORE you deploy

1. **Run a queue worker.** Webhook delivery is no longer synchronous.
2. **Audit every registered client's scope list.** `invalid_scope` is now enforced at
   `/authorize`. This has the widest blast radius in the release.
3. **On PostgreSQL, reconcile case-variant duplicate usernames/emails.** Equality is now
   case-insensitive on every driver, so rows that used to coexist now collide.
4. **Re-read your published `config/cbox-id.php`.** Package defaults are now merged
   key-by-key instead of block-by-block, so settings a partial published config used to
   suppress are live again.

Each is expanded below.

---

### Webhooks require a running queue worker — SILENT if missing

**What changed.** `HttpWebhookDispatcher` used to make the outbound HTTP request in-band,
inside the relay pass. It now dispatches a `DeliverWebhook` job. The relay's job is to
enqueue; the worker's job is to deliver.

**Why.** One endpoint that accepts the connection and never answers used to hold the relay
pass open, delaying every other tenant's events behind it. Delivery also had no way to
recover a request the process died in the middle of.

**How it breaks.** A deployment with no worker consuming the queue enqueues jobs that are
never run. Deliveries sit at `pending`. **No exception is thrown and nothing is logged as
an error** — from the console the endpoint simply looks quiet. This is the failure mode
most likely to be mistaken for "no events happened".

**What to do.**

```sh
php artisan queue:work --queue=default
```

Run it under a supervisor (systemd, Supervisor, Horizon) so it restarts. If you already
run a worker for the framework's own queues, webhook jobs go on the same connection unless
you separate them:

```env
CBOX_ID_WEBHOOKS_QUEUE_CONNECTION=redis
CBOX_ID_WEBHOOKS_QUEUE=webhooks
```

`QUEUE_CONNECTION=sync` also "works" and restores the old inline behaviour — but it
reintroduces the head-of-line blocking the change exists to remove, so treat it as a
development setting only.

**How to check you got it right.** After deploying, trigger any event and confirm the
delivery leaves `pending`. `php artisan cbox-id:events:backlog --json` reports outbox depth;
a depth that only grows means the relay or the worker is not running.

See [Background work](docs/operations/background-work.md) for the full picture, including
the retry sweep, the stranded-delivery rescue and the per-endpoint circuit breaker.

### The root host now 404s the IdP surface

**What changed.** The protocol surface — OIDC discovery, JWKS, `/oauth/*`, SCIM — is now
behind a configurable middleware gate (`cbox-id.api.middleware`). In a multi-tenant
deployment the apex host refuses it.

**How it breaks.** A client pointed at the apex rather than at its environment's issuer
gets a `404`, where it previously got a working response. This looks exactly like an
outage.

**What to do.** Point clients at the issuer that discovery advertises, never at the apex.
The gate is inert in a single-tenant install (`cbox-id.api.middleware` defaults to `[]`),
so nothing changes there. See the deployment docs in the app repo for the host layout.

**Note:** `GET /up` is registered outside the gated group and still answers on every host,
so a liveness probe against the apex is unaffected.

### `invalid_scope` is enforced at `/authorize` — widest blast radius

**What changed.** A scope the client is not registered for used to be accepted at
`/authorize` and then quietly filtered out when the token was minted. It is now refused up
front with `error=invalid_scope`.

**Why.** The old behaviour turned a registration mistake into a mystery: the authorization
succeeded, the token came back missing a scope, and the client's next API call failed with
a 403 that nothing anywhere explained.

**How it breaks.** **Every deployed client whose SDK requests more scopes than it
registered now hard-fails at the authorize step instead of degrading.** You do not control
when those clients next run, and you cannot fix them from the server side after the fact.
The usual culprits are `email` and `offline_access` — SDK defaults that were never added to
the registration.

**What to do — before you deploy.** For every client, compare its registered scope list
against what its SDK actually sends:

```sh
php artisan tinker
>>> \Cbox\Id\OAuthServer\Models\Client::query()->get(['client_id', 'name', 'scopes']);
```

Add any scope that is legitimately requested. A client registered with **no** scopes at all
is exempt from the check — it has declared no surface to validate against — so an empty
list is not a false positive.

**Related, non-breaking:** `/oauth/token` now echoes the granted `scope` in its response, so
a narrowed grant is visible at the point it happens.

### SAML: stricter `AuthnRequest` handling

Four changes, all refusals that used to be acceptances:

- **`NameIDPolicy` is enforced** against what the registered SP can actually be answered
  under. A policy the registration does not support is refused instead of being answered
  under a different format. (`urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified` still
  means "IdP, you choose" — note the **1.1** prefix. There is no `SAML:2.0:…:unspecified`;
  SAML 2.0 carries the 1.1 URN forward unchanged, and `NameIdFormat::tryFromPolicyUrn()`
  returns null for the 2.0 spelling, so an SP configured from an earlier revision of this
  line is answered `InvalidNameIDPolicy`.)
- **A signed `AuthnRequest` must carry a `Destination`.** A signed request with no
  `Destination` at all was previously accepted; it is now refused, because the signature
  then covers no statement about where the request was meant to go.
- **An `AuthnRequest` is single-use.** A replayed request id is refused.
- **An `AuthnRequest` older than 15 minutes is refused.**

**What to do.** If an SP integration starts failing, the refusal reason is in the audit
trail. A relying party that cannot supply `Destination` on a signed request must either
stop signing or be fixed; there is no configuration switch to re-accept it.

### SCIM: stricter errors, and one response-shape change

| Case | Before | Now |
|---|---|---|
| `DELETE` an id that does not exist | `204` | `404` |
| `PATCH` with malformed or absent `Operations` | `200` (silently no-op) | `400` |
| `active` sent as a non-boolean (`"fasle"`, `"no"`, `0`, `1`) | `200`, treated as false | `400` |
| Rate limited | plain framework `429` | `429` inside the SCIM Error envelope, `Retry-After` intact |
| `GET /Groups` (listing) | included `members` | **omits `members`** unless requested |
| Filter literal of the wrong type for its attribute | matched nothing, `200` | `400 invalidFilter` |

The `/Groups` change is the one that can break a working integration: a client that reads
membership from the listing now sees no members. Ask for them explicitly
(`?attributes=members`), or read the group singly — a single-resource `GET /Groups/{id}`
still returns members. The change exists because a page of large groups was a memory bomb.

The stricter errors are a net win for integrators (a rejected write is now visible instead
of being reported as a success it did not make), but a connector that treats any non-2xx as
fatal will start alerting on requests it used to send happily.

See [SCIM](docs/core-concepts/scim.md) for the full endpoint reference.

### `userName` / email equality is case-insensitive on ALL drivers

**What changed.** Comparison used to depend on the database's collation: case-insensitive
on MySQL's default collation, case-**sensitive** on PostgreSQL. It is now case-insensitive
everywhere, via normalized columns
(`2026_07_25_000100_add_normalized_scim_columns_to_directory_users`).

**How it breaks.** **A PostgreSQL tenant may hold rows that were legal before and are not
now** — `Alice@example.com` and `alice@example.com` as two separate directory users. After
the migration they collide, and a create or update that touches either returns
`409 uniqueness`.

**What to do — before you deploy.** Find the duplicates and merge or delete them:

```sql
SELECT directory_id, lower(user_name) AS key, count(*)
FROM directory_users
GROUP BY directory_id, lower(user_name)
HAVING count(*) > 1;

SELECT directory_id, lower(email) AS key, count(*)
FROM directory_users
WHERE email IS NOT NULL
GROUP BY directory_id, lower(email)
HAVING count(*) > 1;
```

The migration backfills `user_name_lower` / `email_lower` and indexes them; it does NOT
deduplicate. Decide which row survives for each collision —
this is a data decision, not a mechanical one, because the two rows may carry different
memberships. The migration itself does not merge them for you.

### `/up` returns JSON

`GET /up` now returns `{"status":"ok"}` with `Content-Type: application/json` instead of an
empty body. A probe asserting on an empty body or on `text/html` needs updating; a probe
asserting only on the status code is unaffected.

### Published config is merged key-by-key, not block-by-block

**What changed.** The package used to merge its defaults with Laravel's
`mergeConfigFrom()`, a single `array_merge()` that only merges the TOP level. It now uses
`Cbox\Id\Support\PackageConfigMerger`, which recurses.

**Why.** A published `config/cbox-id.php` is almost always PARTIAL — you override one
setting and delete the rest of the file. Under the old merge, naming a top-level key
replaced the package's ENTIRE block for that key. An app whose config declared nothing but

```php
'oauth' => ['authorization_endpoint_path' => '/oauth/authorize'],
```

silently lost `oauth.access_token_ttl`, `oauth.require_par`, `oauth.embed_entitlements`,
`oauth.decisions.*`, `oauth.ciba.*`, `oauth.dynamic_registration.*` and
`oauth.authorization_endpoint`. Every consumer inside the package passes a hard-coded
fallback to `config()`, so nothing crashed — but `CBOX_ID_ACCESS_TOKEN_TTL`,
`CBOX_ID_REQUIRE_PAR`, `CBOX_ID_DCR_MODE`, `CBOX_ID_DECISIONS_MAX_BATCH` and
`CBOX_ID_CIBA_*` were **inert**. Setting them did nothing and said nothing.

**The rules.**

- Your value wins on any key you define, including `null`, `false` and `0`.
- A package default is only ever filled in where your config is SILENT about that key.
- A **list** (sequential array — `api.middleware`, `oauth.dynamic_registration.allowed_scopes`)
  is treated as a single value: yours REPLACES the package's, it is never appended to. You
  can still shrink a default list, or empty it with `[]`.
- Where your value and the package's are different types, yours stands unmerged.

**How it breaks you.** Only in one shape: if you were relying on the shallow merge to
REMOVE a package default — omitting a sibling key so it disappeared entirely — that key is
now present again at its package default. Check any top-level block you published
partially. Package defaults are conservative (DCR `disabled`, PAR not required), so the
usual effect of getting them back is that an env var you set now takes effect. To keep a
default suppressed, state it explicitly:

```php
'oauth' => [
    'authorization_endpoint_path' => '/oauth/authorize',
    'embed_entitlements' => false, // explicit beats omitted
],
```

`php artisan cbox-id:doctor` and `php artisan config:show cbox-id` both print the merged
result, which is the fastest way to see what your deployment actually resolves.

---

## How to read this file

An entry earns a place here only if a deployment that was working can stop working, or
start behaving differently, without anyone changing their own code. Additive features,
new endpoints and bug fixes that only ever made a wrong answer right live in
[`CHANGELOG.md`](CHANGELOG.md).
