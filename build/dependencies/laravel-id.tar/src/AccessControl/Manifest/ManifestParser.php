<?php

declare(strict_types=1);

namespace Cbox\Id\AccessControl\Manifest;

use Cbox\Id\AccessControl\Exceptions\InvalidManifest;
use Cbox\Id\Migration\ValueObjects\LegacyLoginDeclaration;

/**
 * Parses + validates a raw manifest document (already JSON-decoded to an array)
 * into a typed {@see Manifest}. Deny-by-default: anything malformed — a bad key
 * format, a duplicate, or a role referencing an undeclared permission — is rejected
 * whole, never partially applied.
 */
class ManifestParser
{
    /** A `feature:action` (or bare `feature`) slug — lowercase, dot/colon/underscore/dash segments. */
    private const KEY_PATTERN = '/^[a-z][a-z0-9_-]*(?:[.:][a-z0-9_-]+)*$/';

    /**
     * @param  array<string, mixed>  $data
     */
    public function parse(array $data): Manifest
    {
        $version = $data['version'] ?? '';

        if (! is_string($version) || $version === '') {
            throw InvalidManifest::make('a non-empty "version" string is required.');
        }

        $permissions = $this->parsePermissions($data['permissions'] ?? []);
        $declaredKeys = array_map(static fn (DeclaredPermission $p): string => $p->key, $permissions);

        $roles = $this->parseRoles($data['roles'] ?? [], $declaredKeys);

        /** @var array<string, mixed>|null $legacyLogin */
        $legacyLogin = is_array($raw = $data['legacy_login'] ?? null) ? $raw : null;

        return new Manifest(
            $version,
            $permissions,
            $roles,
            // Throws on a half-declaration rather than ignoring it: an app that declared
            // something we refused should fail its deploy, not believe it is migrating
            // when it is not.
            $legacyLogin !== null ? LegacyLoginDeclaration::fromArray($legacyLogin) : null,
        );
    }

    /**
     * @param  mixed  $raw
     * @return list<DeclaredPermission>
     */
    private function parsePermissions($raw): array
    {
        if (! is_array($raw)) {
            throw InvalidManifest::make('"permissions" must be a list.');
        }

        $permissions = [];
        $seen = [];

        foreach ($raw as $entry) {
            if (! is_array($entry)) {
                throw InvalidManifest::make('each permission must be an object.');
            }

            $key = $this->requireKey($entry['key'] ?? null, 'permission');

            if (isset($seen[$key])) {
                throw InvalidManifest::make("duplicate permission \"{$key}\".");
            }
            $seen[$key] = true;

            $permissions[] = new DeclaredPermission(
                $key,
                $this->optionalString($entry['description'] ?? null),
                // Deny-by-default: a permission is tenant self-serve-assignable ONLY when
                // the app explicitly declares "tenant_assignable": true. An omitted or
                // non-true value keeps it internal. As apps become third-party-authored,
                // an unset field must narrow access, not widen it — the opt-IN model.
                ($entry['tenant_assignable'] ?? false) === true,
            );
        }

        return $permissions;
    }

    /**
     * @param  mixed  $raw
     * @param  list<string>  $declaredPermissionKeys
     * @return list<DeclaredRole>
     */
    private function parseRoles($raw, array $declaredPermissionKeys): array
    {
        if (! is_array($raw)) {
            throw InvalidManifest::make('"roles" must be a list.');
        }

        $roles = [];
        $seen = [];
        $seenNames = [];

        foreach ($raw as $entry) {
            if (! is_array($entry)) {
                throw InvalidManifest::make('each role must be an object.');
            }

            $key = $this->requireKey($entry['key'] ?? null, 'role');

            if (isset($seen[$key])) {
                throw InvalidManifest::make("duplicate role \"{$key}\".");
            }
            $seen[$key] = true;

            $name = $entry['name'] ?? null;
            if (! is_string($name) || $name === '') {
                throw InvalidManifest::make("role \"{$key}\" needs a non-empty name.");
            }

            // Names must be distinct too — a person picking a role sees the name, and
            // two roles sharing one would be ambiguous (and collide in storage).
            $nameKey = mb_strtolower($name);
            if (isset($seenNames[$nameKey])) {
                throw InvalidManifest::make("duplicate role name \"{$name}\".");
            }
            $seenNames[$nameKey] = true;

            $permissions = $this->parseRolePermissions($entry['permissions'] ?? [], $key, $declaredPermissionKeys);

            $roles[] = new DeclaredRole(
                $key,
                $name,
                $this->optionalString($entry['description'] ?? null),
                $permissions,
                array_key_exists('tenant_assignable', $entry) ? $this->roleTenantAssignable($entry['tenant_assignable'], $key) : true,
            );
        }

        return $roles;
    }

    /**
     * Whether tenants may grant this role, when the key is present. Absent means yes;
     * `false` marks a staff role; an explicit `null` is refused like any other non-boolean
     * rather than read as absent.
     *
     * STRICTLY A BOOLEAN. The permission flag above reads anything but `true` as "no",
     * which is safe there because its default is the narrow one. Here the default is the
     * WIDE one, so the same leniency would turn a staff role declared as `"false"` (a
     * string, from a YAML-to-JSON step or a hand-edited file) into one every tenant
     * administrator can hand out. A value we cannot read unambiguously refuses the whole
     * manifest instead.
     *
     * @param  mixed  $value
     */
    private function roleTenantAssignable($value, string $roleKey): bool
    {
        if (! is_bool($value)) {
            throw InvalidManifest::make("role \"{$roleKey}\" tenant_assignable must be true or false.");
        }

        return $value;
    }

    /**
     * @param  mixed  $raw
     * @param  list<string>  $declaredPermissionKeys
     * @return list<string>
     */
    private function parseRolePermissions($raw, string $roleKey, array $declaredPermissionKeys): array
    {
        if (! is_array($raw)) {
            throw InvalidManifest::make("role \"{$roleKey}\" permissions must be a list.");
        }

        $permissions = [];

        foreach ($raw as $permission) {
            if (! is_string($permission)) {
                throw InvalidManifest::make("role \"{$roleKey}\" has a non-string permission.");
            }

            // A role may only grant permissions the same manifest declares — no
            // dangling references.
            if (! in_array($permission, $declaredPermissionKeys, true)) {
                throw InvalidManifest::make("role \"{$roleKey}\" references undeclared permission \"{$permission}\".");
            }

            if (! in_array($permission, $permissions, true)) {
                $permissions[] = $permission;
            }
        }

        return $permissions;
    }

    /**
     * @param  mixed  $value
     */
    private function requireKey($value, string $what): string
    {
        if (! is_string($value) || preg_match(self::KEY_PATTERN, $value) !== 1) {
            throw InvalidManifest::make("each {$what} needs a valid lowercase key (e.g. invoices:create).");
        }

        return $value;
    }

    /**
     * @param  mixed  $value
     */
    private function optionalString($value): ?string
    {
        return is_string($value) && $value !== '' ? $value : null;
    }
}
