<?php

declare(strict_types=1);

namespace Cbox\Id\AccessControl;

use Cbox\Id\AccessControl\Contracts\GrantGuard;
use Cbox\Id\AccessControl\Contracts\Roles;
use Cbox\Id\AccessControl\Enums\GrantSource;
use Cbox\Id\AccessControl\Exceptions\GrantRefused;
use Cbox\Id\AccessControl\Exceptions\RoleNotTenantAssignable;
use Cbox\Id\AccessControl\Exceptions\UnknownRole;
use Cbox\Id\AccessControl\Models\EnvironmentRoleAssignment;
use Cbox\Id\AccessControl\Models\GroupRoleMapping;
use Cbox\Id\AccessControl\Models\Permission;
use Cbox\Id\AccessControl\Models\Role;
use Cbox\Id\AccessControl\Models\RoleAssignment;
use Cbox\Id\Kernel\Audit\Contracts\AuditLog;
use Cbox\Id\Kernel\Audit\Enums\ActorType;
use Cbox\Id\Kernel\Audit\ValueObjects\AuditEvent;
use Cbox\Id\Kernel\Events\Contracts\EventBus;
use Cbox\Id\Kernel\Events\ValueObjects\DomainEvent;
use Cbox\Id\Organization\Contracts\Memberships;
use Cbox\Id\Organization\Models\Membership;
use Illuminate\Support\Facades\DB;

class RoleService implements Roles
{
    public function __construct(
        private readonly EventBus $events,
        private readonly AuditLog $audit,
        private readonly GrantGuard $grants,
    ) {}

    public function define(?string $organizationId, string $name, ?string $description = null, ?string $clientId = null, bool $tenantAssignable = true): Role
    {
        return Role::query()->firstOrCreate(
            ['organization_id' => $organizationId, 'client_id' => $clientId, 'name' => $name],
            ['description' => $description, 'tenant_assignable' => $tenantAssignable],
        );
    }

    public function grantPermission(?string $organizationId, string $roleId, string $permission): void
    {
        // The role must belong to the caller's org — never grant onto another
        // tenant's role.
        //
        // NULL NAMES THE ENVIRONMENT PLANE, the same thing it means to requireRole() and
        // attachPermission(). This took a non-nullable organization and matched on it, so
        // an environment-wide role — the only kind that can be granted across every
        // tenant — could never be given a permission through this method at all. The gap
        // only showed once environment-wide GRANTS existed and a global role with no
        // permissions turned out to be a name and nothing else.
        $role = Role::query()
            ->whereKey($roleId)
            ->when(
                $organizationId === null,
                fn ($query) => $query->whereNull('organization_id'),
                fn ($query) => $query->where('organization_id', $organizationId),
            )
            ->first();

        if ($role === null) {
            throw UnknownRole::make($roleId);
        }

        // Resolve the permission WITHIN the role's own scope. An app-scoped role's
        // permissions live under that app's client_id; an org-wide role's under
        // client_id null. Matching on (client_id, name) — the table's unique key —
        // means we reuse the app's declared permission instead of minting a stray
        // client_id-null duplicate of it (the old firstOrCreate(['name']) bug).
        $model = Permission::query()->firstOrCreate([
            'client_id' => $role->client_id,
            'name' => $permission,
        ]);

        DB::table('role_permission')->insertOrIgnore([
            'role_id' => $roleId,
            'permission_id' => $model->id,
        ]);
    }

    public function updateRole(string $roleId, string $name, ?string $description = null, ?string $organizationId = null, ?bool $tenantAssignable = null): Role
    {
        $role = $this->requireRole($roleId, $organizationId);

        $before = ['name' => $role->name, 'description' => $role->description, 'tenant_assignable' => $role->tenant_assignable];

        $role->name = $name;
        $role->description = $description;

        if ($tenantAssignable !== null) {
            $role->tenant_assignable = $tenantAssignable;
        }

        $role->save();

        // The staff flag rides the same `role.updated` entry as a rename, with before and
        // after, because "who may hand this role out" changing is exactly the kind of edit
        // an auditor looks for and should not have to infer from a later grant.
        $this->recordRoleChange($role, 'role.updated', [
            'from' => $before,
            'to' => ['name' => $name, 'description' => $description, 'tenant_assignable' => $role->tenant_assignable],
        ]);

        return $role;
    }

    public function attachPermission(string $roleId, string $permissionId, ?string $organizationId = null): void
    {
        $role = $this->requireRole($roleId, $organizationId);

        $attached = DB::table('role_permission')->insertOrIgnore([
            'role_id' => $role->id,
            'permission_id' => $permissionId,
        ]);

        // Announce a STATE CHANGE, not a call — the same rule assign() follows.
        if ($attached > 0) {
            $this->recordRoleChange($role, 'role.permission_granted', ['permission_id' => $permissionId]);
        }
    }

    public function revokePermission(string $roleId, string $permissionId, ?string $organizationId = null): void
    {
        $role = $this->requireRole($roleId, $organizationId);

        $detached = DB::table('role_permission')
            ->where('role_id', $role->id)
            ->where('permission_id', $permissionId)
            ->delete();

        if ($detached > 0) {
            $this->recordRoleChange($role, 'role.permission_revoked', ['permission_id' => $permissionId]);
        }
    }

    public function deleteRole(string $roleId, ?string $organizationId = null): void
    {
        $role = $this->requireRole($roleId, $organizationId);

        // One transaction for the whole removal, and for the events it announces.
        //
        // Nothing here cascades at the database layer, so a partial delete is a
        // half-removed role: rows pointing at an id that no longer resolves, with no
        // second pass to finish the job. The outbox rows are written inside it too — the
        // same rule MembershipService::add() follows — so a crash cannot leave the grants
        // gone and the `role.unassigned` events unwritten.
        DB::transaction(function () use ($role): void {
            // Read the holders BEFORE the delete: they are the subjects whose privileges
            // this removes, and the only way a downstream mirror can be told which grants
            // went. Nothing else reports them — there is no FK cascade and no observer.
            $held = RoleAssignment::query()->where('role_id', $role->id)->get();

            // ENVIRONMENT-WIDE GRANTS GO TOO. This deleted the role and its org
            // assignments and left `environment_role_assignments` rows naming an id that
            // no longer resolves — so `everywhereFor()` reported a phantom role, a
            // segregation-of-duties policy naming the dead id produced false conflicts,
            // and any downstream mirror reconciling off unassignment events never heard
            // that those holders lost it. No token ever carried it (the read re-resolves
            // the role row, which is gone), which is exactly why it could sit unnoticed.
            $heldEverywhere = EnvironmentRoleAssignment::query()->where('role_id', $role->id)->get();

            DB::table('role_permission')->where('role_id', $role->id)->delete();

            // The directory group→role mappings MUST go with the role. `group_role_mappings`
            // has neither a foreign key nor a cascade, so a surviving mapping keeps naming a
            // role id that no longer resolves — and the next reconcile of that group plucks
            // it, calls assign(), and assertAssignableIn() throws UnknownRole. That is the
            // exact poison-pill this class's map() docblock says it fixed, reintroduced from
            // the other end: the reconcile runs on the RELAY, whose isolation releases the
            // claim and retries the event forever, so the outbox row can never be pruned and
            // every listener registered after AccessControl — webhooks, provisioning, usage
            // metering, audit streaming — is skipped for that event on every pass.
            GroupRoleMapping::query()->where('role_id', $role->id)->delete();

            RoleAssignment::query()->where('role_id', $role->id)->delete();
            EnvironmentRoleAssignment::query()->where('role_id', $role->id)->delete();
            $role->delete();

            // One `role.unassigned` per holder, exactly as unassign() emits, so a consumer
            // reconciling grants off that event learns the role is gone from each subject.
            $userIds = [];
            foreach ($held as $assignment) {
                $userIds[] = $assignment->user_id;
                $this->emitAndAudit($assignment->organization_id, $assignment->user_id, $role->id, 'role.unassigned');
            }

            foreach ($heldEverywhere as $assignment) {
                $userIds[] = $assignment->user_id;
                $this->emitAndAudit(null, $assignment->user_id, $role->id, 'role.unassigned_everywhere', ['client_id' => $role->client_id]);
            }

            // Folded into the same list, so `role.deleted`'s `user_ids` names everybody
            // who actually lost the role rather than only the org-scoped holders.
            $userIds = array_values(array_unique($userIds));

            $this->recordRoleChange($role, 'role.deleted', [
                'name' => $role->name,
                'client_id' => $role->client_id,
                'user_ids' => $userIds,
            ]);
        });
    }

    /**
     * The role, resolved WITHIN the organization the caller says it is acting for.
     *
     * `whereKey()` under the environment scope was the whole boundary, which made the
     * tenant fence a convention rather than a query: a surface that correctly checked
     * "may this administrator manage organization A" and then passed an id belonging to
     * organization B mutated B's role, because nothing between the check and the write
     * ever compared the two. The app's own console resolves through an ownership-scoped
     * set before it calls, so nothing shipped was exploitable — but the contract invited
     * the mistake, and this package is consumed by more than one caller.
     *
     * `$organizationId` is nullable and defaults to null so existing callers are
     * unaffected, and null means the environment plane: an operator managing the
     * environment's own roles, which is what the parameter's absence has always meant.
     * A caller that passes one gets the fence; a caller that does not is exactly as
     * scoped as it was. New tenant-facing code should always pass it.
     *
     * @throws UnknownRole when no such role exists, or it belongs to another organization
     *                     — the same refusal for both, because a caller not entitled to
     *                     the role is not entitled to learn it exists
     */
    private function requireRole(string $roleId, ?string $organizationId = null): Role
    {
        $role = Role::query()
            ->whereKey($roleId)
            ->when($organizationId !== null, fn ($query) => $query->where('organization_id', $organizationId))
            ->first();

        if ($role === null) {
            throw UnknownRole::make($roleId);
        }

        return $role;
    }

    /**
     * Emit + audit a change to the role CATALOG. Mirrors {@see emitAndAudit()}, but
     * the target is the role rather than a subject, and the tenant tag is the role's
     * own organization (null for an environment-wide role, which records on the
     * system trail).
     *
     * @param  array<string, mixed>  $context
     */
    private function recordRoleChange(Role $role, string $action, array $context = []): void
    {
        $this->events->emit(new DomainEvent(
            $action,
            ['role_id' => $role->id] + $context,
            $role->organization_id,
        ));

        $this->audit->record(new AuditEvent(
            action: $action,
            actorType: ActorType::System,
            organizationId: $role->organization_id,
            targetType: 'role',
            targetId: $role->id,
            context: $context,
        ));
    }

    public function assign(
        string $organizationId,
        string $userId,
        string $roleId,
        GrantSource $source = GrantSource::Manual,
    ): RoleAssignment {
        // The role must be assignable IN this organization — either its own, or a system
        // role (organization_id null) shared across the environment. This is the chokepoint
        // every caller funnels through — console toggles, directory group→role mapping and
        // invitation grants all land here — so validating once closes all of them. Without
        // it a caller can name ANOTHER tenant's role id and have it written under their own
        // org, and the read path would then surface that role's permissions in this org's
        // tokens. Mirrors the ownership check grantPermission() has always had.
        $this->assertAssignableIn($organizationId, $roleId);

        // Conflict rules, at the same chokepoint as ownership. These used to be enforced
        // only by the host, in front of the console's manual grant paths — and the one
        // path a host cannot get in front of is this one, so a directory group→role
        // mapping created toxic pairs the console would have refused, silently, on every
        // reconcile. The automation a customer buys is not a way around the control they
        // bought. Via a contract because Governance already depends on AccessControl and
        // a direct dependency back would close a cycle.
        $refusal = $this->grants->refuse($organizationId, $userId, $roleId, $source);

        if ($refusal !== null) {
            throw new GrantRefused($organizationId, $userId, $roleId, $refusal);
        }

        $assignment = RoleAssignment::query()->firstOrCreate(
            ['organization_id' => $organizationId, 'user_id' => $userId, 'role_id' => $roleId],
            ['source' => $source],
        );

        // Announce a STATE CHANGE, not a call. Re-assigning a role the user already
        // holds is a no-op on the row, and emitting anyway made every reconcile pass
        // write an outbox row plus a hash-chained audit entry per user.
        //
        // The directory reconciler makes that constant: it compares the mapped roles
        // against the assignments whose source is `pushed`, so a user holding a mapped
        // role via a MANUAL grant is never in that set and is "assigned" again on every
        // single reconcile — burning a relay slot each time and feeding the very relay
        // backlog the async webhook work exists to keep short.
        if ($assignment->wasRecentlyCreated) {
            $this->emitAndAudit($organizationId, $userId, $roleId, 'role.assigned');
        }

        return $assignment;
    }

    /**
     * A role belongs to this organization, or is a system role usable by any org in the
     * environment. Anything else is another tenant's policy and is refused.
     *
     * Public so callers that write a role id somewhere OTHER than an assignment row —
     * directory group→role mappings, for one — can refuse it up front rather than
     * discovering it later during reconciliation.
     *
     * @throws UnknownRole
     */
    public function assertAssignableIn(string $organizationId, string $roleId): void
    {
        $assignable = Role::query()
            ->whereKey($roleId)
            ->where(fn ($query) => $query
                ->whereNull('organization_id')
                ->orWhere('organization_id', $organizationId))
            // An ORPHANED role is one whose declaring app dropped it from its manifest.
            // The console stopped offering those, but this check did not refuse them — so
            // an admin who knew a retired role's id could still map a directory group to
            // it by calling the action directly, and every reconcile then granted a role
            // the owning application no longer believes in. A role nobody can see in the
            // UI is precisely the one worth naming by hand.
            ->whereNull('orphaned_at')
            ->exists();

        if (! $assignable) {
            throw UnknownRole::make($roleId);
        }
    }

    public function tenantAssignableRoles(string $organizationId, ?string $clientId = null): array
    {
        return array_values(Role::query()
            ->tenantAssignable($organizationId, $clientId)
            ->orderBy('name')
            ->orderBy('id')
            ->get()
            ->all());
    }

    /**
     * The organization-plane guard.
     *
     * The id is bound INTO the same predicate the tenant's role list uses, rather than
     * loaded and then inspected: a staff role and another tenant's role are refused by
     * the one query that decides what the tenant may see, so the list and the write
     * cannot drift apart, and no caller-side scope can make it pass by accident.
     *
     * @throws RoleNotTenantAssignable
     */
    public function assertTenantAssignable(string $organizationId, string $roleId): void
    {
        $assignable = Role::query()
            ->whereKey($roleId)
            ->tenantAssignable($organizationId)
            ->exists();

        if (! $assignable) {
            throw RoleNotTenantAssignable::forRole($roleId);
        }
    }

    public function assignAsTenant(
        string $organizationId,
        string $userId,
        string $roleId,
        GrantSource $source = GrantSource::Manual,
    ): RoleAssignment {
        $this->assertTenantAssignable($organizationId, $roleId);

        return $this->assign($organizationId, $userId, $roleId, $source);
    }

    /**
     * Grant a role EVERYWHERE in this environment, rather than inside one organization.
     *
     * For the people an org-scoped grant cannot describe: a support agent of the product
     * who acts across every customer, somebody who has not joined an organization, and
     * any service provider with no tenancy of its own to hang a grant on.
     *
     * ONLY A ROLE NO ORGANIZATION OWNS MAY BE GRANTED THIS WAY. A role owned by one
     * organization is that tenant's own policy, named by them and meaning what they say
     * it means; handing it to somebody across the whole environment would grant every
     * other tenant a role they did not define and cannot see. That refusal is the one
     * guard on this path that is not merely tidy.
     *
     * AN APP'S OWN ROLES ARE ACCEPTED. This used to refuse any role with a `client_id`,
     * on the grounds that an app role granted everywhere would put one app's vocabulary
     * into every tenant — and the consequence was that the only staff role anybody could
     * grant was an app-agnostic one, which then appeared in EVERY app's token in the
     * environment: a cadastre "Support" role riding into the tax app's tokens. An
     * app-declared role granted everywhere now reaches that app's tokens and no other's;
     * the read side filters by client exactly as it does for an organization grant
     * ({@see HierarchyAwareAccessChecker::forToken()}).
     *
     * @throws UnknownRole when the role does not exist, is orphaned, or belongs to one
     *                     organization
     */
    public function assignEverywhere(
        string $userId,
        string $roleId,
        GrantSource $source = GrantSource::Manual,
    ): EnvironmentRoleAssignment {
        $role = Role::query()
            ->whereKey($roleId)
            ->whereNull('organization_id')
            ->whereNull('orphaned_at')
            ->first();

        if ($role === null) {
            throw UnknownRole::make($roleId);
        }

        // THE CONFLICT CHECK, WHICH THIS PATH SKIPPED. assign() asks the guard before
        // writing; this did not, and the reasoning was that segregation of duties refuses
        // a toxic PAIR within an organization while this grant belongs to none — so the
        // NEXT org-scoped grant would be refused where the pair actually forms.
        //
        // That covers one order and not the other. Somebody already holding `Approver` in
        // one organization could be given a conflicting `Support` everywhere, and no
        // later grant ever happens to trigger the check: the pair simply exists, in that
        // organization's tokens, having been refused nowhere.
        //
        // So the question is asked ONCE PER ORGANIZATION THE PERSON IS IN, because that
        // is precisely where this grant is about to land. A refusal anywhere refuses the
        // whole thing — a grant that cannot be made in one tenant is not a grant that can
        // be made in all of them.
        foreach ($this->organizationsOf($userId) as $organizationId) {
            $refusal = $this->grants->refuse($organizationId, $userId, $roleId, $source);

            if ($refusal !== null) {
                throw new GrantRefused($organizationId, $userId, $roleId, $refusal);
            }
        }

        $assignment = EnvironmentRoleAssignment::query()->firstOrCreate(
            ['user_id' => $userId, 'role_id' => $roleId],
            ['source' => $source],
        );

        // Same rule as assign(): announce a state change, never a call.
        //
        // WITH THE ROLE'S APP. A downstream mirror reconciling off this event has to know
        // which application the grant reaches — an app-agnostic staff role and one app's
        // "Support" are very different grants — and the role row is the only place it can
        // learn that from after the fact.
        if ($assignment->wasRecentlyCreated) {
            $this->emitAndAudit(null, $userId, $roleId, 'role.assigned_everywhere', ['client_id' => $role->client_id]);
        }

        return $assignment;
    }

    /**
     * The organizations this person is a member of.
     *
     * THROUGH THE CONTRACT, and this is the third way of asking that turned out to be
     * wrong. `DB::table('memberships')` reads every environment's rows. `Membership::query()`
     * looks right and answers NOTHING: the model carries a tenant scope that denies by
     * default when no tenant is in context — which is exactly the state an environment-wide
     * grant is made in — so the guard below would have been asked about zero organizations
     * and refused nothing, silently, while looking like it worked. That is the same
     * deny-to-empty trap the devices console documents.
     *
     * `forUser()` exists precisely for this: the contract calls it "a legitimate
     * cross-tenant 'which orgs am I in' lookup".
     *
     * @return list<string>
     */
    private function organizationsOf(string $userId): array
    {
        return array_values(array_filter(
            app(Memberships::class)->forUser($userId)
                ->map(static fn (Membership $membership): string => $membership->organization_id)
                ->all(),
            'is_string',
        ));
    }

    /** Take back an environment-wide grant. */
    public function unassignEverywhere(string $userId, string $roleId): void
    {
        $deleted = EnvironmentRoleAssignment::query()
            ->where('user_id', $userId)
            ->where('role_id', $roleId)
            ->delete();

        if ($deleted > 0) {
            $this->emitAndAudit(null, $userId, $roleId, 'role.unassigned_everywhere', [
                'client_id' => Role::query()->whereKey($roleId)->value('client_id'),
            ]);
        }
    }

    /**
     * The role ids this user holds everywhere in the environment.
     *
     * @return list<string>
     */
    public function everywhereFor(string $userId): array
    {
        return array_values(array_filter(
            EnvironmentRoleAssignment::query()->where('user_id', $userId)->pluck('role_id')->all(),
            'is_string',
        ));
    }

    public function unassign(string $organizationId, string $userId, string $roleId): void
    {
        $deleted = RoleAssignment::query()
            ->where('organization_id', $organizationId)
            ->where('user_id', $userId)
            ->where('role_id', $roleId)
            ->delete();

        // Same rule as assign(): revoking a role the user does not hold changed
        // nothing, so it announces nothing.
        if ($deleted > 0) {
            $this->emitAndAudit($organizationId, $userId, $roleId, 'role.unassigned');
        }
    }

    public function unassignAll(string $organizationId, string $userId): int
    {
        $roleIds = RoleAssignment::query()
            ->where('organization_id', $organizationId)
            ->where('user_id', $userId)
            ->pluck('role_id')
            ->all();

        if ($roleIds === []) {
            return 0;
        }

        RoleAssignment::query()
            ->where('organization_id', $organizationId)
            ->where('user_id', $userId)
            ->delete();

        // One event per role, not one for the batch: a downstream consumer reconciling
        // grants needs to know WHICH roles went, and every other revocation on this
        // service reports itself that way.
        foreach ($roleIds as $roleId) {
            if (is_string($roleId)) {
                $this->emitAndAudit($organizationId, $userId, $roleId, 'role.unassigned');
            }
        }

        return count($roleIds);
    }

    public function assignmentsForSubject(string $organizationId, string $userId): array
    {
        // ENVIRONMENT-WIDE GRANTS COUNT HERE. The question this answers is "what does
        // this person effectively hold in this organization", and segregation of duties
        // is its main caller — so leaving them out would let a toxic pair form across the
        // two kinds of grant, invisibly, which is the one combination nobody would think
        // to look for.
        $everywhere = $this->everywhereFor($userId);

        $inOrg = array_filter(
            RoleAssignment::query()
                ->where('organization_id', $organizationId)
                ->where('user_id', $userId)
                ->pluck('role_id')
                ->all(),
            'is_string',
        );

        return array_values(array_unique([...$inOrg, ...$everywhere]));
    }

    public function assignmentsInOrganization(string $organizationId): array
    {
        return array_values(RoleAssignment::query()
            ->where('organization_id', $organizationId)
            ->orderBy('user_id')
            ->get()
            ->all());
    }

    public function assignmentsEverywhere(): array
    {
        return array_values(EnvironmentRoleAssignment::query()
            ->orderBy('user_id')
            ->orderBy('role_id')
            ->get()
            ->all());
    }

    /**
     * @param  string|null  $organizationId  null for an environment-wide grant, which
     *                                       belongs to no tenant. Both the event and the
     *                                       audit chain already model that: a null key
     *                                       files the entry on the ENVIRONMENT's chain
     *                                       rather than a tenant's, which is where a
     *                                       grant that spans every tenant belongs.
     * @param  array<string, mixed>  $context  extra facts about the grant, carried on both
     *                                         the event and the audit entry
     */
    private function emitAndAudit(?string $organizationId, string $userId, string $roleId, string $action, array $context = []): void
    {
        $this->events->emit(new DomainEvent($action, ['user_id' => $userId, 'role_id' => $roleId] + $context, $organizationId));

        $this->audit->record(new AuditEvent(
            action: $action,
            actorType: ActorType::System,
            organizationId: $organizationId,
            targetType: 'user',
            targetId: $userId,
            context: ['role_id' => $roleId] + $context,
        ));
    }
}
