<?php

declare(strict_types=1);

namespace Cbox\Id\Directory\Support;

use Cbox\Id\Directory\Enums\ScimFilterAttribute;
use Cbox\Id\Directory\Models\DirectoryUser;
use Cbox\Id\Scim\Filter\ScimFilterParser;
use Illuminate\Database\Eloquent\Builder;

/**
 * Parses and applies the subset of SCIM 2.0 filter syntax (RFC 7644 §3.4.2.2)
 * identity providers actually send against `/Users`: the comparison operators
 * `eq`/`ne`/`co`/`sw`/`ew`, the ordering comparisons `gt`/`ge`/`lt`/`le` on the
 * timestamp attributes, and the presence test `pr` — over the closed set of
 * {@see ScimFilterAttribute}, combined by a single top-level `and` or `or`.
 *
 * That covers the real traffic: `userName eq "x"` existence checks before
 * provisioning, Entra-style `userName eq "x" and active eq true`, and the
 * `meta.lastModified gt "<watermark>"` every delta sync is built on. Grouping
 * parentheses, nested/value-path filters, mixing `and` with `or`, an operator the
 * attribute's type cannot answer, and a literal that is not a value of that type all
 * return null, so the caller surfaces `invalidFilter` rather than silently
 * mis-matching.
 *
 * @deprecated Since 1.23 the directory stores parse filters with the full RFC 7644
 *             grammar ({@see ScimFilterParser}) and translate
 *             them with {@see ScimDirectoryQuery}; nothing in the package calls this
 *             any more. It is kept, unchanged, for hosts that use it directly.
 */
readonly class ScimUserFilter
{
    // A clause is a presence test (`attr pr`) or a comparison whose value is a
    // quoted string or an unquoted boolean literal (`active eq true`, RFC 7644).
    private const CLAUSE = '(?<attr>[\w.]+)\s+(?:(?<presence>pr)|(?<op>eq|ne|co|sw|ew|gt|ge|lt|le)\s+(?:"(?<val>[^"]*)"|(?<lit>true|false)))';

    /**
     * @param  non-empty-list<ScimFilterClause>  $clauses
     * @param  'and'|'or'  $conjunction  how the clauses combine (irrelevant for one)
     */
    private function __construct(
        public array $clauses,
        public string $conjunction,
    ) {}

    public static function parse(string $filter): ?self
    {
        $rest = trim($filter);
        $clauses = [];
        $conjunction = 'and';

        while ($rest !== '') {
            if (preg_match('/^'.self::CLAUSE.'/i', $rest, $m) !== 1) {
                return null;
            }

            $clause = self::clause($m);

            if ($clause === null) {
                return null;
            }

            $clauses[] = $clause;
            $rest = trim(substr($rest, strlen($m[0])));

            if ($rest === '') {
                break;
            }

            // Between two clauses the ONLY thing allowed is a single logical joiner,
            // and the whole expression must use one operator — mixing `and`/`or`
            // needs grouping we do not parse, so refuse it rather than guess precedence.
            if (preg_match('/^(?<join>and|or)\s+/i', $rest, $j) !== 1) {
                return null;
            }

            $join = strtolower($j['join']) === 'or' ? 'or' : 'and';

            if (count($clauses) > 1 && $join !== $conjunction) {
                return null;
            }

            $conjunction = $join;
            $rest = substr($rest, strlen($j[0]));
        }

        return $clauses === [] ? null : new self($clauses, $conjunction);
    }

    /**
     * @param  Builder<DirectoryUser>  $query
     * @return Builder<DirectoryUser>
     */
    public function apply(Builder $query): Builder
    {
        // Nest the clauses in their own group so an `or` never escapes past the
        // caller's directory scope (`WHERE directory_id = ? AND ( … OR … )`).
        return $query->where(function (Builder $group): void {
            foreach ($this->clauses as $index => $clause) {
                $clause->apply($group, $index === 0 ? 'and' : $this->conjunction);
            }
        });
    }

    /**
     * @param  array<array-key, string>  $matches
     */
    private static function clause(array $matches): ?ScimFilterClause
    {
        $attribute = ScimFilterAttribute::tryParse($matches['attr']);

        if ($attribute === null) {
            return null;
        }

        if (($matches['presence'] ?? '') !== '') {
            return new ScimFilterClause($attribute->column(), 'pr', null);
        }

        $operator = strtolower($matches['op']);
        $type = $attribute->type();

        // An operator the attribute's type cannot answer (a substring match on a
        // boolean, an ordering comparison this server does not implement) is refused,
        // not approximated.
        if (! $type->supports($operator)) {
            return null;
        }

        // An unquoted boolean literal (`lit`) wins over the quoted `val`; only one
        // of the two alternation branches ever participates in a match.
        $literal = $matches['lit'] ?? '';
        $value = $type->coerce($literal !== '' ? $literal : ($matches['val'] ?? ''));

        // A literal that is not a value of the attribute's type at all — `active eq
        // "fasle"` used to become `active = false` and answer, confidently, with every
        // deactivated user.
        if ($value === null) {
            return null;
        }

        return new ScimFilterClause($attribute->column(), $operator, $value);
    }
}
