<?php

declare(strict_types=1);

namespace Cbox\Id\Console;

use Cbox\Id\Identity\Contracts\RelyingParties;
use Cbox\Id\Identity\EnvironmentRelyingParties;
use Cbox\Id\Kernel\Crypto\Contracts\MasterKeyRing;
use Cbox\Id\Kernel\Crypto\Contracts\SealedColumns;
use Cbox\Id\Kernel\Crypto\Contracts\SecretRewrapper;
use Cbox\Id\Kernel\Crypto\Enums\KeyStatus;
use Cbox\Id\Kernel\Crypto\Exceptions\CryptoConfigurationException;
use Cbox\Id\Kernel\Crypto\Models\SigningKey;
use Cbox\Id\Kernel\Crypto\ValueObjects\MasterKeySet;
use Cbox\Id\Kernel\Tenancy\Contracts\IssuerResolver;
use Cbox\Id\Kernel\Tenancy\Scopes\EnvironmentScope;
use Cbox\Id\Organization\Models\Environment;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Schema;
use Throwable;

/**
 * `cbox-id:doctor` — a friendly health check. It looks over everything the
 * platform needs to run correctly and tells you, in plain language, what's good,
 * what's a warning, and what's broken (with the exact fix). Run it after install,
 * after a deploy, or any time something feels off. You should not need to be an
 * identity expert to read the output.
 */
class DoctorCommand extends Command
{
    protected $signature = 'cbox-id:doctor';

    protected $description = 'Check that the Cbox ID platform is configured correctly and ready to run';

    /** @var list<array{status: string, label: string, detail: string}> */
    private array $results = [];

    public function handle(): int
    {
        $this->line('');
        $this->line('  <options=bold>Cbox ID — health check</>');
        $this->line('  <fg=gray>Looking over your setup…</>');
        $this->line('');

        $this->checkExtensions();
        $this->checkCryptoKey();
        $this->checkMasterKeyRotation();
        $this->checkMigrations();
        $this->checkSigningKeys();
        $this->checkPlatformRoot();
        $this->checkIssuer();
        $this->checkAuthorizationEndpoint();
        $this->checkWebAuthn();
        $this->checkProductionHardening();

        // Whatever the HOST added. It knows things this package cannot: which planes its
        // console serves, where its account door lives, whether its own two halves agree.
        foreach (app(HealthChecks::class)->run() as $contributed) {
            $this->results[] = [
                'status' => $contributed->status->value,
                'label' => $contributed->label,
                'detail' => $contributed->detail,
            ];
        }

        foreach ($this->results as $result) {
            $this->line('  '.$this->icon($result['status']).' '.$result['label']);

            if ($result['detail'] !== '') {
                $this->line('     <fg=gray>'.$result['detail'].'</>');
            }
        }

        $fails = count(array_filter($this->results, static fn (array $r): bool => $r['status'] === 'fail'));
        $warns = count(array_filter($this->results, static fn (array $r): bool => $r['status'] === 'warn'));

        $this->line('');

        if ($fails > 0) {
            $this->line("  <fg=red;options=bold>✗ {$fails} problem(s) to fix</> <fg=gray>({$warns} warning(s))</>");
            $this->line('');

            return self::FAILURE;
        }

        if ($warns > 0) {
            $this->line("  <fg=yellow;options=bold>✓ Ready, with {$warns} warning(s) worth a look</>");
            $this->line('');

            return self::SUCCESS;
        }

        $this->line('  <fg=green;options=bold>✓ Everything looks healthy. You are good to go.</>');
        $this->line('');

        return self::SUCCESS;
    }

    private function checkExtensions(): void
    {
        $missing = array_filter(['sodium', 'openssl'], static fn (string $ext): bool => ! extension_loaded($ext));

        $missing === []
            ? $this->addOk('PHP extensions', 'sodium and openssl are loaded.')
            : $this->addFail('PHP extensions', 'Missing: '.implode(', ', $missing).'. Enable them in php.ini — the crypto layer needs them.');
    }

    private function checkCryptoKey(): void
    {
        try {
            $keys = MasterKeySet::fromConfig(config('cbox-id.crypto.key'), config('cbox-id.crypto.previous_keys'));
        } catch (CryptoConfigurationException $e) {
            $this->addFail('Crypto master key', $e->getMessage().' Run `php artisan cbox-id:install` to generate a key.');

            return;
        }

        $previous = count($keys->previous);

        $this->addOk('Crypto master key', 'Set and valid (32 bytes, id '.$keys->current->id.')'
            .($previous > 0 ? " plus {$previous} previous key(s) for opening older secrets" : '')
            .'. Keep it backed up separately from the database.');
    }

    /**
     * A rotation is only finished when nothing is left under the old key — until then the
     * old key cannot be dropped, and the operator who drops it anyway makes every secret
     * still under it unreadable. So while a previous key is configured, count what is not
     * yet current and say so.
     *
     * Untagged envelopes from before 1.22 are not a warning on their own: with no previous
     * key configured they can only be under the current key. They are mentioned so the
     * operator knows a rewrap will tag them.
     */
    private function checkMasterKeyRotation(): void
    {
        try {
            $ring = app(MasterKeyRing::class);
            $rewrapper = app(SecretRewrapper::class);
            $remaining = 0;
            $columns = [];

            foreach (app(SealedColumns::class)->all() as $column) {
                $count = $rewrapper->remaining($column);

                if ($count > 0) {
                    $remaining += $count;
                    $columns[] = $column->name();
                }
            }
        } catch (Throwable) {
            // The key itself is reported by checkCryptoKey(); an unreachable database by
            // checkMigrations(). Neither needs saying twice.
            return;
        }

        if ($ring->previousKeyIds() === []) {
            $this->addOk('Master key rotation', $remaining > 0
                ? "No rotation in progress. {$remaining} secret(s) predate key versioning; `php artisan cbox-id:crypto:rewrap` tags them with the current key (optional)."
                : 'No rotation in progress; every secret is sealed under the current key.');

            return;
        }

        if ($remaining > 0) {
            $this->addWarn('Master key rotation', "{$remaining} secret(s) are not yet sealed under the current key (".implode(', ', $columns).'). '
                .'Run `php artisan cbox-id:crypto:rewrap`, and keep CBOX_ID_CRYPTO_PREVIOUS_KEYS until this clears.');

            return;
        }

        $this->addWarn('Master key rotation', 'Every secret is sealed under the current key. The previous key(s) '
            .implode(', ', $ring->previousKeyIds()).' are no longer needed: remove them from CBOX_ID_CRYPTO_PREVIOUS_KEYS.');
    }

    private function checkMigrations(): void
    {
        try {
            $present = Schema::hasTable('signing_keys') && Schema::hasTable('oauth_clients') && Schema::hasTable('auth_sessions');
        } catch (Throwable) {
            $this->addFail('Database', 'Could not connect to the database. Check your DB_* settings.');

            return;
        }

        $present
            ? $this->addOk('Migrations', 'Core tables exist.')
            : $this->addFail('Migrations', 'Core tables are missing. Run `php artisan migrate`.');
    }

    /**
     * An active signing key in EVERY environment, counted across environments.
     *
     * Signing keys are environment-owned, and the doctor runs with no environment set —
     * so a plain query went through the environment scope's `where 1 = 0` and reported
     * "no active signing key" on every multi-environment install, however many there were.
     * Read past the scope, per environment: an environment without one is named (a key is
     * minted on first use there, so it is a warning, not a failure).
     */
    private function checkSigningKeys(): void
    {
        try {
            /** @var list<string> $withKey */
            $withKey = SigningKey::query()
                ->withoutGlobalScope(EnvironmentScope::class)
                ->where('status', KeyStatus::Active->value)
                ->distinct()
                ->pluck('environment_id')
                ->filter(static fn (mixed $id): bool => is_string($id))
                ->values()
                ->all();
            /** @var list<string> $environments */
            $environments = Environment::query()->pluck('id')->filter(static fn (mixed $id): bool => is_string($id))->values()->all();
        } catch (Throwable) {
            $this->addWarn('Signing keys', 'Could not read signing keys (migrations not run yet?).');

            return;
        }

        if ($environments === []) {
            $withKey !== []
                ? $this->addOk('Signing keys', count($withKey).' environment(s) with an active key. Tokens can be signed and the JWKS is populated.')
                : $this->addWarn('Signing keys', 'No active signing key yet — one is minted on first use, or run `php artisan cbox-id:install`.');

            return;
        }

        $missing = array_values(array_diff($environments, $withKey));

        if ($missing === []) {
            $this->addOk('Signing keys', 'Every environment ('.count($environments).') has an active key. Tokens can be signed and each JWKS is populated.');

            return;
        }

        $slugs = Environment::query()->whereIn('id', $missing)->pluck('slug')->filter(static fn (mixed $slug): bool => is_string($slug))->all();

        $this->addWarn('Signing keys', 'No active signing key yet in: '.implode(', ', $slugs).' — one is minted on first use there, or run `php artisan cbox-id:install`.');
    }

    /**
     * The platform root is where the platform's OWN people are written as subjects, so
     * aiming it at a customer's environment hands that customer's environment admins a
     * way to set an account member's password and sign in as them. The mistake is silent
     * at runtime — everything works, in the wrong tenant — so it is caught here.
     */
    private function checkPlatformRoot(): void
    {
        try {
            $stamped = Environment::query()->where('is_default', true)->first();
        } catch (Throwable) {
            $this->addWarn('Platform root', 'Could not read environments (migrations not run yet?).');

            return;
        }

        if ($stamped !== null) {
            $this->addOk('Platform root', "'{$stamped->slug}' is flagged is_default.");

            return;
        }

        $configured = config('cbox-id.environments.default');

        if (! is_string($configured) || $configured === '') {
            $this->addWarn('Platform root', 'No is_default environment and no CBOX_ID_ENVIRONMENT_DEFAULT — account members have nowhere to live. Run `php artisan cbox-id:install`.');

            return;
        }

        $row = Environment::query()->where('id', $configured)->orWhere('slug', $configured)->first();

        if ($row === null) {
            // Legitimate for a single-tenant self-hosted install: the config key scopes
            // every query and no `environments` row need ever exist. It only matters if
            // this deployment serves ACCOUNTS, which need somewhere to put their people.
            $this->addWarn('Platform root', "CBOX_ID_ENVIRONMENT_DEFAULT is '{$configured}' with no environment row behind it. Fine for a single-tenant install; multi-account deployments need a real environment stamped is_default.");

            return;
        }

        // Unowned is `project_id === null` — the same predicate {@see PlatformRoot::environment()}
        // refuses on, and it has to stay the same one or the doctor reports a root the
        // platform will not actually use.
        $row->project_id === null
            ? $this->addWarn('Platform root', "Resolved from config to '{$row->slug}'. Stamp it is_default so the answer does not depend on per-process configuration.")
            : $this->addFail('Platform root', "CBOX_ID_ENVIRONMENT_DEFAULT points at '{$row->slug}', which a customer owns. The platform root must be an environment no customer owns.");
    }

    private function checkIssuer(): void
    {
        $issuer = config('cbox-id.issuer');

        is_string($issuer) && $issuer !== ''
            ? $this->addOk('Issuer', $issuer)
            : $this->addWarn('Issuer', 'CBOX_ID_ISSUER is not set — discovery falls back to the app URL. Set it to your public HTTPS URL.');
    }

    private function checkAuthorizationEndpoint(): void
    {
        $rawPath = config('cbox-id.oauth.authorization_endpoint_path');
        $rawAbsolute = config('cbox-id.oauth.authorization_endpoint');
        $path = is_string($rawPath) ? $rawPath : '';
        $absolute = is_string($rawAbsolute) ? $rawAbsolute : '';
        $configured = $path !== '' || $absolute !== '';

        // OpenID Connect Discovery §3 marks authorization_endpoint REQUIRED, but RFC 8414
        // (plain OAuth) permits omitting it — and a machine-to-machine deployment serving
        // only client_credentials genuinely has no authorization endpoint. So this is a
        // warning, not a failure: it must not fail a valid OAuth-only install, but a host
        // intending to serve OIDC needs to know its discovery document is one certified
        // clients will refuse. The package cannot supply the value itself — it serves the
        // back-channel endpoints, not the consent screen, and advertising a route it does
        // not serve would be worse than omitting it.
        $configured
            ? $this->addOk('Authorization endpoint', $path !== '' ? $path : $absolute)
            : $this->addWarn(
                'Authorization endpoint',
                'Not configured, so discovery omits `authorization_endpoint`. Fine for an OAuth-only '
                .'(client_credentials) deployment; but if you serve OpenID Connect, a conformant client will '
                .'refuse to initialize — set CBOX_ID_AUTHORIZATION_ENDPOINT_PATH to where your app mounts '
                .'/authorize (e.g. /oauth/authorize).',
            );
    }

    /**
     * Unset rp_id/origin is no longer a warning — it is the recommended state, and the
     * Relying Party is derived from the environment's issuer. What is worth reporting is
     * a PIN THAT DOES NOT APPLY here: it looks configured, it is silently overridden on
     * every host but its own, and an operator reading their `.env` would conclude the
     * opposite.
     */
    private function checkWebAuthn(): void
    {
        $parties = $this->laravel->make(RelyingParties::class);
        $issuers = $this->laravel->make(IssuerResolver::class);

        try {
            $current = $parties->current();
        } catch (Throwable) {
            // Resolving the party reads the environment's issuer, which is a database
            // lookup. Doctor is the tool you run on a box that has not migrated yet, so a
            // missing schema is a state to report, not to die on.
            $this->addWarn('Passkeys (WebAuthn)', 'Cannot resolve the Relying Party until migrations have run.');

            return;
        }

        if (! $parties instanceof EnvironmentRelyingParties) {
            $this->addOk('Passkeys (WebAuthn)', "rp_id {$current->id} (host-bound resolver)");

            return;
        }

        $pinned = $parties->pinned();

        if ($pinned === null) {
            $this->addOk('Passkeys (WebAuthn)', "rp_id {$current->id} (derived from the issuer)");

            return;
        }

        // Compared against the HOST, not against `$current`. Comparing the two parties was
        // structurally unable to name the state it was written for: once a pin wins,
        // `$current` IS `$pinned`, so both halves are identical by construction and the
        // check reported OK for every pin that won — including one that wins and then
        // fails every ceremony.
        //
        // The question an operator needs answered is whether the pin matches the host that
        // will actually answer here, so that is what is asked. A pin whose origin names a
        // different host is refused by `EnvironmentRelyingParties` and reported below; a
        // pin that is in force is confirmed against the host rather than against itself.
        $host = $issuers->canonicalHost();

        $inForce = $pinned->id === $current->id && $pinned->origin === $current->origin;
        $reaches = $host === null || ($pinned->host() === $host
            && ($host === $pinned->id || str_ends_with($host, '.'.$pinned->id)));

        $inForce && $reaches
            ? $this->addOk('Passkeys (WebAuthn)', "rp_id {$current->id} (pinned)")
            : $this->addWarn(
                'Passkeys (WebAuthn)',
                "The pin is rp_id {$pinned->id} at {$pinned->origin}, but ceremonies in this "
                ."environment run as rp_id {$current->id} at {$current->origin}, on host "
                .($host ?? '(the configured issuer)').'. A credential enrolled under a different id is '
                .'never offered, and an origin the browser does not report fails every ceremony. Unset '
                .'both keys unless this deployment really does serve passkeys from exactly one origin.',
            );
    }

    private function checkProductionHardening(): void
    {
        if (! $this->laravel->environment('production')) {
            $this->addOk('Environment', 'Non-production — hardening checks are advisory.');

            return;
        }

        $issues = [];

        if (config('app.debug') === true) {
            $issues[] = 'APP_DEBUG is true';
        }

        if (config('session.secure') !== true) {
            $issues[] = 'SESSION_SECURE_COOKIE is not true';
        }

        if (config('session.encrypt') !== true) {
            $issues[] = 'SESSION_ENCRYPT is not true';
        }

        $issues === []
            ? $this->addOk('Production hardening', 'Debug off, secure + encrypted sessions.')
            : $this->addFail('Production hardening', implode('; ', $issues).'. Fix these before serving traffic.');
    }

    private function addOk(string $label, string $detail = ''): void
    {
        $this->results[] = ['status' => 'ok', 'label' => $label, 'detail' => $detail];
    }

    private function addWarn(string $label, string $detail = ''): void
    {
        $this->results[] = ['status' => 'warn', 'label' => $label, 'detail' => $detail];
    }

    private function addFail(string $label, string $detail = ''): void
    {
        $this->results[] = ['status' => 'fail', 'label' => $label, 'detail' => $detail];
    }

    private function icon(string $status): string
    {
        return match ($status) {
            'ok' => '<fg=green>✓</>',
            'warn' => '<fg=yellow>!</>',
            default => '<fg=red>✗</>',
        };
    }
}
