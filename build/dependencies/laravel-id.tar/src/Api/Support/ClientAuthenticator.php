<?php

declare(strict_types=1);

namespace Cbox\Id\Api\Support;

use Cbox\Id\OAuthServer\Contracts\ClientAssertion;
use Cbox\Id\OAuthServer\Contracts\ClientIdMetadataDocuments;
use Cbox\Id\OAuthServer\Contracts\ClientRegistry;
use Cbox\Id\OAuthServer\Enums\ClientType;
use Cbox\Id\OAuthServer\Exceptions\InvalidClientMetadataDocument;
use Cbox\Id\OAuthServer\Models\Client;
use Illuminate\Http\Request;

/**
 * The single place OAuth client credentials are read and verified, so every
 * credential-bearing endpoint (`/oauth/token`, `/introspect`, `/revoke`, `/par`)
 * authenticates a client the same way.
 *
 * Three methods, in precedence order: `private_key_jwt` (RFC 7523 — a signed
 * `client_assertion` verified against the client's registered keys), then HTTP Basic
 * (RFC 6749 §2.3.1, `client_secret_basic`), then the `client_id`/`client_secret` body
 * (`client_secret_post`). The RFC forbids combining mechanisms, so a request mixing an
 * assertion with a secret — or Basic with body credentials — is refused. Secrets are
 * verified in constant time by the {@see ClientRegistry}; public clients (no secret,
 * `none`) authenticate by `client_id` alone where the endpoint allows it.
 *
 * A `client_id` the registry does not know may be a client ID metadata document URL
 * ({@see ClientIdMetadataDocuments}, when enabled). Such a client never holds a secret, so
 * one presented alongside it is refused; a `none` document client authenticates by
 * `client_id` (PKCE carries the proof), and a `private_key_jwt` one only by assertion.
 */
class ClientAuthenticator
{
    public function __construct(
        private readonly ClientRegistry $clients,
        private readonly ClientAssertion $assertions,
        private readonly ?ClientIdMetadataDocuments $documents = null,
    ) {}

    /**
     * Authenticate a client that MAY be public (`none`): a confidential client
     * (one that holds a secret) must present a valid secret, while a public client
     * authenticates by `client_id` alone. Returns null when the client is unknown,
     * a confidential secret is wrong, or both credential mechanisms were combined.
     */
    public function authenticate(Request $request): ?Client
    {
        if ($this->hasAssertion($request)) {
            return $this->assertionClient($request);
        }

        $credentials = $this->credentials($request);

        if ($credentials === null) {
            return null;
        }

        [$clientId, $secret] = $credentials;
        $client = $this->clients->byClientId($clientId) ?? $this->documentClient($clientId, $secret);

        if ($client === null) {
            return null;
        }

        // Key the bypass on the client's TYPE, not on whether a secret happens to be
        // stored. A confidential client authenticating by private_key_jwt has
        // secret_hash === null BY DESIGN (a secret is minted only when no JWKS is
        // registered), so the old `secret_hash !== null` test skipped verification
        // entirely and returned the client on the strength of a client_id alone. Anyone
        // holding such a client's refresh token or authorization code could redeem it
        // with no assertion — collapsing private_key_jwt to a bearer model.
        //
        // An assertion, if one was presented, is handled above; reaching here means a
        // confidential client must prove itself with a secret.
        // Require proof when the client is Confidential OR still holds a secret.
        //
        // Keying on type ALONE re-opened the hole from the other side: RFC 7592 lets a
        // client rewrite its own token_endpoint_auth_method to "none" via
        // PUT /oauth/register/{client}, which flipped type to Public WITHOUT clearing
        // the secret — so anyone holding a registration access token could downgrade a
        // confidential client and then authenticate on client_id alone. The disjunction
        // covers both the private_key_jwt case (type set, no secret) and the downgrade
        // case (secret still set, type cleared).
        //
        // "Still holds a secret" means a LIVE one in the registry's secret store. A
        // client with none fails `verifySecret()` below by construction, so a
        // confidential client with no secret (private_key_jwt) is refused here too.
        if (($client->type === ClientType::Confidential || $this->clients->hasSecret($client))
            && ! $this->clients->verifySecret($client, $secret)) {
            return null;
        }

        return $client;
    }

    /**
     * Authenticate a confidential client: a valid secret is REQUIRED. Used by the
     * `client_credentials` grant and the introspection/revocation endpoints, which
     * have no public-client mode. Public clients are refused.
     */
    public function authenticateConfidential(Request $request): ?Client
    {
        if ($this->hasAssertion($request)) {
            return $this->assertionClient($request);
        }

        $credentials = $this->credentials($request);

        if ($credentials === null) {
            return null;
        }

        [$clientId, $secret] = $credentials;
        $client = $this->clients->byClientId($clientId);

        return $client !== null && $this->clients->verifySecret($client, $secret) ? $client : null;
    }

    /**
     * The client a metadata document describes, when `$clientId` is one and no secret was
     * presented. A document client cannot hold a secret, so a request carrying one is not
     * from it; and a document that cannot be fetched or fails validation authenticates
     * nobody — the same `invalid_client` an unknown id gets, with no detail that would
     * tell a prober which.
     */
    private function documentClient(string $clientId, string $secret): ?Client
    {
        if ($this->documents === null || $secret !== '' || ! $this->documents->supports($clientId)) {
            return null;
        }

        try {
            return $this->documents->resolve($clientId);
        } catch (InvalidClientMetadataDocument) {
            return null;
        }
    }

    private function hasAssertion(Request $request): bool
    {
        return $request->string('client_assertion')->toString() !== '';
    }

    /**
     * Authenticate via `private_key_jwt` (RFC 7523). Refuses a wrong assertion type,
     * and — per RFC 6749 §2.3 — an assertion COMBINED with a secret or Basic header.
     */
    private function assertionClient(Request $request): ?Client
    {
        if ($request->string('client_assertion_type')->toString() !== ClientAssertion::ASSERTION_TYPE) {
            return null;
        }

        $basicUser = $request->getUser();
        $combined = (is_string($basicUser) && $basicUser !== '') || $request->string('client_secret')->toString() !== '';

        if ($combined) {
            return null;
        }

        return $this->assertions->verify($request->string('client_assertion')->toString());
    }

    /**
     * Extract (client_id, client_secret), preferring HTTP Basic over the body.
     * Returns null when no `client_id` is present, or when both mechanisms are
     * combined (RFC 6749 §2.3.1: "a client MUST NOT use more than one
     * authentication method in each request").
     *
     * @return array{string, string}|null
     */
    private function credentials(Request $request): ?array
    {
        $basicUser = $request->getUser();
        $hasBasic = is_string($basicUser) && $basicUser !== '';

        $bodyId = $request->string('client_id')->toString();
        $bodySecret = $request->string('client_secret')->toString();
        $hasBody = $bodyId !== '' || $bodySecret !== '';

        if ($hasBasic && $hasBody) {
            return null;
        }

        if ($hasBasic) {
            return [$basicUser, (string) $request->getPassword()];
        }

        return $bodyId === '' ? null : [$bodyId, $bodySecret];
    }
}
