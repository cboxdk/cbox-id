<?php

declare(strict_types=1);

namespace Cbox\Id\Api\Http\Controllers;

use Cbox\Id\Kernel\Tenancy\Contracts\IssuerResolver;
use Cbox\Id\OAuthServer\Contracts\DynamicClientRegistration;
use Cbox\Id\OAuthServer\Exceptions\InvalidClientMetadata;
use Cbox\Id\OAuthServer\Support\ClientRegistrationDocument;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * `POST /oauth/register` — OAuth 2.0 Dynamic Client Registration (RFC 7591).
 *
 * Gated by `cbox-id.oauth.dynamic_registration.mode`: `disabled` (403),
 * `protected` (requires the configured initial access token), `open`, or `mcp` (open,
 * but public clients for host-declared resources only — see DynamicClientRegistrar).
 */
class RegistrationController
{
    public function __construct(
        private readonly DynamicClientRegistration $registrar,
        // The issuer, not `url()`. Every other URL in the registration response and in
        // discovery is built from the environment's issuer; this one was built from the
        // request Host, so a tenant registering through any alias of its issuer was
        // handed a management URI on that alias — the one endpoint in the document that
        // could name a host the issuer does not.
        private readonly IssuerResolver $issuers,
    ) {}

    public function __invoke(Request $request): JsonResponse
    {
        $gate = $this->gate($request);

        if ($gate !== null) {
            return $gate;
        }

        try {
            $metadata = $this->registrar->validate($this->body($request));
        } catch (InvalidClientMetadata $e) {
            return new JsonResponse(['error' => $e->error, 'error_description' => $e->getMessage()], 400);
        }

        $registration = $this->registrar->register($metadata);

        $document = ClientRegistrationDocument::for($registration->client);
        $document['registration_access_token'] = $registration->registrationAccessToken;
        $document['registration_client_uri'] = $this->issuers->issuer().'/oauth/register/'.$registration->client->client_id;

        if ($registration->secret !== null) {
            $document['client_secret'] = $registration->secret;
            $document['client_secret_expires_at'] = 0; // 0 = does not expire
        }

        return new JsonResponse($document, 201);
    }

    /**
     * Enforce the registration mode. Returns an error response to short-circuit,
     * or null to proceed.
     */
    private function gate(Request $request): ?JsonResponse
    {
        $mode = config('cbox-id.oauth.dynamic_registration.mode', 'disabled');

        // `mcp` is open registration too — anyone may register — held to the MCP profile
        // by the registrar and to a per-address hourly ceiling by the route's limiter.
        if ($mode === 'open' || $mode === 'mcp') {
            return null;
        }

        if ($mode !== 'protected') {
            return new JsonResponse([
                'error' => 'access_denied',
                'error_description' => 'dynamic client registration is disabled',
            ], 403);
        }

        // protected: require the configured initial access token as a bearer.
        $expected = config('cbox-id.oauth.dynamic_registration.initial_access_token');
        $presented = $request->bearerToken();

        if (! is_string($expected) || $expected === '' || ! is_string($presented)
            || ! hash_equals($expected, $presented)) {
            return new JsonResponse([
                'error' => 'invalid_token',
                'error_description' => 'a valid initial access token is required to register',
            ], 401, ['WWW-Authenticate' => 'Bearer']);
        }

        return null;
    }

    /**
     * @return array<string, mixed>
     */
    private function body(Request $request): array
    {
        $data = $request->json()->all();
        $data = $data === [] ? $request->all() : $data;

        $normalized = [];

        foreach ($data as $key => $value) {
            $normalized[(string) $key] = $value;
        }

        return $normalized;
    }
}
